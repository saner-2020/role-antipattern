/*
 * NullableSpinner.java 29 mai 07
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.NumberFormat;
/**
 * Spinner that accepts empty string values. In this case the returned value is <code>null</code>. 
 */
public static class NullableSpinnerModuloNumberModel extends NullableSpinnerNumberModel {
    private Class numberClass;
    public NullableSpinnerModuloNumberModel(int value, int minimum, int maximum, int stepSize) {
      super(value, minimum, maximum, stepSize);
      this.numberClass = int.class;
    }
    public NullableSpinnerModuloNumberModel(float value, float minimum, float maximum, float stepSize) {
      super(value, minimum, maximum, stepSize);
      this.numberClass = float.class;
    }
    @Override
    public Object getNextValue() {
      if (this.numberClass == int.class) {
        if (getValue() == null
            || getNumber().intValue() + getStepSize().intValue() < ((Number)getMaximum()).intValue()) {
          return ((Number)super.getNextValue()).intValue();
        } else {
          return getNumber().intValue() + getStepSize().intValue() - ((Number)getMaximum()).intValue() + ((Number)getMinimum()).intValue();
        }
      } else {
        if (getValue() == null
            || getNumber().floatValue() + getStepSize().floatValue() < ((Number)getMaximum()).floatValue()) {
          return ((Number)super.getNextValue()).floatValue();
        } else {
          return getNumber().floatValue() + getStepSize().floatValue() - ((Number)getMaximum()).floatValue() + ((Number)getMinimum()).floatValue();
        }
      }
    }
    @Override
    public Object getPreviousValue() {
      if (this.numberClass == int.class) {
        if (getValue() == null
            || getNumber().intValue() - getStepSize().intValue() >= ((Number)getMinimum()).intValue()) {
          return ((Number)super.getPreviousValue()).intValue();
        } else {
          return getNumber().intValue() - getStepSize().intValue() - ((Number)getMinimum()).intValue() + ((Number)getMaximum()).intValue();
        }
      } else {
        if (getValue() == null
            || getNumber().floatValue() - getStepSize().floatValue() >= ((Number)getMinimum()).floatValue()) {
          return ((Number)super.getPreviousValue()).floatValue();
        } else {
          return getNumber().floatValue() - getStepSize().floatValue() - ((Number)getMinimum()).floatValue() + ((Number)getMaximum()).floatValue();
        }
      }
    }
    /**
     * Returns the format used by this model.
     */
    @Override
    Format getFormat() {
      return this.numberClass == int.class 
          ? NumberFormat.getIntegerInstance()
          : new DecimalFormat("0.#");
    }
  }
