/*
 * PlanController.java 2 juin 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import com.eteks.sweethome3d.model.Label;
import com.eteks.sweethome3d.model.TextStyle;
/**
 * A MVC controller for the plan view.
 * @author Emmanuel Puybaret
 */
private class LabelElevationState extends ControllerState {
    private boolean magnetismEnabled;
    private float   deltaYToElevationPoint;
    private Label   selectedLabel;
    private float   oldElevation;
    private String  elevationToolTipFeedback;
    @Override
    public Mode getMode() {
      return Mode.SELECTION;
    }
    @Override
    public boolean isModificationState() {
      return true;
    }
    @Override
    public boolean isBasePlanModificationState() {
      return true;
    }
    @Override
    public void enter() {
      this.elevationToolTipFeedback = preferences.getLocalizedString(
          PlanController.class, "elevationToolTipFeedback");
      this.selectedLabel = (Label)home.getSelectedItems().get(0);
      TextStyle textStyle = getItemTextStyle(this.selectedLabel, this.selectedLabel.getStyle());
      float [][] textBounds = getView().getTextBounds(this.selectedLabel.getText(), textStyle, 
          this.selectedLabel.getX(), this.selectedLabel.getY(), this.selectedLabel.getAngle());
      this.deltaYToElevationPoint = getYLastMousePress() - (textBounds [2][1] + textBounds [3][1]) / 2;
      this.oldElevation = this.selectedLabel.getElevation();
      this.magnetismEnabled = preferences.isMagnetismEnabled()
                              ^ wasMagnetismToggledLastMousePress();
      PlanView planView = getView();
      planView.setResizeIndicatorVisible(true);
      planView.setToolTipFeedback(getToolTipFeedbackText(this.oldElevation), 
          getXLastMousePress(), getYLastMousePress());
    }
    @Override
    public void moveMouse(float x, float y) {
      // Compute the new elevation of the piece 
      PlanView planView = getView();
      TextStyle textStyle = getItemTextStyle(this.selectedLabel, this.selectedLabel.getStyle());
      float [][] textBounds = getView().getTextBounds(this.selectedLabel.getText(), textStyle, 
          this.selectedLabel.getX(), this.selectedLabel.getY(), this.selectedLabel.getAngle());
      float deltaY = y - this.deltaYToElevationPoint - (textBounds [2][1] + textBounds [3][1]) / 2;
      float newElevation = this.oldElevation - deltaY;
      newElevation = Math.min(Math.max(newElevation, 0f), preferences.getLengthUnit().getMaximumElevation());
      if (this.magnetismEnabled) {
        newElevation = preferences.getLengthUnit().getMagnetizedLength(newElevation, planView.getPixelLength());
      }
      // Update piece new dimension
      this.selectedLabel.setElevation(newElevation);
      // Ensure point at (x,y) is visible
      planView.makePointVisible(x, y);
      planView.setToolTipFeedback(getToolTipFeedbackText(newElevation), x, y);
    }
    @Override
    public void releaseMouse(float x, float y) {
      postLabelElevation(this.selectedLabel, this.oldElevation);
      setState(getSelectionState());
    }
    @Override
    public void toggleMagnetism(boolean magnetismToggled) {
      // Compute active magnetism
      this.magnetismEnabled = preferences.isMagnetismEnabled()
                              ^ magnetismToggled;
      // Compute again angle as if mouse moved
      moveMouse(getXLastMouseMove(), getYLastMouseMove());
    }
    @Override
    public void escape() {
      this.selectedLabel.setElevation(this.oldElevation);
      setState(getSelectionState());
    }
    @Override
    public void exit() {
      PlanView planView = getView();
      planView.setResizeIndicatorVisible(false);
      planView.deleteFeedback();
      this.selectedLabel = null;
    }  
    private String getToolTipFeedbackText(float height) {
      return String.format(this.elevationToolTipFeedback,  
          preferences.getLengthUnit().getFormatWithUnit().format(height));
    }
  }
