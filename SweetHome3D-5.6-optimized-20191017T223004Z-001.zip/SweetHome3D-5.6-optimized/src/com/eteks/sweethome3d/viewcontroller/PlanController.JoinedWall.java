/*
 * PlanController.java 2 juin 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import java.util.Arrays;
import java.util.List;
import com.eteks.sweethome3d.model.Level;
import com.eteks.sweethome3d.model.Wall;
/**
 * A MVC controller for the plan view.
 * @author Emmanuel Puybaret
 */
private static final class JoinedWall {
    private final Wall    wall;
    private final Level   level;
    private final float   xStart;
    private final float   yStart;
    private final float   xEnd;
    private final float   yEnd; 
    private final Wall    wallAtStart;
    private final Wall    wallAtEnd;
    private final boolean joinedAtEndOfWallAtStart;
    private final boolean joinedAtStartOfWallAtEnd;
    public JoinedWall(Wall wall) {
      this.wall = wall;
      this.level = wall.getLevel();
      this.xStart = wall.getXStart();
      this.xEnd = wall.getXEnd();
      this.yStart = wall.getYStart();
      this.yEnd = wall.getYEnd();
      this.wallAtStart = wall.getWallAtStart();
      this.joinedAtEndOfWallAtStart =
          this.wallAtStart != null
          && this.wallAtStart.getWallAtEnd() == wall;
      this.wallAtEnd = wall.getWallAtEnd();
      this.joinedAtStartOfWallAtEnd =
          this.wallAtEnd != null
          && wallAtEnd.getWallAtStart() == wall;
    }
    public Wall getWall() {
      return this.wall;
    }
    public Level getLevel() {
      return this.level;
    }
    public float getXStart() {
      return this.xStart;
    }
    public float getYStart() {
      return this.yStart;
    }
    public float getXEnd() {
      return this.xEnd;
    }
    public float getYEnd() {
      return this.yEnd;
    }
    public Wall getWallAtEnd() {
      return this.wallAtEnd;
    }
    public Wall getWallAtStart() {
      return this.wallAtStart;
    }
    public boolean isJoinedAtEndOfWallAtStart() {
      return this.joinedAtEndOfWallAtStart;
    }
    public boolean isJoinedAtStartOfWallAtEnd() {
      return this.joinedAtStartOfWallAtEnd;
    }
    /**
     * A helper method that builds an array of <code>JoinedWall</code> objects 
     * for a given list of walls.
     */
    public static JoinedWall [] getJoinedWalls(List<Wall> walls) {
      JoinedWall [] joinedWalls = new JoinedWall [walls.size()];
      for (int i = 0; i < joinedWalls.length; i++) {
        joinedWalls [i] = new JoinedWall(walls.get(i));
      }
      return joinedWalls;
    }
    /**
     * A helper method that builds a list of <code>Wall</code> objects 
     * for a given array of <code>JoinedWall</code> objects.
     */
    public static List<Wall> getWalls(JoinedWall [] joinedWalls) {
      Wall [] walls = new Wall [joinedWalls.length];
      for (int i = 0; i < joinedWalls.length; i++) {
        walls [i] = joinedWalls [i].getWall();
      }
      return Arrays.asList(walls);
    }
  }
