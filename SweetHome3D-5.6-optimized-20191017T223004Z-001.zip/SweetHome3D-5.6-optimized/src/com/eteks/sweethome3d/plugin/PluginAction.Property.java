/*
 * PluginAction.java 26 oct. 2008
 *
 * Sweet Home 3D, Copyright (c) 2008 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.plugin;
/**
 * An action made available to application users through a plugin.
 * @author Emmanuel Puybaret
 */
public enum Property {
    /** 
     * The key of the property of <code>String</code> type that specifies
     * the name of an action, used for a menu or button.
     */
    NAME,
    /**
     * The key of the property of <code>String</code> type that specifies
     * a short description of an action, used for tool tip text.
     */
    SHORT_DESCRIPTION,
    /**
     * The key of the property of <code>Content</code> type that specifies
     * an image content of an action, used for tool bar buttons.  
     */
    SMALL_ICON,
    /**
     * The key of the property of <code>Character</code> type that specifies 
     * the ASCII character used as the mnemonic of an action.
     */
    MNEMONIC,
    /**
     * The key of the property of <code>Boolean</code> type that specifies
     * if an action will appear in the main tool bar.
     */
    TOOL_BAR,
    /**
     * The key of the property of <code>String</code> type that specifies
     * in which menu of the main menu bar an action should appear. 
     */
    MENU,
    /**
     * The key of the property of <code>Boolean</code> type that specifies
     * if an action is enabled or not.
     */
    ENABLED,
  }
