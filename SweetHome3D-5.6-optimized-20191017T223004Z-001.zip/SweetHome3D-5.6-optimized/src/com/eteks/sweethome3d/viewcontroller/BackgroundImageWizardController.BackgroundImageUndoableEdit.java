/*
 * BackgroundImageWizardController.java 8 juin 07
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import com.eteks.sweethome3d.model.BackgroundImage;
import com.eteks.sweethome3d.model.Home;
import com.eteks.sweethome3d.model.Level;
import com.eteks.sweethome3d.model.UserPreferences;
/**
 * Wizard controller for background image in plan.
 * @author Emmanuel Puybaret
 */
private static class BackgroundImageUndoableEdit extends AbstractUndoableEdit {
    private final Home            home;
    private final Level           level;
    private final UserPreferences preferences;
    private final boolean         modification;
    private final BackgroundImage oldImage;
    private final BackgroundImage image;
    private BackgroundImageUndoableEdit(Home home,
                                        Level level, 
                                        UserPreferences preferences,
                                        boolean modification,
                                        BackgroundImage oldImage,
                                        BackgroundImage image) {
      this.home = home;
      this.level = level;
      this.preferences = preferences;
      this.modification = modification;
      this.oldImage = oldImage;
      this.image = image;
    }
    @Override
    public void undo() throws CannotUndoException {
      super.undo();
      this.home.setSelectedLevel(this.level);
      if (this.level != null) {
        this.level.setBackgroundImage(this.oldImage);
      } else {
        this.home.setBackgroundImage(this.oldImage);
      } 
    }
    @Override
    public void redo() throws CannotRedoException {
      super.redo();
      this.home.setSelectedLevel(this.level);
      if (this.level != null) {
        this.level.setBackgroundImage(this.image);
      } else {
        this.home.setBackgroundImage(this.image);
      } 
    }
    @Override
    public String getPresentationName() {
      return this.preferences.getLocalizedString(BackgroundImageWizardController.class,
          this.modification 
              ? "undoImportBackgroundImageName"
              : "undoModifyBackgroundImageName");
    }
  }
