/*
 * Copyright 2011-2015 the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui;
import org.bitcoinj.core.Monetary;
import de.schildbach.wallet.util.MonetarySpannable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
/**
 * @author Andreas Schildbach
 */
private final class TextViewListener implements TextWatcher, OnFocusChangeListener {
        private boolean fire = true;
        public void setFire(final boolean fire) {
            this.fire = fire;
        }
        @Override
        public void afterTextChanged(final Editable s) {
            // workaround for German keyboards
            final String original = s.toString();
            final String replaced = original.replace(',', '.');
            if (!replaced.equals(original)) {
                s.clear();
                s.append(replaced);
            }
            MonetarySpannable.applyMarkup(s, null, MonetarySpannable.STANDARD_SIGNIFICANT_SPANS,
                    MonetarySpannable.STANDARD_INSIGNIFICANT_SPANS);
        }
        @Override
        public void beforeTextChanged(final CharSequence s, final int start, final int count, final int after) {
        }
        @Override
        public void onTextChanged(final CharSequence s, final int start, final int before, final int count) {
            updateAppearance();
            if (listener != null && fire)
                listener.changed();
        }
        @Override
        public void onFocusChange(final View v, final boolean hasFocus) {
            if (!hasFocus) {
                final Monetary amount = getAmount();
                if (amount != null)
                    setAmount(amount, false);
            }
            if (listener != null && fire)
                listener.focusChanged(hasFocus);
        }
    }
