/*
 * Max3DSLoader.java 24 Nov. 2013
 *
 * Sweet Home 3D, Copyright (c) 2013 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.j3d;
/**
 * A loader for 3DS streams.<br> 
 * Mainly an adaptation in Java 3D of the GNU LGPL C library available at www.lib3ds.org.
 * Note: this class is compatible with Java 3D 1.3.
 * @author Emmanuel Puybaret
 */
private static class Face3DS {
    private int         index;
    private int []      vertexIndices;
    private int []      normalIndices;
    private Material3DS material;
    private Long        smoothingGroup;
    public Face3DS(int index,
                   int vertexAIndex,
                   int vertexBIndex,
                   int vertexCIndex, 
                   int flags) {
      this.index = index;
      this.vertexIndices = new int [] {vertexAIndex, vertexBIndex, vertexCIndex};
    }
    public int getIndex() {
      return this.index;
    }
    public int [] getVertexIndices() {
      return this.vertexIndices;
    }
    public void setNormalIndices(int [] normalIndices) {
      this.normalIndices = normalIndices;
    }
    public int [] getNormalIndices() {
      return this.normalIndices;
    }
    public void setMaterial(Material3DS material) {
      this.material = material;
    }
    public Material3DS getMaterial() {
      return this.material;
    }
    public void setSmoothingGroup(Long smoothingGroup) {
      this.smoothingGroup = smoothingGroup;
    }
    public Long getSmoothingGroup() {
      return this.smoothingGroup;
    }
  }
