/*
 * PlanController.java 2 juin 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import com.eteks.sweethome3d.model.Room;
/**
 * A MVC controller for the plan view.
 * @author Emmanuel Puybaret
 */
private class RoomAreaRotationState extends ControllerState {
    private static final int  STEP_COUNT = 24;
    private Room     selectedRoom;
    private float    oldAreaAngle;
    private float    angleMousePress;
    private boolean  magnetismEnabled;
    private boolean  alignmentActivated;
    @Override
    public Mode getMode() {
      return Mode.SELECTION;
    }
    @Override
    public boolean isModificationState() {
      return true;
    }
    @Override
    public void enter() {
      this.selectedRoom = (Room)home.getSelectedItems().get(0);
      this.angleMousePress = (float)Math.atan2(this.selectedRoom.getYCenter() + this.selectedRoom.getAreaYOffset() - getYLastMousePress(), 
          getXLastMousePress() - this.selectedRoom.getXCenter() - this.selectedRoom.getAreaXOffset()); 
      this.oldAreaAngle = this.selectedRoom.getAreaAngle();
      this.alignmentActivated = wasAlignmentActivatedLastMousePress();
      this.magnetismEnabled = preferences.isMagnetismEnabled()
          ^ wasMagnetismToggledLastMousePress();
      PlanView planView = getView();
      planView.setResizeIndicatorVisible(true);
    }
    @Override
    public void moveMouse(float x, float y) {
      if (x != this.selectedRoom.getXCenter() + this.selectedRoom.getAreaXOffset() 
          || y != this.selectedRoom.getYCenter() + this.selectedRoom.getAreaYOffset()) {
        // Compute the new angle of the room area      
        float angleMouseMove = (float)Math.atan2(this.selectedRoom.getYCenter() + this.selectedRoom.getAreaYOffset() - y, 
            x - this.selectedRoom.getXCenter() - this.selectedRoom.getAreaXOffset()); 
        float newAngle = this.oldAreaAngle - angleMouseMove + this.angleMousePress;
        if (this.alignmentActivated
            || this.magnetismEnabled) {
          float angleStep = 2 * (float)Math.PI / STEP_COUNT; 
          // Compute angles closest to a step angle (multiple of angleStep) 
          newAngle = Math.round(newAngle / angleStep) * angleStep;
        }
        // Update room area new angle
        this.selectedRoom.setAreaAngle(newAngle); 
        getView().makePointVisible(x, y);
      }
    }
    @Override
    public void releaseMouse(float x, float y) {
      postRoomAreaRotation(this.selectedRoom, this.oldAreaAngle);
      setState(getSelectionState());
    }
    @Override
    public void toggleMagnetism(boolean magnetismToggled) {
      // Compute active magnetism
      this.magnetismEnabled = preferences.isMagnetismEnabled()
                              ^ magnetismToggled;
      // Compute again angle as if mouse moved
      moveMouse(getXLastMouseMove(), getYLastMouseMove());
    }
    @Override
    public void setAlignmentActivated(boolean alignmentActivated) {
      this.alignmentActivated = alignmentActivated;
      moveMouse(getXLastMouseMove(), getYLastMouseMove());
    }
    @Override
    public void escape() {
      this.selectedRoom.setAreaAngle(this.oldAreaAngle);
      setState(getSelectionState());
    }
    @Override
    public void exit() {
      getView().setResizeIndicatorVisible(false);
      this.selectedRoom = null;
    }  
  }
