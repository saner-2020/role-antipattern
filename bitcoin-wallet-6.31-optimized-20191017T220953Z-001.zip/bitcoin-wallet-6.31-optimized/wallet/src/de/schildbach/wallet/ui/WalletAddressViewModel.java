/*
 * Copyright the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui;
import org.bitcoinj.core.Address;
import org.bitcoinj.uri.BitcoinURI;
import de.schildbach.wallet.WalletApplication;
import de.schildbach.wallet.data.ConfigOwnNameLiveData;
import de.schildbach.wallet.util.Qr;
import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.MediatorLiveData;
import android.arch.lifecycle.Observer;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
/**
 * @author Andreas Schildbach
 */
public class WalletAddressViewModel extends AndroidViewModel {
    private final WalletApplication application;
    public final CurrentAddressLiveData currentAddress;
    public final ConfigOwnNameLiveData ownName;
    public final MediatorLiveData<Bitmap> qrCode = new MediatorLiveData<>();
    public final MediatorLiveData<Uri> bitcoinUri = new MediatorLiveData<>();
    public WalletAddressViewModel(final Application application) {
        super(application);
        this.application = (WalletApplication) application;
        this.currentAddress = new CurrentAddressLiveData(this.application);
        this.ownName = new ConfigOwnNameLiveData(this.application);
        this.qrCode.addSource(currentAddress, new Observer<Address>() {
            @Override
            public void onChanged(final Address currentAddress) {
                maybeGenerateQrCode();
            }
        });
        this.qrCode.addSource(ownName, new Observer<String>() {
            @Override
            public void onChanged(final String label) {
                maybeGenerateQrCode();
            }
        });
        this.bitcoinUri.addSource(currentAddress, new Observer<Address>() {
            @Override
            public void onChanged(final Address currentAddress) {
                maybeGenerateBitcoinUri();
            }
        });
        this.bitcoinUri.addSource(ownName, new Observer<String>() {
            @Override
            public void onChanged(final String label) {
                maybeGenerateBitcoinUri();
            }
        });
    }
    private void maybeGenerateQrCode() {
        final Address address = currentAddress.getValue();
        if (address != null) {
            AsyncTask.execute(new Runnable() {
                @Override
                public void run() {
                    qrCode.postValue(Qr.bitmap(uri(address, ownName.getValue())));
                }
            });
        }
    }
    private void maybeGenerateBitcoinUri() {
        final Address address = currentAddress.getValue();
        if (address != null) {
            bitcoinUri.setValue(Uri.parse(uri(address, ownName.getValue())));
        }
    }
    private String uri(final Address address, final String label) {
        return BitcoinURI.convertToBitcoinURI(address, null, label, null);
    }
}
