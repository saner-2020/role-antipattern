/*
 * OBJLoader.java 10 f�vr. 2009
 *
 * Sweet Home 3D, Copyright (c) 2009 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.j3d;
import java.util.List;
/**
 * An OBJ + MTL loader. 
 * It supports the same features as {@link com.sun.j3d.loaders.objectfile.ObjectFile ObjectFile}
 * Java 3D class, expected for texture images format (supports only BMP, WBMP, GIF, JPEG and PNG format).
 * Compared to <code>ObjectFile</code>, this class supports transparency as defined in
 * <a href="http://local.wasp.uwa.edu.au/~pbourke/dataformats/mtl/">MTL file format</a> 
 * specifications, and doesn't oblige to define texture coordinate on all vertices 
 * when only one face needs such coordinates. Material description is stored in 
 * {@link OBJMaterial OBJMaterial} instances to be able to use additional OBJ information
 * in other circumstances.<br>
 * Note: this class is compatible with Java 3D 1.3.
 * @author Emmanuel Puybaret
 */
private static class Face extends Geometry {
    private int []  normalIndices;
    private boolean smooth;
    public Face(List<Integer> vertexIndices, 
                List<Integer> textureCoordinateIndices, 
                List<Integer> normalIndices,
                boolean       smooth,
                String        material) {
      super(vertexIndices, textureCoordinateIndices, material);
      this.smooth = smooth;
      if (normalIndices.size() != 0) {
        this.normalIndices = new int [normalIndices.size()];
        for (int i = 0; i < this.normalIndices.length; i++) {
          this.normalIndices [i] = normalIndices.get(i);
        }
      }
    }
    public boolean isSmooth() {
      return this.smooth;
    }
    public int [] getNormalIndices() {
      return this.normalIndices;
    }
    public boolean hasNormalIndices() {
      return this.normalIndices != null
          && this.normalIndices.length > 0;
    }
  }
