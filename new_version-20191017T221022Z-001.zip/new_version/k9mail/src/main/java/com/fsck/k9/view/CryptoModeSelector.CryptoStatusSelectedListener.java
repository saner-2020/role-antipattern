package com.fsck.k9.view;
interface CryptoStatusSelectedListener {
        void onCryptoStatusSelected(CryptoModeSelectorState type);
    }