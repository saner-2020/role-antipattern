/*
 * WallController.java 30 mai 07
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import java.util.List;
import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import com.eteks.sweethome3d.model.Home;
import com.eteks.sweethome3d.model.HomeTexture;
import com.eteks.sweethome3d.model.Selectable;
import com.eteks.sweethome3d.model.TextureImage;
import com.eteks.sweethome3d.model.UserPreferences;
/**
 * A MVC controller for wall view.
 * @author Emmanuel Puybaret
 */
private static class WallsModificationUndoableEdit extends AbstractUndoableEdit {
    private final Home             home;
    private final UserPreferences  preferences;
    private final List<Selectable> oldSelection;
    private final ModifiedWall []  modifiedWalls;
    private final float            newWallBaseboardThickness;
    private final float            newWallBaseboardHeight;
    private final Float            xStart;
    private final Float            yStart;
    private final Float            xEnd;
    private final Float            yEnd;
    private final WallPaint        leftSidePaint;
    private final Integer          leftSideColor;
    private final HomeTexture      leftSideTexture;
    private final Float            leftSideShininess;
    private final Boolean          leftSideBaseboardVisible;
    private final Float            leftSideBaseboardThickness;
    private final Float            leftSideBaseboardHeight;
    private final BaseboardChoiceController.BaseboardPaint leftSideBaseboardPaint;
    private final Integer          leftSideBaseboardColor;
    private final HomeTexture      leftSideBaseboardTexture;
    private final WallPaint        rightSidePaint;
    private final Integer          rightSideColor;
    private final HomeTexture      rightSideTexture;
    private final Float            rightSideShininess;
    private final Boolean          rightSideBaseboardVisible;
    private final Float            rightSideBaseboardThickness;
    private final Float            rightSideBaseboardHeight;
    private final BaseboardChoiceController.BaseboardPaint rightSideBaseboardPaint;
    private final Integer          rightSideBaseboardColor;
    private final HomeTexture      rightSideBaseboardTexture;
    private final TextureImage     pattern;
    private final boolean          modifiedTopColor;
    private final Integer          topColor;
    private final Float            height;
    private final Float            heightAtEnd;
    private final Float            thickness;
    private final Float            arcExtent;
    private WallsModificationUndoableEdit(Home home,
                                          UserPreferences preferences,
                                          List<Selectable> oldSelection, ModifiedWall [] modifiedWalls,
                                          float newWallBaseboardThickness, float newWallBaseboardHeight,
                                          Float xStart, Float yStart, Float xEnd, Float yEnd,
                                          WallPaint leftSidePaint, Integer leftSideColor, 
                                          HomeTexture leftSideTexture, Float leftSideShininess,
                                          Boolean leftSideBaseboardVisible, Float leftSideBaseboardThickness, Float leftSideBaseboardHeight, 
                                          BaseboardChoiceController.BaseboardPaint leftSideBaseboardPaint, Integer leftSideBaseboardColor, HomeTexture leftSideBaseboardTexture,
                                          WallPaint rightSidePaint, Integer rightSideColor, 
                                          HomeTexture rightSideTexture, Float rightSideShininess,
                                          Boolean rightSideBaseboardVisible, Float rightSideBaseboardThickness, Float rightSideBaseboardHeight, 
                                          BaseboardChoiceController.BaseboardPaint rightSideBaseboardPaint, Integer rightSideBaseboardColor, HomeTexture rightSideBaseboardTexture,
                                          TextureImage pattern,
                                          boolean modifiedTopColor,
                                          Integer topColor, 
                                          Float height,
                                          Float heightAtEnd,
                                          Float thickness,
                                          Float arcExtent) {
      this.home = home;
      this.preferences = preferences;
      this.oldSelection = oldSelection;
      this.modifiedWalls = modifiedWalls;
      this.newWallBaseboardThickness = newWallBaseboardThickness;
      this.newWallBaseboardHeight = newWallBaseboardHeight;
      this.xStart = xStart;
      this.yStart = yStart;
      this.xEnd = xEnd;
      this.yEnd = yEnd;
      this.leftSidePaint = leftSidePaint;
      this.leftSideColor = leftSideColor;
      this.leftSideShininess = leftSideShininess;
      this.leftSideBaseboardVisible = leftSideBaseboardVisible;
      this.leftSideBaseboardThickness = leftSideBaseboardThickness;
      this.leftSideBaseboardHeight = leftSideBaseboardHeight;
      this.leftSideBaseboardPaint = leftSideBaseboardPaint;
      this.leftSideBaseboardColor = leftSideBaseboardColor;
      this.leftSideBaseboardTexture = leftSideBaseboardTexture;
      this.rightSidePaint = rightSidePaint;
      this.rightSideColor = rightSideColor;
      this.rightSideTexture = rightSideTexture;
      this.leftSideTexture = leftSideTexture;
      this.rightSideShininess = rightSideShininess;
      this.rightSideBaseboardVisible = rightSideBaseboardVisible;
      this.rightSideBaseboardThickness = rightSideBaseboardThickness;
      this.rightSideBaseboardHeight = rightSideBaseboardHeight;
      this.rightSideBaseboardPaint = rightSideBaseboardPaint;
      this.rightSideBaseboardColor = rightSideBaseboardColor;
      this.rightSideBaseboardTexture = rightSideBaseboardTexture;
      this.pattern = pattern;
      this.modifiedTopColor = modifiedTopColor;
      this.topColor = topColor;
      this.height = height;
      this.heightAtEnd = heightAtEnd;
      this.thickness = thickness;
      this.arcExtent = arcExtent;
    }
    @Override
    public void undo() throws CannotUndoException {
      super.undo();
      undoModifyWalls(this.modifiedWalls); 
      this.home.setSelectedItems(this.oldSelection); 
    }
    @Override
    public void redo() throws CannotRedoException {
      super.redo();
      doModifyWalls(this.modifiedWalls, this.newWallBaseboardThickness, this.newWallBaseboardHeight,
          this.xStart, this.yStart, this.xEnd, this.yEnd, 
          this.leftSidePaint, this.leftSideColor, this.leftSideTexture, this.leftSideShininess, 
          this.leftSideBaseboardVisible, this.leftSideBaseboardThickness, this.leftSideBaseboardHeight, 
          this.leftSideBaseboardPaint, this.leftSideBaseboardColor, this.leftSideBaseboardTexture,
          this.rightSidePaint, this.rightSideColor, this.rightSideTexture, this.rightSideShininess,
          this.rightSideBaseboardVisible, this.rightSideBaseboardThickness, this.rightSideBaseboardHeight, 
          this.rightSideBaseboardPaint, this.rightSideBaseboardColor, this.rightSideBaseboardTexture,
          this.pattern, this.modifiedTopColor, this.topColor,
          this.height, this.heightAtEnd, this.thickness, this.arcExtent); 
      this.home.setSelectedItems(this.oldSelection); 
    }
    @Override
    public String getPresentationName() {
      return this.preferences.getLocalizedString(WallController.class, "undoModifyWallsName");
    }
  }
