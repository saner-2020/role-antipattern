/*
 * PlanComponent.java 2 juin 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
/**
 * A component displaying the plan of a home.
 * @author Emmanuel Puybaret
 */
public static class IndicatorType {
    // Don't qualify IndicatorType as an enumeration to be able to extend IndicatorType class
    public static final IndicatorType ROTATE        = new IndicatorType("ROTATE");
    public static final IndicatorType RESIZE        = new IndicatorType("RESIZE");
    public static final IndicatorType ELEVATE       = new IndicatorType("ELEVATE");
    public static final IndicatorType RESIZE_HEIGHT = new IndicatorType("RESIZE_HEIGHT");
    public static final IndicatorType CHANGE_POWER  = new IndicatorType("CHANGE_POWER");
    public static final IndicatorType MOVE_TEXT     = new IndicatorType("MOVE_TEXT");
    public static final IndicatorType ROTATE_TEXT   = new IndicatorType("ROTATE_TEXT");
    public static final IndicatorType ROTATE_PITCH  = new IndicatorType("ROTATE_PITCH");
    public static final IndicatorType ROTATE_ROLL   = new IndicatorType("ROTATE_ROLL");
    private final String name;
    protected IndicatorType(String name) {
      this.name = name;      
    }
    public final String name() {
      return this.name;
    }
    @Override
    public String toString() {
      return this.name;
    }
  }
