/*
 * Copyright 2014-2015 the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui.send;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.bitcoinj.protocols.payments.PaymentProtocol;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import de.schildbach.wallet.R;
import de.schildbach.wallet.data.PaymentIntent;
import de.schildbach.wallet.ui.InputParser;
import de.schildbach.wallet.util.Bluetooth;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
/**
 * @author Andreas Schildbach
 */
public final static class BluetoothRequestTask extends RequestPaymentRequestTask {
        private final BluetoothAdapter bluetoothAdapter;
        public BluetoothRequestTask(final Handler backgroundHandler, final ResultCallback resultCallback,
                final BluetoothAdapter bluetoothAdapter) {
            super(backgroundHandler, resultCallback);
            this.bluetoothAdapter = bluetoothAdapter;
        }
        @Override
        public void requestPaymentRequest(final String url) {
            super.backgroundHandler.post(new Runnable() {
                @Override
                public void run() {
                    log.info("trying to request payment request from {}", url);
                    final BluetoothDevice device = bluetoothAdapter
                            .getRemoteDevice(Bluetooth.decompressMac(Bluetooth.getBluetoothMac(url)));
                    try (final BluetoothSocket socket = device
                            .createInsecureRfcommSocketToServiceRecord(Bluetooth.PAYMENT_REQUESTS_UUID);
                            final OutputStream os = socket.getOutputStream();
                            final InputStream is = socket.getInputStream()) {
                        socket.connect();
                        log.info("connected to {}", url);
                        final CodedInputStream cis = CodedInputStream.newInstance(is);
                        final CodedOutputStream cos = CodedOutputStream.newInstance(os);
                        cos.writeInt32NoTag(0);
                        cos.writeStringNoTag(Bluetooth.getBluetoothQuery(url));
                        cos.flush();
                        final int responseCode = cis.readInt32();
                        if (responseCode == 200) {
                            new InputParser.BinaryInputParser(PaymentProtocol.MIMETYPE_PAYMENTREQUEST,
                                    cis.readBytes().toByteArray()) {
                                @Override
                                protected void handlePaymentIntent(final PaymentIntent paymentIntent) {
                                    log.info("received {} via bluetooth", paymentIntent);
                                    onPaymentIntent(paymentIntent);
                                }
                                @Override
                                protected void error(final int messageResId, final Object... messageArgs) {
                                    onFail(messageResId, messageArgs);
                                }
                            }.parse();
                        } else {
                            log.info("got bluetooth error {}", responseCode);
                            onFail(R.string.error_bluetooth, responseCode);
                        }
                    } catch (final IOException x) {
                        log.info("problem sending", x);
                        onFail(R.string.error_io, x.getMessage());
                    }
                }
            });
        }
    }
