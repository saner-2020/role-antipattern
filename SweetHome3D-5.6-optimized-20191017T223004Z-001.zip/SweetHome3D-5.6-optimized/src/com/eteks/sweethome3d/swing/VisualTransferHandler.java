/*
 * VisualTransferHandler.java 05 june 2009
 *
 * Sweet Home 3D, Copyright (c) 2009 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.awt.dnd.DragSource;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import javax.swing.JComponent;
import javax.swing.TransferHandler;
/**
 * Transfer handler with visual representation on systems that support it.
 * @author Emmanuel Puybaret
 */
public class VisualTransferHandler extends TransferHandler {
  private final DragGestureRecognizerWithVisualRepresentation dragGestureRecognizerWithVisualRepresentation = 
        new DragGestureRecognizerWithVisualRepresentation();
  /**
   * Causes the Swing drag support to be initiated with a drag icon if necessary. 
   * This method implements the expected behavior of <code>exportAsDrag</code> 
   * if <code>getVisualRepresentation</code> was used in <code>TransferHandler</code> implementation.  
   * As only Mac OS X supports drag image, the drag icon will actually appear only on this system.
   */
  public void exportAsDrag(JComponent source, InputEvent ev, int action) {
    int sourceActions = getSourceActions(source);
    int dragAction = sourceActions & action;
    if (DragSource.isDragImageSupported() 
        && dragAction != NONE 
        && (ev instanceof MouseEvent)) {
      this.dragGestureRecognizerWithVisualRepresentation.gestured(source, (MouseEvent)ev, sourceActions, dragAction);
    } else {
      super.exportAsDrag(source, ev, action);
    }
  }
  /**
   * A drag gesture recognizer that uses transfer handler visual representation.
   * See <code>TransferHandler$SwingDragGestureRecognizer</code> for original code. 
   */
  ;
  /**
   * A drag listener that uses transfer handler visual representation for drag image.
   * See <code>TransferHandler$DragHandler</code> for base code. 
   */
}
