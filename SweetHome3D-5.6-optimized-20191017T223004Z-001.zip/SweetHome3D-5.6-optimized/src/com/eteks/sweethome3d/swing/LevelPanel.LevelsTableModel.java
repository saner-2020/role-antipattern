/*
 * LevelPanel.java  27 oct 2011
 *
 * Sweet Home 3D, Copyright (c) 2011 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.table.AbstractTableModel;
import com.eteks.sweethome3d.model.Level;
import com.eteks.sweethome3d.viewcontroller.LevelController;
/**
 * Level editing panel.
 * @author Emmanuel Puybaret
 */
private static final class LevelsTableModel extends AbstractTableModel {
    private Level  [] levels;
    private String [] columnNames;
    private LevelsTableModel(final LevelController controller, String [] columnNames) {
      this.levels = controller.getLevels();
      this.columnNames = columnNames;
      controller.addPropertyChangeListener(LevelController.Property.LEVELS, new PropertyChangeListener() {
          public void propertyChange(PropertyChangeEvent ev) {
            levels = controller.getLevels();
            fireTableDataChanged();
          }
        });
    }
    public int getRowCount() {
      return this.levels.length;
    }
    public int getColumnCount() {
      return 4;
    }
    public Object getValueAt(int rowIndex, int columnIndex) {
      Level level = this.levels [this.levels.length - rowIndex - 1]; // List in reverse order
      switch (columnIndex) {
        case 0 : return level.getName();
        case 1 : return level.getElevation();
        case 2 :
          if (level.getElevation() == this.levels [0].getElevation()) {
            return null; // Don't display floor thickness of first levels 
          } else {
            return level.getFloorThickness();
          }
        case 3 : return level.getHeight();
        case 4 :
          // Use not visible 5th column to retrieve viewable information
          return level.isViewable(); 
      }
      return null;
    }
    @Override
    public String getColumnName(int column) {
      return this.columnNames [column];
    }
  }
