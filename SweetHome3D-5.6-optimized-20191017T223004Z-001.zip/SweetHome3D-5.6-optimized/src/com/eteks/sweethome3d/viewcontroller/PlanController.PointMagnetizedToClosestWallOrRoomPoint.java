/*
 * PlanController.java 2 juin 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import java.awt.geom.GeneralPath;
import java.awt.geom.Point2D;
import com.eteks.sweethome3d.model.Room;
/**
 * A MVC controller for the plan view.
 * @author Emmanuel Puybaret
 */
private class PointMagnetizedToClosestWallOrRoomPoint {
    private float   x;
    private float   y;
    private boolean magnetized;
    /**
     * Creates a point that applies magnetism to point (<code>x</code>, <code>y</code>).
     * If this point is close to a point of a wall corner or of a room, it will be initialiazed to its coordinates.
     */
    public PointMagnetizedToClosestWallOrRoomPoint(float x, float y) {
      this(null, -1, x, y);
    }
    public PointMagnetizedToClosestWallOrRoomPoint(Room editedRoom, int editedPointIndex, float x, float y) {
      float margin = PIXEL_MARGIN / getScale();
      // Find the closest wall point to (x,y)
      double smallestDistance = Double.MAX_VALUE;
      for (GeneralPath roomPath : getRoomPathsFromWalls()) {
        smallestDistance = updateMagnetizedPoint(-1, x, y,
            smallestDistance, getPathPoints(roomPath, false));
      }      
      for (Room room : getDetectableRoomsAtSelectedLevel()) {
        smallestDistance = updateMagnetizedPoint(room == editedRoom ? editedPointIndex : - 1, 
            x, y, smallestDistance, room.getPoints());
      }      
      this.magnetized = smallestDistance <= margin * margin;
      if (!this.magnetized) {
        // Don't magnetism if closest wall point is too far
        this.x = x;
        this.y = y;
      }
    }
    private double updateMagnetizedPoint(int editedPointIndex,
                                         float x, float y,
                                         double smallestDistance,
                                         float [][] points) {
      for (int i = 0; i < points.length; i++) {
        if (i != editedPointIndex) {
          double distance = Point2D.distanceSq(points [i][0], points [i][1], x, y);
          if (distance < smallestDistance) {
            this.x = points [i][0];
            this.y = points [i][1];
            smallestDistance = distance;
          }
        }
      }
      return smallestDistance;
    }
    /**
     * Returns the abscissa of end point computed with magnetism.
     */
    public float getX() {
      return this.x;
    }
    /**
     * Returns the ordinate of end point computed with magnetism.
     */
    public float getY() {
      return this.y;
    }
    public boolean isMagnetized() {
      return this.magnetized;
    }
  }
