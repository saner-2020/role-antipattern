/*
 * Max3DSLoader.java 24 Nov. 2013
 *
 * Sweet Home 3D, Copyright (c) 2013 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.j3d;
import javax.media.j3d.Texture;
import javax.vecmath.Color3f;
/**
 * A loader for 3DS streams.<br> 
 * Mainly an adaptation in Java 3D of the GNU LGPL C library available at www.lib3ds.org.
 * Note: this class is compatible with Java 3D 1.3.
 * @author Emmanuel Puybaret
 */
private static class Material3DS {
    private String  name;
    private Color3f ambientColor;
    private Color3f diffuseColor;
    private Color3f specularColor;
    private Float   shininess;
    private Float   transparency;
    private Texture texture;
    private boolean twoSided;
    public Material3DS(String name, Color3f ambientColor, Color3f diffuseColor, Color3f specularColor,
                       Float shininess, Float transparency, Texture texture, boolean twoSided) {
      this.name = name;
      this.ambientColor = ambientColor;
      this.diffuseColor = diffuseColor;
      this.specularColor = specularColor;
      this.shininess = shininess;
      this.transparency = transparency;
      this.texture = texture;
      this.twoSided = twoSided;
    }
    public String getName() {
      return this.name;
    }
    public boolean isTwoSided() {
      return this.twoSided;
    }
    public Color3f getAmbientColor() {
      return this.ambientColor;
    }
    public Color3f getDiffuseColor() {
      return this.diffuseColor;
    }
    public Color3f getSpecularColor() {
      return this.specularColor;
    }
    public Float getShininess() {
      return this.shininess;
    }
    public Float getTransparency() {
      return this.transparency;
    }
    public Texture getTexture() {
      return this.texture;
    }
  }
