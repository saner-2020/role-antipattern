/*
 * PlanController.java 2 juin 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
/**
 * A MVC controller for the plan view.
 * @author Emmanuel Puybaret
 */
protected static abstract class ControllerState {
    public void enter() {
    }
    public void exit() {
    }
    public abstract Mode getMode();
    public void setMode(Mode mode) {
    }
    public boolean isModificationState() {
      return false;
    }
    public boolean isBasePlanModificationState() {
      return false;
    }
    public void deleteSelection() {
    }
    public void escape() {
    }
    public void moveSelection(float dx, float dy) {
    }
    public void toggleMagnetism(boolean magnetismToggled) {
    }
    public void setAlignmentActivated(boolean alignmentActivated) {
    }
    public void setDuplicationActivated(boolean duplicationActivated) {
    }
    public void setEditionActivated(boolean editionActivated) {
    }
    public void updateEditableProperty(EditableProperty editableField, Object value) {
    }
    public void pressMouse(float x, float y, int clickCount, 
                           boolean shiftDown, boolean duplicationActivated) {
    }
    public void releaseMouse(float x, float y) {
    }
    public void moveMouse(float x, float y) {
    }
    public void zoom(float factor) {
    }
  }
