/*
 * Copyright the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui.monitor;
import de.schildbach.wallet.R;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
/**
 * @author Andreas Schildbach
 */
public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView ipView;
        private final TextView heightView;
        private final TextView versionView;
        private final TextView protocolView;
        private final TextView pingView;
        private ViewHolder(final View itemView) {
            super(itemView);
            ipView = (TextView) itemView.findViewById(R.id.peer_list_row_ip);
            heightView = (TextView) itemView.findViewById(R.id.peer_list_row_height);
            versionView = (TextView) itemView.findViewById(R.id.peer_list_row_version);
            protocolView = (TextView) itemView.findViewById(R.id.peer_list_row_protocol);
            pingView = (TextView) itemView.findViewById(R.id.peer_list_row_ping);
        }
    }
