package com.fsck.k9.provider;


public interface AccountColumns {
        /**
         * <P>Type: INTEGER</P>
         */
        String ACCOUNT_NUMBER = "accountNumber";
        /**
         * <P>Type: String</P>
         */
        String ACCOUNT_NAME = "accountName";


        String ACCOUNT_UUID = "accountUuid";
        String ACCOUNT_COLOR = "accountColor";
    }