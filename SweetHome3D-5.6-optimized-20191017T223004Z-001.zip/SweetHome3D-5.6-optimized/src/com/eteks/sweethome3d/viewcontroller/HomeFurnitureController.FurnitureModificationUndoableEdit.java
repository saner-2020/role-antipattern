/*
 * HomeFurnitureController.java 30 mai 07
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import java.math.BigDecimal;
import java.util.List;
import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import com.eteks.sweethome3d.model.Home;
import com.eteks.sweethome3d.model.HomeMaterial;
import com.eteks.sweethome3d.model.HomeTexture;
import com.eteks.sweethome3d.model.Selectable;
import com.eteks.sweethome3d.model.UserPreferences;
/**
 * A MVC controller for home furniture view.
 * @author Emmanuel Puybaret
 */
private static class FurnitureModificationUndoableEdit extends AbstractUndoableEdit {
    private final Home                        home;
    private final UserPreferences             preferences;
    private final ModifiedPieceOfFurniture [] modifiedFurniture;
    private final List<Selectable>            oldSelection;
    private final List<Selectable>            newSelection;
    private final String                      name;
    private final Boolean                     nameVisible;
    private final String                      description;
    private final BigDecimal                  price;
    private final Float                       x;
    private final Float                       y;
    private final Float                       elevation;
    private final Float                       angle;
    private final Float                       roll;
    private final Float                       pitch;
    private final FurnitureHorizontalAxis     horizontalAxis;
    private final Boolean                     basePlanItem;
    private final Float                       width;
    private final Float                       depth;
    private final Float                       height;
    private final boolean                     proportional;
    private final FurniturePaint              paint;
    private final Integer                     color;
    private final HomeTexture                 texture;
    private final HomeMaterial []             modelMaterials;
    private final boolean                     defaultShininess;
    private final Float                       shininess;
    private final Boolean                     visible;
    private final Boolean                     modelMirrored;
    private final Float                       lightPower;
    private FurnitureModificationUndoableEdit(Home home,
                                              UserPreferences preferences, 
                                              List<Selectable> oldSelection,
                                              List<Selectable> newSelection,
                                              ModifiedPieceOfFurniture [] modifiedFurniture,
                                              String name, Boolean nameVisible, String description, BigDecimal price, 
                                              Float x, Float y, Float elevation, 
                                              Float angle, Float roll, Float pitch, FurnitureHorizontalAxis horizontalAxis, Boolean basePlanItem, 
                                              Float width, Float depth, Float height, boolean proportional,
                                              FurniturePaint paint, Integer color, HomeTexture texture,
                                              HomeMaterial [] modelMaterials,
                                              boolean defaultShininess, Float shininess,
                                              Boolean visible,
                                              Boolean modelMirrored,
                                              Float lightPower) {
      this.home = home;
      this.preferences = preferences;
      this.oldSelection = oldSelection;
      this.newSelection = newSelection;
      this.modifiedFurniture = modifiedFurniture;
      this.name = name;
      this.nameVisible = nameVisible;
      this.description = description;
      this.price = price;
      this.x = x;
      this.y = y;
      this.elevation = elevation;
      this.angle = angle;
      this.roll = roll;
      this.pitch = pitch;
      this.horizontalAxis = horizontalAxis;
      this.basePlanItem = basePlanItem;
      this.width = width;
      this.depth = depth;
      this.height = height;
      this.proportional = proportional;
      this.paint = paint;
      this.color = color;
      this.texture = texture;
      this.modelMaterials = modelMaterials;
      this.defaultShininess = defaultShininess;
      this.shininess = shininess;
      this.visible = visible;
      this.modelMirrored = modelMirrored;
      this.lightPower = lightPower;
    }
    @Override
    public void undo() throws CannotUndoException {
      super.undo();
      undoModifyFurniture(this.modifiedFurniture);
      this.home.setSelectedItems(this.oldSelection); 
    }
    @Override
    public void redo() throws CannotRedoException {
      super.redo();
      doModifyFurniture(this.modifiedFurniture, 
          this.name, this.nameVisible, this.description, this.price, this.x, this.y, this.elevation, 
          this.angle, this.roll, this.pitch, this.horizontalAxis, this.basePlanItem, 
          this.width, this.depth, this.height, this.proportional,
          this.paint, this.color, this.texture, this.modelMaterials, 
          this.defaultShininess, this.shininess,
          this.visible, this.modelMirrored, this.lightPower); 
      this.home.setSelectedItems(this.newSelection); 
    }
    @Override
    public String getPresentationName() {
      return this.preferences.getLocalizedString(HomeFurnitureController.class, 
          "undoModifyFurnitureName");
    }
  }
