package com.fsck.k9.view;


public interface OnPageFinishedListener {
        void onPageFinished();
    }