/*
 * Base64.java
 * 
 * Light version of the Public Domain class available at http://iharder.net/base64 v2.3.7
 * 
 * This class and its modifications belong to Public Domain.
 */
package com.eteks.sweethome3d.io;
/**
 * <p>Encodes and decodes to and from Base64 notation.</p>
 * <p>Homepage: <a href="http://iharder.net/base64">http://iharder.net/base64</a>.</p>
 * 
 * <p>Example:</p>
 * 
 * <code>String encoded = Base64.encode( myByteArray );</code>
 * <br>
 * <code>byte[] myByteArray = Base64.decode( encoded );</code>
 *
 * <p>The <tt>options</tt> parameter, which appears in a few places, is used to pass 
 * several pieces of information to the encoder. In the "higher level" methods such as 
 * encodeBytes( bytes, options ) the options parameter can be used to indicate such 
 * things as first gzipping the bytes before encoding them, not inserting linefeeds,
 * and encoding using the URL-safe and Ordered dialects.</p>
 *
 * <p>Note, according to <a href="http://www.faqs.org/rfcs/rfc3548.html">RFC3548</a>,
 * Section 2.1, implementations should not add line feeds unless explicitly told
 * to do so. I've got Base64 set to this behavior now, although earlier versions
 * broke lines by default.</p>
 *
 * <p>The constants defined in Base64 can be OR-ed together to combine options, so you 
 * might make a call like this:</p>
 *
 * <code>String encoded = Base64.encodeBytes( mybytes, Base64.GZIP | Base64.DO_BREAK_LINES );</code>
 * <p>to compress the data before encoding it and then making the output have newline characters.</p>
 * <p>Also...</p>
 * <code>String encoded = Base64.encodeBytes( crazyString.getBytes() );</code>
 *
 * <p>
 * Change Log:
 * </p>
 * <ul>
 *  <li>v2.3.7 - Fixed subtle bug when base 64 input stream contained the
 *   value 01111111, which is an invalid base 64 character but should not
 *   throw an ArrayIndexOutOfBoundsException either. Led to discovery of
 *   mishandling (or potential for better handling) of other bad input
 *   characters. You should now get an IOException if you try decoding
 *   something that has bad characters in it.</li>
 *  <li>v2.3.6 - Fixed bug when breaking lines and the final byte of the encoded
 *   string ended in the last column; the buffer was not properly shrunk and
 *   contained an extra (null) byte that made it into the string.</li>
 *  <li>v2.3.5 - Fixed bug in <code>encodeFromFile</code> where estimated buffer size
 *   was wrong for files of size 31, 34, and 37 bytes.</li>
 *  <li>v2.3.4 - Fixed bug when working with gzipped streams whereby flushing
 *   the Base64.OutputStream closed the Base64 encoding (by padding with equals
 *   signs) too soon. Also added an option to suppress the automatic decoding
 *   of gzipped streams. Also added experimental support for specifying a
 *   class loader when using the <code>decodeToObject</code> method.</li>
 *  <li>v2.3.3 - Changed default char encoding to US-ASCII which reduces the internal Java
 *   footprint with its CharEncoders and so forth. Fixed some javadocs that were
 *   inconsistent. Removed imports and specified things like java.io.IOException
 *   explicitly inline.</li>
 *  <li>v2.3.2 - Reduced memory footprint! Finally refined the "guessing" of how big the
 *   final encoded data will be so that the code doesn't have to create two output
 *   arrays: an oversized initial one and then a final, exact-sized one. Big win
 *   when using the <code>encodeBytesToBytes(byte[])</code> family of methods (and not
 *   using the gzip options which uses a different mechanism with streams and stuff).</li>
 *  <li>v2.3.1 - Added {@link #encodeBytesToBytes(byte[], int, int, int)} and some
 *   similar helper methods to be more efficient with memory by not returning a
 *   String but just a byte array.</li>
 *  <li>v2.3 - <strong>This is not a drop-in replacement!</strong> This is two years of comments
 *   and bug fixes queued up and finally executed. Thanks to everyone who sent
 *   me stuff, and I'm sorry I wasn't able to distribute your fixes to everyone else.
 *   Much bad coding was cleaned up including throwing exceptions where necessary 
 *   instead of returning null values or something similar. Here are some changes
 *   that may affect you:
 *   <ul>
 *    <li><em>Does not break lines, by default.</em> This is to keep in compliance with
 *      <a href="http://www.faqs.org/rfcs/rfc3548.html">RFC3548</a>.</li>
 *    <li><em>Throws exceptions instead of returning null values.</em> Because some operations
 *      (especially those that may permit the GZIP option) use IO streams, there
 *      is a possiblity of an java.io.IOException being thrown. After some discussion and
 *      thought, I've changed the behavior of the methods to throw java.io.IOExceptions
 *      rather than return null if ever there's an error. I think this is more
 *      appropriate, though it will require some changes to your code. Sorry,
 *      it should have been done this way to begin with.</li>
 *    <li><em>Removed all references to System.out, System.err, and the like.</em>
 *      Shame on me. All I can say is sorry they were ever there.</li>
 *    <li><em>Throws NullPointerExceptions and IllegalArgumentExceptions</em> as needed
 *      such as when passed arrays are null or offsets are invalid.</li>
 *    <li>Cleaned up as much javadoc as I could to avoid any javadoc warnings.
 *      This was especially annoying before for people who were thorough in their
 *      own projects and then had gobs of javadoc warnings on this file.</li>
 *   </ul>
 *  <li>v2.2.1 - Fixed bug using URL_SAFE and ORDERED encodings. Fixed bug
 *   when using very small files (~&lt; 40 bytes).</li>
 *  <li>v2.2 - Added some helper methods for encoding/decoding directly from
 *   one file to the next. Also added a main() method to support command line
 *   encoding/decoding from one file to the next. Also added these Base64 dialects:
 *   <ol>
 *   <li>The default is RFC3548 format.</li>
 *   <li>Calling Base64.setFormat(Base64.BASE64_FORMAT.URLSAFE_FORMAT) generates
 *   URL and file name friendly format as described in Section 4 of RFC3548.
 *   http://www.faqs.org/rfcs/rfc3548.html</li>
 *   <li>Calling Base64.setFormat(Base64.BASE64_FORMAT.ORDERED_FORMAT) generates
 *   URL and file name friendly format that preserves lexical ordering as described
 *   in http://www.faqs.org/qa/rfcc-1940.html</li>
 *   </ol>
 *   Special thanks to Jim Kellerman at <a href="http://www.powerset.com/">http://www.powerset.com/</a>
 *   for contributing the new Base64 dialects.
 *  </li>
 * 
 *  <li>v2.1 - Cleaned up javadoc comments and unused variables and methods. Added
 *   some convenience methods for reading and writing to and from files.</li>
 *  <li>v2.0.2 - Now specifies UTF-8 encoding in places where the code fails on systems
 *   with other encodings (like EBCDIC).</li>
 *  <li>v2.0.1 - Fixed an error when decoding a single byte, that is, when the
 *   encoded data was a single byte.</li>
 *  <li>v2.0 - I got rid of methods that used booleans to set options. 
 *   Now everything is more consolidated and cleaner. The code now detects
 *   when data that's being decoded is gzip-compressed and will decompress it
 *   automatically. Generally things are cleaner. You'll probably have to
 *   change some method calls that you were making to support the new
 *   options format (<tt>int</tt>s that you "OR" together).</li>
 *  <li>v1.5.1 - Fixed bug when decompressing and decoding to a             
 *   byte[] using <tt>decode( String s, boolean gzipCompressed )</tt>.      
 *   Added the ability to "suspend" encoding in the Output Stream so        
 *   you can turn on and off the encoding if you need to embed base64       
 *   data in an otherwise "normal" stream (like an XML file).</li>  
 *  <li>v1.5 - Output stream pases on flush() command but doesn't do anything itself.
 *      This helps when using GZIP streams.
 *      Added the ability to GZip-compress objects before encoding them.</li>
 *  <li>v1.4 - Added helper methods to read/write files.</li>
 *  <li>v1.3.6 - Fixed OutputStream.flush() so that 'position' is reset.</li>
 *  <li>v1.3.5 - Added flag to turn on and off line breaks. Fixed bug in input stream
 *      where last buffer being read, if not completely full, was not returned.</li>
 *  <li>v1.3.4 - Fixed when "improperly padded stream" error was thrown at the wrong time.</li>
 *  <li>v1.3.3 - Fixed I/O streams which were totally messed up.</li>
 * </ul>
 *
 * <p>
 * I am placing this code in the Public Domain. Do with it as you will.
 * This software comes with no guarantees or warranties but with
 * plenty of well-wishing instead!
 * Please visit <a href="http://iharder.net/base64">http://iharder.net/base64</a>
 * periodically to check for updates or to contribute improvements.
 * </p>
 *
 * @author Robert Harder
 * @author rob@iharder.net
 * @version 2.3.7
 */
   // end class Base64
private static class OutputStream extends java.io.FilterOutputStream {
    private boolean encode;
    private int     position;
    private byte[]  buffer;
    private int     bufferLength;
    private int     lineLength;
    private boolean breakLines;
    private byte[]  b4;         // Scratch used in a few places
    private boolean suspendEncoding;
    private int     options;    // Record for later
    private byte[]  decodabet;  // Local copies to avoid extra method calls
    /**
     * Constructs a {@link Base64.OutputStream} in
     * either ENCODE or DECODE mode.
     * <p>
     * Valid options:<pre>
     *   ENCODE or DECODE: Encode or Decode as data is read.
     *   DO_BREAK_LINES: don't break lines at 76 characters
     *     (only meaningful when encoding)</i>
     * </pre>
     * <p>
     * Example: <code>new Base64.OutputStream( out, Base64.ENCODE )</code>
     *
     * @param out the <tt>java.io.OutputStream</tt> to which data will be written.
     * @param options Specified options.
     * @see Base64#ENCODE
     * @see Base64#DECODE
     * @see Base64#DO_BREAK_LINES
     * @since 1.3
     */
    public OutputStream(java.io.OutputStream out, int options) {
      super(out);
      this.breakLines   = (options & DO_BREAK_LINES) != 0;
      this.encode       = (options & ENCODE) != 0;
      this.bufferLength = encode ? 3 : 4;
      this.buffer       = new byte[ bufferLength ];
      this.position     = 0;
      this.lineLength   = 0;
      this.suspendEncoding = false;
      this.b4           = new byte[4];
      this.options      = options;
      this.decodabet    = getDecodabet(options);
    } // end constructor
    /**
     * Writes the byte to the output stream after
     * converting to/from Base64 notation.
     * When encoding, bytes are buffered three
     * at a time before the output stream actually
     * gets a write() call.
     * When decoding, bytes are buffered four
     * at a time.
     *
     * @param theByte the byte to write
     * @since 1.3
     */
    @Override
    public void write(int theByte) throws java.io.IOException {
      // Encoding suspended?
      if (suspendEncoding) {
        this.out.write(theByte);
        return;
      } // end if: supsended
      // Encode?
      if (encode) {
        buffer [position++] = (byte)theByte;
        if (position >= bufferLength) { // Enough to encode.
          this.out.write(encode3to4(b4, buffer, bufferLength, options));
          lineLength += 4;
          if (breakLines && lineLength >= MAX_LINE_LENGTH) {
            this.out.write(NEW_LINE);
            lineLength = 0;
          } // end if: end of line
          position = 0;
        } // end if: enough to output
      } // end if: encoding
      // Else, Decoding
      else {
        // Meaningful Base64 character?
        if (decodabet [theByte & 0x7f] > WHITE_SPACE_ENC) {
          buffer [position++] = (byte)theByte;
          if (position >= bufferLength) { // Enough to output.
            int len = Base64.decode4to3(buffer, 0, b4, 0, options);
            out.write(b4, 0, len);
            position = 0;
          } // end if: enough to output
        } // end if: meaningful base64 character
        else if (decodabet [theByte & 0x7f] != WHITE_SPACE_ENC) {
          throw new java.io.IOException("Invalid character in Base64 data.");
        } // end else: not white space either
      } // end else: decoding
    } // end write
    /**
     * Calls {@link #write(int)} repeatedly until <var>len</var> 
     * bytes are written.
     *
     * @param theBytes array from which to read bytes
     * @param off offset for array
     * @param len max number of bytes to read into array
     * @since 1.3
     */
    @Override
    public void write( byte[] theBytes, int off, int len ) 
    throws java.io.IOException {
      // Encoding suspended?
      if (suspendEncoding) {
        this.out.write(theBytes, off, len);
        return;
      } // end if: supsended
      for (int i = 0; i < len; i++) {
        write(theBytes [off + i]);
      } // end for: each byte written
    }   // end write
    /**
     * Method added by PHIL. [Thanks, PHIL. -Rob]
     * This pads the buffer without closing the stream.
     * @throws java.io.IOException  if there's an error.
     */
    public void flushBase64() throws java.io.IOException  {
      if (position > 0) {
        if (encode) {
          out.write(encode3to4(b4, buffer, position, options));
          position = 0;
        } // end if: encoding
        else {
          throw new java.io.IOException("Base64 input not properly padded.");
        } // end else: decoding
      } // end if: buffer partially full
    }   // end flush
    /** 
     * Flushes and closes (I think, in the superclass) the stream. 
     *
     * @since 1.3
     */
    @Override
    public void close() throws java.io.IOException {
      // 1. Ensure that pending characters are written
      flushBase64();
      // 2. Actually close the stream
      // Base class both flushes and closes.
      super.close();
      buffer = null;
      out = null;
    } // end close
  }
