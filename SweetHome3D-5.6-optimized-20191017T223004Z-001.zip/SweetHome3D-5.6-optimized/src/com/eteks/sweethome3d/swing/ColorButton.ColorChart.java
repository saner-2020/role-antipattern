/*
 * ColorButton.java 29 mai 07
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.MouseEvent;
import javax.swing.JComponent;
/**
 * Button displaying a color as an icon.
 */
private static final class ColorChart extends JComponent {
    @Override
    protected void paintComponent(Graphics g) {          
      Insets insets = getInsets();
      for (int x = insets.left, n = getWidth() - insets.right; x < n; x++) {
        for (int y = insets.top, m = getHeight() - insets.bottom; y < m; y++) {
          g.setColor(getColorAt(x, y));
          g.fillRect(x, y, 1, 1);
        }
      }
    }
    @Override
    public Dimension getPreferredSize() {
      Insets insets = getInsets();
      return new Dimension(Math.round(256 * SwingTools.getResolutionScale()) + insets.right + insets.left, 
          Math.round(128 * SwingTools.getResolutionScale()) + insets.bottom + insets.top);
    }
    public Color getColorAt(int x, int y) {
      Insets insets = getInsets();
      x = Math.min(Math.max(0, x - insets.left), getWidth() - insets.right - 1);
      y = Math.min(Math.max(0, y - insets.top), getHeight() - insets.bottom - 1);
      int drawnWidth = getWidth() - insets.right - insets.left;
      int drawnHeight = getHeight() - insets.bottom - insets.top;
      if (y < drawnHeight / 2) {
        return Color.getHSBColor((float)x / (drawnWidth - 1), 1, (float)y / (drawnHeight - 1) * 2);
      } else {
        return Color.getHSBColor((float)x / (drawnWidth - 1), (float)(drawnHeight - 1 - y) / (drawnHeight - 1) * 2, 1);
      }
    }
    @Override
    public String getToolTipText(MouseEvent ev) {
      String color = String.format("#%6X", getColorAt(ev.getX(), ev.getY()).getRGB() & 0xFFFFFF).replace(' ', '0');
      return "<html><table><td width='50' height='50' bgcolor='" + color + "'></td></tr>"
          + "<tr><td align='center'>" + color + "</td></tr>";
    }
  }
