/*
 * PlanController.java 2 juin 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import com.eteks.sweethome3d.model.Room;
/**
 * A MVC controller for the plan view.
 * @author Emmanuel Puybaret
 */
private class RoomAreaOffsetState extends ControllerState {
    private Room    selectedRoom;
    private float   oldAreaXOffset;
    private float   oldAreaYOffset;
    private float   xLastMouseMove;
    private float   yLastMouseMove;
    private boolean alignmentActivated;
    @Override
    public Mode getMode() {
      return Mode.SELECTION;
    }
    @Override
    public boolean isModificationState() {
      return true;
    }
    @Override
    public void enter() {
      this.selectedRoom = (Room)home.getSelectedItems().get(0);
      this.oldAreaXOffset = this.selectedRoom.getAreaXOffset();
      this.oldAreaYOffset = this.selectedRoom.getAreaYOffset();
      this.xLastMouseMove = getXLastMousePress();
      this.yLastMouseMove = getYLastMousePress();
      this.alignmentActivated = wasAlignmentActivatedLastMousePress();
      PlanView planView = getView();
      planView.setResizeIndicatorVisible(true);
    }
    @Override
    public void moveMouse(float x, float y) {
      if (this.alignmentActivated) {
        PointWithAngleMagnetism alignedPoint = new PointWithAngleMagnetism(
            this.selectedRoom.getXCenter() + this.oldAreaXOffset, 
            this.selectedRoom.getYCenter() + this.oldAreaYOffset, 
            x, y, preferences.getLengthUnit(), getView().getPixelLength(), 4);
        x = alignedPoint.getX();
        y = alignedPoint.getY();
      }
      this.selectedRoom.setAreaXOffset(this.selectedRoom.getAreaXOffset() + x - this.xLastMouseMove);
      this.selectedRoom.setAreaYOffset(this.selectedRoom.getAreaYOffset() + y - this.yLastMouseMove);
      this.xLastMouseMove = x;
      this.yLastMouseMove = y;
      // Ensure point at (x,y) is visible
      getView().makePointVisible(x, y);
    }
    @Override
    public void releaseMouse(float x, float y) {
      postRoomAreaOffset(this.selectedRoom, this.oldAreaXOffset, this.oldAreaYOffset);
      setState(getSelectionState());
    }
    @Override
    public void setAlignmentActivated(boolean alignmentActivated) {
      this.alignmentActivated = alignmentActivated;
      moveMouse(getXLastMouseMove(), getYLastMouseMove());
    }
    @Override
    public void escape() {
      this.selectedRoom.setAreaXOffset(this.oldAreaXOffset);
      this.selectedRoom.setAreaYOffset(this.oldAreaYOffset);
      setState(getSelectionState());
    }
    @Override
    public void exit() {
      getView().setResizeIndicatorVisible(false);
      this.selectedRoom = null;
    }  
  }
