/*
 * VideoPanel.java 15 fevr. 2010
 *
 * Sweet Home 3D, Copyright (c) 2010 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InterruptedIOException;
import com.eteks.sweethome3d.j3d.PhotoRenderer;
import com.eteks.sweethome3d.model.Camera;
import com.eteks.sweethome3d.model.Home;
import com.eteks.sweethome3d.viewcontroller.Object3DFactory;
/**
 * A panel used for video creation. 
 * @author Emmanuel Puybaret
 */
private static class PhotoImageGenerator extends FrameGenerator {
    private PhotoRenderer renderer;
    private BufferedImage image;
    public PhotoImageGenerator(Home home, int width, int height,
                               Object3DFactory object3dFactory,
                               PhotoRenderer.Quality quality) throws IOException {
      this.renderer = new PhotoRenderer(home, object3dFactory, quality); 
      this.image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
    }
    public BufferedImage renderImageAt(Camera frameCamera, boolean last) throws IOException {
      try {
        checkLaunchingThreadIsntInterrupted();
        this.renderer.render(this.image, frameCamera, null);   
        checkLaunchingThreadIsntInterrupted();
        return image;
      } catch(InterruptedIOException ex) {
        this.renderer = null;
        throw ex;
      } finally {
        if (last) {
          this.renderer.dispose();
          this.renderer = null;
        }
      }
    }
  }
