package com.fsck.k9.activity.compose;


public interface OnOpenPgpInlineChangeListener {
        void onOpenPgpInlineChange(boolean enabled);
    }