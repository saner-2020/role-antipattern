/*
 * PlanController.java 2 juin 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import java.util.Arrays;
import java.util.List;
import com.eteks.sweethome3d.model.LengthUnit;
import com.eteks.sweethome3d.model.Polyline;
import com.eteks.sweethome3d.model.Selectable;
/**
 * A MVC controller for the plan view.
 * @author Emmanuel Puybaret
 */
private class PolylineDrawingState extends AbstractPolylineState {
    private float            xPreviousPoint;
    private float            yPreviousPoint;
    private Polyline         newPolyline;
    private float []         newPoint;
    private List<Selectable> oldSelection;
    private boolean          oldBasePlanLocked;
    private boolean          oldAllLevelsSelection;
    private boolean          magnetismEnabled;
    private boolean          alignmentActivated;
    private boolean          curvedPolyline;
    private long             lastPointCreationTime;
    @Override
    public Mode getMode() {
      return Mode.POLYLINE_CREATION;
    }
    @Override
    public boolean isModificationState() {
      return true;
    }
    @Override
    public boolean isBasePlanModificationState() {
      return true;
    }
    @Override
    public void setMode(Mode mode) {
      // Escape current creation and change state to matching mode
      escape();
      if (mode == Mode.SELECTION) {
        setState(getSelectionState());
      } else if (mode == Mode.PANNING) {
        setState(getPanningState());
      } else if (mode == Mode.WALL_CREATION) {
        setState(getWallCreationState());
      } else if (mode == Mode.ROOM_CREATION) {
        setState(getRoomCreationState());
      } else if (mode == Mode.DIMENSION_LINE_CREATION) {
        setState(getDimensionLineCreationState());
      } else if (mode == Mode.LABEL_CREATION) {
        setState(getLabelCreationState());
      } 
    }
    @Override
    public void enter() {
      super.enter();
      this.oldSelection = home.getSelectedItems();
      this.oldBasePlanLocked = home.isBasePlanLocked();
      this.oldAllLevelsSelection = home.isAllLevelsSelection();
      this.newPolyline = null;
      this.alignmentActivated = wasAlignmentActivatedLastMousePress();
      toggleMagnetism(wasMagnetismToggledLastMousePress());
      this.xPreviousPoint = getXLastMousePress();
      this.yPreviousPoint = getYLastMousePress();
      setDuplicationActivated(wasDuplicationActivatedLastMousePress());
      deselectAll();
    }
    @Override
    public void moveMouse(float x, float y) {
      PlanView planView = getView();
      // Compute the coordinates where current edit polyline point should be moved
      float xEnd = x;
      float yEnd = y;
      if (this.alignmentActivated 
          || this.magnetismEnabled) {
        PointWithAngleMagnetism pointWithAngleMagnetism = new PointWithAngleMagnetism(
            this.xPreviousPoint, this.yPreviousPoint, x, y, preferences.getLengthUnit(), planView.getPixelLength());
        xEnd = pointWithAngleMagnetism.getX();
        yEnd = pointWithAngleMagnetism.getY();
      } 
      // If current polyline doesn't exist
      if (this.newPolyline == null) {
        // Create a new one
        this.newPolyline = createAndSelectPolyline(this.xPreviousPoint, this.yPreviousPoint, xEnd, yEnd);
      } else if (this.newPoint != null) {
        // Add a point to current polyline
        float [][] points = this.newPolyline.getPoints();
        this.xPreviousPoint = points [points.length - 1][0];
        this.yPreviousPoint = points [points.length - 1][1]; 
        this.newPolyline.addPoint(xEnd, yEnd);
        this.newPoint [0] = xEnd; 
        this.newPoint [1] = yEnd; 
        this.newPoint = null;
      } else {
        // Otherwise update its last point
        this.newPolyline.setPoint(xEnd, yEnd, this.newPolyline.getPointCount() - 1);
      }         
      planView.setAlignmentFeedback(Polyline.class, null, x, y, false);
      planView.setToolTipFeedback(
          getToolTipFeedbackText(this.newPolyline, this.newPolyline.getPointCount() - 1), x, y);
      if (this.newPolyline.getJoinStyle() != Polyline.JoinStyle.CURVED) {
        showPolylineAngleFeedback(this.newPolyline, this.newPolyline.getPointCount() - 1);
      }
      // Ensure point at (x,y) is visible
      planView.makePointVisible(x, y);
    }
    /**
     * Returns a new polyline instance with one segment between (<code>xStart</code>,
     * <code>yStart</code>) and (<code>xEnd</code>, <code>yEnd</code>) points. 
     * The new polyline is added to home and selected
     */
    private Polyline createAndSelectPolyline(float xStart, float yStart,
                                     float xEnd, float yEnd) {
      Polyline newPolyline = createPolyline(new float [][] {{xStart, yStart}, {xEnd, yEnd}});
      if (this.curvedPolyline) {
        newPolyline.setJoinStyle(Polyline.JoinStyle.CURVED);
      }
      selectItems(Arrays.asList(new Selectable [] {newPolyline}));      
      return newPolyline;
    }
    @Override
    public void pressMouse(float x, float y, int clickCount, 
                           boolean shiftDown, boolean duplicationActivated) {
      if (clickCount == 2) {
        if (this.newPolyline != null) {
          int pointIndex = this.newPolyline.getPointIndexAt(x, y, PIXEL_MARGIN / getScale());
          if (pointIndex == 0) {
            this.newPolyline.removePoint(this.newPolyline.getPointCount() - 1);
            this.newPolyline.setClosedPath(true);
          }
          validateDrawnPolyline();
        } else {
          setState(getPolylineCreationState());
        }
      } else {
        endPolylineSegment();
      }
    }
    private void validateDrawnPolyline() {
      if (this.newPolyline != null) {
        float [][] points = this.newPolyline.getPoints();
        if (points.length < 2) {
          // Delete current created polyline if it doesn't have more than 2 clicked points
          home.deletePolyline(this.newPolyline);
        } else {
          // Post polyline creation to undo support
          postCreatePolylines(Arrays.asList(new Polyline [] {this.newPolyline}), 
              this.oldSelection, this.oldBasePlanLocked, this.oldAllLevelsSelection);
        }
      }
      // Change state to PolylineCreationState 
      setState(getPolylineCreationState());
    }
    private void endPolylineSegment() {
      // Create a new polyline segment only when its length is greater than zero
      if (this.newPolyline != null
          && getPolylineSegmentLength(this.newPolyline, this.newPolyline.getPointCount() - 1) > 0) {    
        this.newPoint = new float [2];
        if (this.newPolyline.getPointCount() <= 2
            && this.curvedPolyline
            && newPolyline.getJoinStyle() != Polyline.JoinStyle.CURVED) {
          // Give a second chance to create a curved polyline
          newPolyline.setJoinStyle(Polyline.JoinStyle.CURVED);
        }
      }
    }
    @Override
    public void setEditionActivated(boolean editionActivated) {
      PlanView planView = getView();
      if (editionActivated) {
        planView.deleteFeedback();
        if (this.newPolyline == null) {
          // Edit xStart and yStart
          planView.setToolTipEditedProperties(new EditableProperty [] {EditableProperty.X,
                                                                       EditableProperty.Y},
              new Object [] {this.xPreviousPoint, this.yPreviousPoint},
              this.xPreviousPoint, this.yPreviousPoint);
        } else {
          if (this.newPoint != null) {
            // May happen if edition is activated after the user clicked to add a new point 
            createNextSegment();            
          }
          // Edit length and angle
          float [][] points = this.newPolyline.getPoints();
          planView.setToolTipEditedProperties(new EditableProperty [] {EditableProperty.LENGTH,
                                                                       EditableProperty.ANGLE},
              new Object [] {getPolylineSegmentLength(this.newPolyline, points.length - 1), 
                             getPolylineSegmentAngle(this.newPolyline, points.length - 1)},
              points [points.length - 1][0], points [points.length - 1][1]);
        }
      } else { 
        if (this.newPolyline == null) {
          // Create a new segment once user entered the start point of the polyline 
          LengthUnit lengthUnit = preferences.getLengthUnit();
          float defaultLength = lengthUnit == LengthUnit.INCH || lengthUnit == LengthUnit.INCH_DECIMALS
              ? LengthUnit.footToCentimeter(10) : 300;
          this.newPolyline = createAndSelectPolyline(this.xPreviousPoint, this.yPreviousPoint, 
              this.xPreviousPoint + defaultLength, this.yPreviousPoint);
          // Activate automatically second step to let user enter the 
          // length and angle of the new segment
          planView.deleteFeedback();
          setEditionActivated(true);
        } else if (System.currentTimeMillis() - this.lastPointCreationTime < 300) {
          // If the user deactivated edition less than 300 ms after activation, 
          // escape current segment creation
          escape();
        } else {
          endPolylineSegment();
          float [][] points = this.newPolyline.getPoints();
          // If last edited point matches first point validate drawn polyline 
          if (points.length > 2 
              && this.newPolyline.getPointIndexAt(points [points.length - 1][0], points [points.length - 1][1], 0.001f) == 0) {
            // Remove last currently edited point and close path
            this.newPolyline.removePoint(this.newPolyline.getPointCount() - 1);
            this.newPolyline.setClosedPath(true);
            validateDrawnPolyline();
            return;
          }
          createNextSegment();
          // Reactivate automatically second step
          planView.deleteToolTipFeedback();
          setEditionActivated(true);
        }
      }
    }
    private void createNextSegment() {
      // Add a point to current polyline
      float [][] points = this.newPolyline.getPoints();
      this.xPreviousPoint = points [points.length - 1][0];
      this.yPreviousPoint = points [points.length - 1][1]; 
      // Create a new segment with an angle equal to previous segment angle - 90�
      double previousSegmentAngle = Math.PI - Math.atan2(points [points.length - 2][1] - points [points.length - 1][1], 
          points [points.length - 2][0] - points [points.length - 1][0]);
      previousSegmentAngle -=  Math.PI / 2;
      float previousSegmentLength = getPolylineSegmentLength(this.newPolyline, points.length - 1); 
      this.newPolyline.addPoint(
          (float)(this.xPreviousPoint + previousSegmentLength * Math.cos(previousSegmentAngle)),
          (float)(this.yPreviousPoint - previousSegmentLength * Math.sin(previousSegmentAngle)));
      this.newPoint = null;
      this.lastPointCreationTime = System.currentTimeMillis();
    }
    @Override
    public void updateEditableProperty(EditableProperty editableProperty, Object value) {
      PlanView planView = getView();
      if (this.newPolyline == null) {
        // Update start point of the first wall
        switch (editableProperty) {
          case X : 
            this.xPreviousPoint = value != null ? ((Number)value).floatValue() : 0;
            this.xPreviousPoint = Math.max(-100000f, Math.min(this.xPreviousPoint, 100000f));
            break;      
          case Y : 
            this.yPreviousPoint = value != null ? ((Number)value).floatValue() : 0;
            this.yPreviousPoint = Math.max(-100000f, Math.min(this.yPreviousPoint, 100000f));
            break;      
        }
        planView.setAlignmentFeedback(Polyline.class, null, this.xPreviousPoint, this.yPreviousPoint, true);
        planView.makePointVisible(this.xPreviousPoint, this.yPreviousPoint);
      } else {
        float [][] points = this.newPolyline.getPoints();
        float [] previousPoint = points [points.length - 2];
        float [] point = points [points.length - 1];
        float newX;
        float newY;
        // Update end point of the current polyline
        switch (editableProperty) {
          case LENGTH : 
            float length = value != null ? ((Number)value).floatValue() : 0;
            length = Math.max(0.001f, Math.min(length, preferences.getLengthUnit().getMaximumLength()));
            double segmentAngle = Math.PI - Math.atan2(previousPoint [1] - point [1], 
                previousPoint [0] - point [0]);
            newX = (float)(previousPoint [0] + length * Math.cos(segmentAngle));
            newY = (float)(previousPoint [1] - length * Math.sin(segmentAngle));
            break;      
          case ANGLE : 
            segmentAngle = Math.toRadians(value != null ? ((Number)value).floatValue() : 0);
            if (points.length > 2) {
              segmentAngle -= Math.atan2(points [points.length - 3][1] - previousPoint [1], 
                  points [points.length - 3][0] - previousPoint [0]);
            }
            float segmentLength = getPolylineSegmentLength(this.newPolyline, points.length - 1);              
            newX = (float)(previousPoint [0] + segmentLength * Math.cos(segmentAngle));
            newY = (float)(previousPoint [1] - segmentLength * Math.sin(segmentAngle));
            break;
          default :
            return;
        }
        this.newPolyline.setPoint(newX, newY, points.length - 1);
        if (this.newPolyline.getJoinStyle() != Polyline.JoinStyle.CURVED) {
          showPolylineAngleFeedback(this.newPolyline, points.length - 1);
        }
        planView.setAlignmentFeedback(Polyline.class, null, newX, newY, false);
        // Ensure polyline segment points are visible
        planView.makePointVisible(points [points.length - 2][0], points [points.length - 2][1]);
        planView.makePointVisible(points [points.length - 1][0], points [points.length - 1][1]);
      }
    }
    @Override
    public void toggleMagnetism(boolean magnetismToggled) {
      // Compute active magnetism
      this.magnetismEnabled = preferences.isMagnetismEnabled()
                              ^ magnetismToggled;
      if (this.newPolyline != null) {
        moveMouse(getXLastMouseMove(), getYLastMouseMove());
      }
    }
    @Override
    public void setAlignmentActivated(boolean alignmentActivated) {
      this.alignmentActivated = alignmentActivated;
      moveMouse(getXLastMouseMove(), getYLastMouseMove());
    }
    @Override
    public void setDuplicationActivated(boolean duplicationActivated) {
      // Reuse duplication activation for curved polyline creation
      this.curvedPolyline = duplicationActivated;
    }
    @Override
    public void escape() {
      if (this.newPolyline != null
          && this.newPoint == null) {
        // Remove last currently edited point.
        this.newPolyline.removePoint(this.newPolyline.getPointCount() - 1);
      }
      validateDrawnPolyline();
    }
    @Override
    public void exit() {
      getView().deleteFeedback();
      this.newPolyline = null;
      this.newPoint = null;
      this.oldSelection = null;
    }  
  }
