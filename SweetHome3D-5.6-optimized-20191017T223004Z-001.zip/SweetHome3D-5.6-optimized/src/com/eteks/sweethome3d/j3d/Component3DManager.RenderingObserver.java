/*
 * Canvas3DManager.java 25 oct. 07
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.j3d;
import javax.media.j3d.Canvas3D;
/**
 * Manager of <code>Canvas3D</code> instantiations and Java 3D error listeners.
 * Note: this class is compatible with Java 3D 1.3 at runtime but requires Java 3D 1.5 to compile.
 * @author Emmanuel Puybaret
 */
public static interface RenderingObserver {
    /**
     * Called before <code>canvas3D</code> is rendered.
     */
    public void canvas3DPreRendered(Canvas3D canvas3D); 
    /**
     * Called after <code>canvas3D</code> is rendered.
     */
    public void canvas3DPostRendered(Canvas3D canvas3D); 
    /**
     * Called after <code>canvas3D</code> buffer is swapped.
     */
    public void canvas3DSwapped(Canvas3D canvas3D); 
  }
