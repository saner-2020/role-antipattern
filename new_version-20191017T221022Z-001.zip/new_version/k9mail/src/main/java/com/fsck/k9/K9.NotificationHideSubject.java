package com.fsck.k9;


public enum NotificationHideSubject {
        ALWAYS,
        WHEN_LOCKED,
        NEVER
    }