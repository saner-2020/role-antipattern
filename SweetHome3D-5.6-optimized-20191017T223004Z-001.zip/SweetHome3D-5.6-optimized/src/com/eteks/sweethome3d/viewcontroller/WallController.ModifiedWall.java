/*
 * WallController.java 30 mai 07
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import com.eteks.sweethome3d.model.Baseboard;
import com.eteks.sweethome3d.model.HomeTexture;
import com.eteks.sweethome3d.model.TextureImage;
import com.eteks.sweethome3d.model.Wall;
/**
 * A MVC controller for wall view.
 * @author Emmanuel Puybaret
 */
private static final class ModifiedWall {
    private final Wall         wall;
    private final float        xStart;
    private final float        yStart;
    private final float        xEnd;
    private final float        yEnd;
    private final Integer      leftSideColor;
    private final HomeTexture  leftSideTexture;
    private final float        leftSideShininess;
    private final Baseboard    leftSideBaseboard;
    private final Integer      rightSideColor;
    private final HomeTexture  rightSideTexture;
    private final float        rightSideShininess;
    private final Baseboard    rightSideBaseboard;
    private final TextureImage pattern;
    private final Integer      topColor;
    private final Float        height;
    private final Float        heightAtEnd;
    private final float        thickness;
    private final Float        arcExtent;
    public ModifiedWall(Wall wall) {
      this.wall = wall;
      this.xStart = wall.getXStart();
      this.yStart = wall.getYStart();
      this.xEnd = wall.getXEnd();
      this.yEnd = wall.getYEnd();
      this.leftSideColor = wall.getLeftSideColor();
      this.leftSideTexture = wall.getLeftSideTexture();
      this.leftSideShininess = wall.getLeftSideShininess();
      this.leftSideBaseboard = wall.getLeftSideBaseboard();
      this.rightSideColor = wall.getRightSideColor();
      this.rightSideTexture = wall.getRightSideTexture();
      this.rightSideShininess = wall.getRightSideShininess();
      this.rightSideBaseboard = wall.getRightSideBaseboard();
      this.pattern = wall.getPattern();
      this.topColor = wall.getTopColor();
      this.height = wall.getHeight();
      this.heightAtEnd = wall.getHeightAtEnd();
      this.thickness = wall.getThickness();
      this.arcExtent = wall.getArcExtent();
    }
    public Wall getWall() {
      return this.wall;
    }
    public float getXStart() {
      return this.xStart;
    }
    public float getXEnd() {
      return this.xEnd;
    }
    public float getYStart() {
      return this.yStart;
    }    
    public float getYEnd() {
      return this.yEnd;
    }
    public Float getHeight() {
      return this.height;
    }
    public Float getHeightAtEnd() {
      return this.heightAtEnd;
    }
    public Integer getLeftSideColor() {
      return this.leftSideColor;
    }
    public HomeTexture getLeftSideTexture() {
      return this.leftSideTexture;
    }
    public float getLeftSideShininess() {
      return this.leftSideShininess;
    }
    public Baseboard getLeftSideBaseboard() {
      return this.leftSideBaseboard;
    }
    public Integer getRightSideColor() {
      return this.rightSideColor;
    }
    public HomeTexture getRightSideTexture() {
      return this.rightSideTexture;
    }
    public float getRightSideShininess() {
      return this.rightSideShininess;
    }
    public Baseboard getRightSideBaseboard() {
      return this.rightSideBaseboard;
    }
    public TextureImage getPattern() {
      return this.pattern;
    }
    public Integer getTopColor() {
      return this.topColor;
    }
    public float getThickness() {
      return this.thickness;
    }
    public Float getArcExtent() {
      return this.arcExtent;
    }
  }
