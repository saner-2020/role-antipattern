/*
 * Copyright 2013-2015 the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.offline;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import org.bitcoin.protocols.payments.Protos;
import org.bitcoin.protocols.payments.Protos.Payment;
import org.bitcoinj.protocols.payments.PaymentProtocol;
import de.schildbach.wallet.R;
import de.schildbach.wallet.util.Bluetooth;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
/**
 * @author Andreas Schildbach
 */
public final static class BluetoothPaymentTask extends DirectPaymentTask {
        private final BluetoothAdapter bluetoothAdapter;
        private final String bluetoothMac;
        public BluetoothPaymentTask(final Handler backgroundHandler, final ResultCallback resultCallback,
                final BluetoothAdapter bluetoothAdapter, final String bluetoothMac) {
            super(backgroundHandler, resultCallback);
            this.bluetoothAdapter = bluetoothAdapter;
            this.bluetoothMac = bluetoothMac;
        }
        @Override
        public void send(final Payment payment) {
            super.backgroundHandler.post(new Runnable() {
                @Override
                public void run() {
                    log.info("trying to send tx via bluetooth {}", bluetoothMac);
                    if (payment.getTransactionsCount() != 1)
                        throw new IllegalArgumentException("wrong transactions count");
                    final BluetoothDevice device = bluetoothAdapter
                            .getRemoteDevice(Bluetooth.decompressMac(bluetoothMac));
                    try (final BluetoothSocket socket = device
                            .createInsecureRfcommSocketToServiceRecord(Bluetooth.BIP70_PAYMENT_PROTOCOL_UUID);
                            final DataOutputStream os = new DataOutputStream(socket.getOutputStream());
                            final DataInputStream is = new DataInputStream(socket.getInputStream())) {
                        socket.connect();
                        log.info("connected to payment protocol {}", bluetoothMac);
                        payment.writeDelimitedTo(os);
                        os.flush();
                        log.info("tx sent via bluetooth");
                        final Protos.PaymentACK paymentAck = Protos.PaymentACK.parseDelimitedFrom(is);
                        final boolean ack = "ack".equals(PaymentProtocol.parsePaymentAck(paymentAck).getMemo());
                        log.info("received {} via bluetooth", ack ? "ack" : "nack");
                        onResult(ack);
                    } catch (final IOException x) {
                        log.info("problem sending", x);
                        onFail(R.string.error_io, x.getMessage());
                    }
                }
            });
        }
    }
