/*
 * Copyright the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui;
import de.schildbach.wallet.R;
import de.schildbach.wallet.ui.TransactionsAdapter.ListItem.TransactionItem;
import android.content.res.Resources;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
/**
 * @author Andreas Schildbach
 */
public static class TransactionViewHolder extends RecyclerView.ViewHolder {
        private final int colorBackground;
        private final int colorBackgroundSelected;
        private final View extendTimeView;
        private final TextView fullTimeView;
        private final View extendAddressView;
        private final CircularProgressView confidenceCircularNormalView, confidenceCircularSelectedView;
        private final TextView confidenceTextualNormalView, confidenceTextualSelectedView;
        private final TextView timeView;
        private final TextView addressView;
        private final CurrencyTextView valueView;
        private final CurrencyTextView fiatView;
        private final View extendFeeView;
        private final CurrencyTextView feeView;
        private final View extendMessageView;
        private final TextView messageView;
        private final ImageButton menuView;
        public TransactionViewHolder(final View itemView) {
            super(itemView);
            final Resources res = itemView.getResources();
            this.colorBackground = res.getColor(R.color.bg_bright);
            this.colorBackgroundSelected = res.getColor(R.color.bg_panel);
            this.extendTimeView = itemView.findViewById(R.id.transaction_row_extend_time);
            this.fullTimeView = (TextView) itemView.findViewById(R.id.transaction_row_full_time);
            this.extendAddressView = itemView.findViewById(R.id.transaction_row_extend_address);
            this.confidenceCircularNormalView = (CircularProgressView) itemView
                    .findViewById(R.id.transaction_row_confidence_circular);
            this.confidenceCircularSelectedView = (CircularProgressView) itemView
                    .findViewById(R.id.transaction_row_confidence_circular_selected);
            this.confidenceTextualNormalView = (TextView) itemView
                    .findViewById(R.id.transaction_row_confidence_textual);
            this.confidenceTextualSelectedView = (TextView) itemView
                    .findViewById(R.id.transaction_row_confidence_textual_selected);
            this.timeView = (TextView) itemView.findViewById(R.id.transaction_row_time);
            this.addressView = (TextView) itemView.findViewById(R.id.transaction_row_address);
            this.valueView = (CurrencyTextView) itemView.findViewById(R.id.transaction_row_value);
            this.fiatView = (CurrencyTextView) itemView.findViewById(R.id.transaction_row_fiat);
            this.extendFeeView = itemView.findViewById(R.id.transaction_row_extend_fee);
            this.feeView = (CurrencyTextView) itemView.findViewById(R.id.transaction_row_fee);
            this.extendMessageView = itemView.findViewById(R.id.transaction_row_extend_message);
            this.messageView = (TextView) itemView.findViewById(R.id.transaction_row_message);
            this.menuView = (ImageButton) itemView.findViewById(R.id.transaction_row_menu);
        }
        public void bind(final TransactionItem item) {
            bindConfidence(item);
            bindTime(item);
            bindAddress(item);
            bindFee(item);
            bindValue(item);
            bindFiat(item);
            bindMessage(item);
            bindIsSelected(item);
        }
        private void bindConfidence(final TransactionItem item) {
            (item.isSelected ? confidenceCircularNormalView : confidenceCircularSelectedView)
                    .setVisibility(View.INVISIBLE);
            (item.isSelected ? confidenceTextualNormalView : confidenceTextualSelectedView).setVisibility(View.GONE);
            final CircularProgressView confidenceCircularView = item.isSelected ? confidenceCircularSelectedView
                    : confidenceCircularNormalView;
            final TextView confidenceTextualView = item.isSelected ? confidenceTextualSelectedView
                    : confidenceTextualNormalView;
            confidenceCircularView
                    .setVisibility(item.confidenceCircularMaxProgress > 0 || item.confidenceCircularMaxSize > 0
                            ? View.VISIBLE : View.GONE);
            confidenceCircularView.setMaxProgress(item.confidenceCircularMaxProgress);
            confidenceCircularView.setProgress(item.confidenceCircularProgress);
            confidenceCircularView.setMaxSize(item.confidenceCircularMaxSize);
            confidenceCircularView.setSize(item.confidenceCircularSize);
            confidenceCircularView.setColors(item.confidenceCircularFillColor, item.confidenceCircularStrokeColor);
            confidenceTextualView.setVisibility(item.confidenceTextual != null ? View.VISIBLE : View.GONE);
            confidenceTextualView.setText(item.confidenceTextual);
            confidenceTextualView.setTextColor(item.confidenceTextualColor);
        }
        private void bindTime(final TransactionItem item) {
            (item.isSelected ? extendTimeView : timeView).setVisibility(View.VISIBLE);
            (item.isSelected ? timeView : extendTimeView).setVisibility(View.GONE);
            final TextView timeView = item.isSelected ? this.fullTimeView : this.timeView;
            timeView.setText(item.time);
            timeView.setTextColor(item.timeColor);
        }
        private void bindAddress(final TransactionItem item) {
            extendAddressView.setVisibility(item.address != null || !item.isSelected ? View.VISIBLE : View.GONE);
            addressView.setText(item.address);
            addressView.setTextColor(item.addressColor);
            addressView.setTypeface(item.addressTypeface);
            addressView.setSingleLine(item.addressSingleLine);
        }
        private void bindFee(final TransactionItem item) {
            extendFeeView.setVisibility(item.fee != null ? View.VISIBLE : View.GONE);
            feeView.setAlwaysSigned(true);
            feeView.setFormat(item.feeFormat);
            feeView.setAmount(item.fee != null ? item.fee.negate() : null);
        }
        private void bindValue(final TransactionItem item) {
            valueView.setVisibility(item.value != null ? View.VISIBLE : View.GONE);
            valueView.setAlwaysSigned(true);
            valueView.setAmount(item.value);
            valueView.setFormat(item.valueFormat);
            valueView.setTextColor(item.valueColor);
        }
        private void bindFiat(final TransactionItem item) {
            fiatView.setVisibility(item.fiat != null ? View.VISIBLE : View.GONE);
            fiatView.setAlwaysSigned(true);
            fiatView.setAmount(item.fiat);
            fiatView.setFormat(item.fiatFormat);
            fiatView.setPrefixColor(item.fiatPrefixColor);
        }
        private void bindMessage(final TransactionItem item) {
            extendMessageView.setVisibility(item.message != null ? View.VISIBLE : View.GONE);
            messageView.setText(item.message);
            messageView.setTextColor(item.messageColor);
            messageView.setSingleLine(item.messageSingleLine);
        }
        private void bindIsSelected(final TransactionItem item) {
            if (itemView instanceof CardView)
                ((CardView) itemView)
                        .setCardBackgroundColor(item.isSelected ? colorBackgroundSelected : colorBackground);
            menuView.setVisibility(item.isSelected ? View.VISIBLE : View.GONE);
            bindConfidence(item);
            bindTime(item);
            bindAddress(item);
        }
    }
