/*
 * VideoPanel.java 15 fevr. 2010
 *
 * Sweet Home 3D, Copyright (c) 2010 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import javax.media.MediaLocator;
import javax.media.Time;
import javax.media.format.VideoFormat;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.PullBufferDataSource;
import javax.media.protocol.PullBufferStream;
import javax.swing.BoundedRangeModel;
import com.eteks.sweethome3d.model.Camera;
/**
 * A panel used for video creation. 
 * @author Emmanuel Puybaret
 */
private static class ImageDataSource extends PullBufferDataSource {
    private ImageSourceStream stream;
    public ImageDataSource(VideoFormat format,
                           FrameGenerator frameGenerator,
                           Camera []      framesPath,
                           BoundedRangeModel progressModel) {
      this.stream = new ImageSourceStream(format, frameGenerator, framesPath, progressModel);
    }
    @Override
    public void setLocator(MediaLocator source) {
    }
    @Override
    public MediaLocator getLocator() {
      return null;
    }
    /**
     * Returns RAW since buffers of video frames are sent without a container format.
     */
    @Override
    public String getContentType() {
      return ContentDescriptor.RAW;
    }
    @Override
    public void connect() {
    }
    @Override
    public void disconnect() {
    }
    @Override
    public void start() {
    }
    @Override
    public void stop() {
    }
    public PullBufferStream [] getStreams() {
      return new PullBufferStream [] {this.stream};
    }
    /**
     * Not necessary to compute the duration.
     */
    @Override
    public Time getDuration() {
      return DURATION_UNKNOWN;
    }
    @Override
    public Object [] getControls() {
      return new Object [0];
    }
    @Override
    public Object getControl(String type) {
      return null;
    }
  }
