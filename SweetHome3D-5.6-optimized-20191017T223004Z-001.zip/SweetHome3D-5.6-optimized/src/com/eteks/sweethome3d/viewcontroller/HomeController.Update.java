/*
 * HomeController.java 15 mai 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import java.net.URL;
import java.util.Date;
/**
 * A MVC controller for the home view.
 * @author Emmanuel Puybaret
 */
private static class Update implements Cloneable {
    private String id;
    private final String version;
    private Date   date;
    private String minVersion;
    private String maxVersion;
    private Long   size;
    private String operatingSystem;
    private URL    defaultDownloadPage;
    private URL    downloadPage;
    private String defaultComment;
    private String comment;
    public Update(String id, String version) {
      this.id = id;
      this.version = version;
    }
    public String getId() {
      return this.id;
    }
    public void setId(String id) {
      this.id = id;
    }
    public String getVersion() {
      return this.version;
    }    
    public Date getDate() {
      return this.date;
    }
    public void setDate(Date date) {
      this.date = date;
    }
    public String getMinVersion() {
      return this.minVersion;
    }
    public void setMinVersion(String minVersion) {
      this.minVersion = minVersion;
    }
    public String getMaxVersion() {
      return this.maxVersion;
    }
    public void setMaxVersion(String maxVersion) {
      this.maxVersion = maxVersion;
    }
    public Long getSize() {
      return this.size;
    }
    public void setSize(Long size) {
      this.size = size;
    }
    public String getOperatingSystem() {
      return this.operatingSystem;
    }
    public void setOperatingSystem(String system) {
      this.operatingSystem = system;
    }
    public URL getDefaultDownloadPage() {
      return this.defaultDownloadPage;
    }
    public void setDefaultDownloadPage(URL defaultDownloadPage) {
      this.defaultDownloadPage = defaultDownloadPage;
    }
    public URL getDownloadPage() {
      return this.downloadPage;
    }
    public void setDownloadPage(URL downloadPage) {
      this.downloadPage = downloadPage;
    }
    public String getDefaultComment() {
      return this.defaultComment;
    }
    public void setDefaultComment(String defaultComment) {
      this.defaultComment = defaultComment;
    }
    public String getComment() {
      return this.comment;
    }
    public void setComment(String comment) {
      this.comment = comment;
    }
    @Override
    protected Update clone() {
      try {
        return (Update)super.clone();
      } catch (CloneNotSupportedException ex) {
        throw new InternalError();
      }
    }
  }
