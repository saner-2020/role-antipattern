/*
 * Wall3D.java 23 jan. 09
 *
 * Sweet Home 3D, Copyright (c) 2007-2009 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.j3d;
import java.util.Arrays;
import com.eteks.sweethome3d.model.Content;
/**
 * Root of wall branch.
 */
private static class ModelRotationTuple {
    private Content    model;
    private float [][] rotation;
    public ModelRotationTuple(Content model, float [][] rotation) {
      this.model = model;
      this.rotation = rotation;
    }
    @Override
    public int hashCode() {
      int hashCode = 31 * this.model.hashCode();
      for (float [] table : this.rotation) {
        hashCode += Arrays.hashCode(table);
      }
      return hashCode;
    }
    @Override
    public boolean equals(Object obj) {
      if (this == obj) {
        return true;
      } else if (obj instanceof ModelRotationTuple) {
        ModelRotationTuple tuple = (ModelRotationTuple)obj;
        if (this.model.equals(tuple.model)
            && this.rotation.length == tuple.rotation.length) {
          for (int i = 0; i < this.rotation.length; i++) {
            if (!Arrays.equals(this.rotation [i], tuple.rotation [i])) {
              return false;
            }
          }
          return true;
        }
      }
      return false;
    }
  }
