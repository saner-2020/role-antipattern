/*
 * Copyright 2013-2015 the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui;
import java.io.FileNotFoundException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Pattern;
import javax.annotation.Nullable;
import org.bitcoin.protocols.payments.Protos;
import org.bitcoinj.core.Transaction;
import org.bitcoinj.core.VerificationException;
import org.bitcoinj.crypto.TrustStoreLoader;
import org.bitcoinj.protocols.payments.PaymentProtocol;
import org.bitcoinj.protocols.payments.PaymentProtocol.PkiVerificationData;
import org.bitcoinj.protocols.payments.PaymentProtocolException;
import org.bitcoinj.protocols.payments.PaymentSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.common.hash.Hashing;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.UninitializedMessageException;
import de.schildbach.wallet.Constants;
import de.schildbach.wallet.R;
import de.schildbach.wallet.data.PaymentIntent;
import android.content.Context;
import android.content.DialogInterface.OnClickListener;
/**
 * @author Andreas Schildbach
 */
public abstract class InputParser {
    private static final Logger log = LoggerFactory.getLogger(InputParser.class);
    public abstract void parse();
    protected final void parseAndHandlePaymentRequest(final byte[] serializedPaymentRequest)
            throws PaymentProtocolException {
        final PaymentIntent paymentIntent = parsePaymentRequest(serializedPaymentRequest);
        handlePaymentIntent(paymentIntent);
    }
    public static PaymentIntent parsePaymentRequest(final byte[] serializedPaymentRequest)
            throws PaymentProtocolException {
        try {
            if (serializedPaymentRequest.length > 50000)
                throw new PaymentProtocolException("payment request too big: " + serializedPaymentRequest.length);
            final Protos.PaymentRequest paymentRequest = Protos.PaymentRequest.parseFrom(serializedPaymentRequest);
            final String pkiName;
            final String pkiCaName;
            if (!"none".equals(paymentRequest.getPkiType())) {
                final KeyStore keystore = new TrustStoreLoader.DefaultTrustStoreLoader().getKeyStore();
                final PkiVerificationData verificationData = PaymentProtocol.verifyPaymentRequestPki(paymentRequest,
                        keystore);
                pkiName = verificationData.displayName;
                pkiCaName = verificationData.rootAuthorityName;
            } else {
                pkiName = null;
                pkiCaName = null;
            }
            final PaymentSession paymentSession = PaymentProtocol.parsePaymentRequest(paymentRequest);
            if (paymentSession.isExpired())
                throw new PaymentProtocolException.Expired("payment details expired: current time " + new Date()
                        + " after expiry time " + paymentSession.getExpires());
            if (!paymentSession.getNetworkParameters().equals(Constants.NETWORK_PARAMETERS))
                throw new PaymentProtocolException.InvalidNetwork(
                        "cannot handle payment request network: " + paymentSession.getNetworkParameters());
            final ArrayList<PaymentIntent.Output> outputs = new ArrayList<PaymentIntent.Output>(1);
            for (final PaymentProtocol.Output output : paymentSession.getOutputs())
                outputs.add(PaymentIntent.Output.valueOf(output));
            final String memo = paymentSession.getMemo();
            final String paymentUrl = paymentSession.getPaymentUrl();
            final byte[] merchantData = paymentSession.getMerchantData();
            final byte[] paymentRequestHash = Hashing.sha256().hashBytes(serializedPaymentRequest).asBytes();
            final PaymentIntent paymentIntent = new PaymentIntent(PaymentIntent.Standard.BIP70, pkiName, pkiCaName,
                    outputs.toArray(new PaymentIntent.Output[0]), memo, paymentUrl, merchantData, null,
                    paymentRequestHash);
            if (paymentIntent.hasPaymentUrl() && !paymentIntent.isSupportedPaymentUrl())
                throw new PaymentProtocolException.InvalidPaymentURL(
                        "cannot handle payment url: " + paymentIntent.paymentUrl);
            return paymentIntent;
        } catch (final InvalidProtocolBufferException x) {
            throw new PaymentProtocolException(x);
        } catch (final UninitializedMessageException x) {
            throw new PaymentProtocolException(x);
        } catch (final FileNotFoundException x) {
            throw new RuntimeException(x);
        } catch (final KeyStoreException x) {
            throw new RuntimeException(x);
        }
    }
    protected abstract void handlePaymentIntent(PaymentIntent paymentIntent);
    protected abstract void handleDirectTransaction(Transaction transaction) throws VerificationException;
    protected abstract void error(int messageResId, Object... messageArgs);
    protected void cannotClassify(final String input) {
        log.info("cannot classify: '{}'", input);
        error(R.string.input_parser_cannot_classify, input);
    }
    protected void dialog(final Context context, @Nullable final OnClickListener dismissListener, final int titleResId,
            final int messageResId, final Object... messageArgs) {
        final DialogBuilder dialog = new DialogBuilder(context);
        if (titleResId != 0)
            dialog.setTitle(titleResId);
        dialog.setMessage(context.getString(messageResId, messageArgs));
        dialog.singleDismissButton(dismissListener);
        dialog.show();
    }
    private static final Pattern PATTERN_TRANSACTION = Pattern
            .compile("[0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ$\\*\\+\\-\\.\\/\\:]{100,}");
}
