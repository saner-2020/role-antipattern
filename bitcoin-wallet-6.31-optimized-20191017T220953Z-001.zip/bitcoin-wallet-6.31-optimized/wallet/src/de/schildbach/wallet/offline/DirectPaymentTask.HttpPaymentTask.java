/*
 * Copyright 2013-2015 the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.offline;
import java.io.IOException;
import java.io.InputStream;
import javax.annotation.Nullable;
import org.bitcoin.protocols.payments.Protos;
import org.bitcoin.protocols.payments.Protos.Payment;
import org.bitcoinj.protocols.payments.PaymentProtocol;
import de.schildbach.wallet.Constants;
import de.schildbach.wallet.R;
import android.os.Handler;
import okhttp3.CacheControl;
import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.BufferedSink;
/**
 * @author Andreas Schildbach
 */
public final static class HttpPaymentTask extends DirectPaymentTask {
        private final String url;
        @Nullable
        private final String userAgent;
        public HttpPaymentTask(final Handler backgroundHandler, final ResultCallback resultCallback, final String url,
                @Nullable final String userAgent) {
            super(backgroundHandler, resultCallback);
            this.url = url;
            this.userAgent = userAgent;
        }
        @Override
        public void send(final Payment payment) {
            super.backgroundHandler.post(new Runnable() {
                @Override
                public void run() {
                    log.info("trying to send tx to {}", url);
                    final Request.Builder request = new Request.Builder();
                    request.url(url);
                    request.cacheControl(new CacheControl.Builder().noCache().build());
                    request.header("Accept", PaymentProtocol.MIMETYPE_PAYMENTACK);
                    if (userAgent != null)
                        request.header("User-Agent", userAgent);
                    request.post(new RequestBody() {
                        @Override
                        public MediaType contentType() {
                            return MediaType.parse(PaymentProtocol.MIMETYPE_PAYMENT);
                        }
                        @Override
                        public long contentLength() throws IOException {
                            return payment.getSerializedSize();
                        }
                        @Override
                        public void writeTo(final BufferedSink sink) throws IOException {
                            payment.writeTo(sink.outputStream());
                        }
                    });
                    final Call call = Constants.HTTP_CLIENT.newCall(request.build());
                    try {
                        final Response response = call.execute();
                        if (response.isSuccessful()) {
                            log.info("tx sent via http");
                            final InputStream is = response.body().byteStream();
                            final Protos.PaymentACK paymentAck = Protos.PaymentACK.parseFrom(is);
                            is.close();
                            final boolean ack = !"nack".equals(PaymentProtocol.parsePaymentAck(paymentAck).getMemo());
                            log.info("received {} via http", ack ? "ack" : "nack");
                            onResult(ack);
                        } else {
                            final int responseCode = response.code();
                            final String responseMessage = response.message();
                            log.info("got http error {}: {}", responseCode, responseMessage);
                            onFail(R.string.error_http, responseCode, responseMessage);
                        }
                    } catch (final IOException x) {
                        log.info("problem sending", x);
                        onFail(R.string.error_io, x.getMessage());
                    }
                }
            });
        }
    }
