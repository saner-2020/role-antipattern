/*
 * Copyright the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.bitcoinj.core.ECKey;
import org.bitcoinj.crypto.DeterministicKey;
import org.bitcoinj.wallet.Wallet;
import com.google.common.collect.Iterables;
import de.schildbach.wallet.Constants;
import de.schildbach.wallet.WalletApplication;
import de.schildbach.wallet.data.AbstractWalletLiveData;
import android.os.AsyncTask;
/**
 * @author Andreas Schildbach
 */
public class AddressesToExcludeLiveData extends AbstractWalletLiveData<Set<String>> {
        public AddressesToExcludeLiveData(final WalletApplication application) {
            super(application);
        }
        @Override
        protected void onWalletActive(final Wallet wallet) {
            loadAddressesToExclude();
        }
        private void loadAddressesToExclude() {
            final Wallet wallet = getWallet();
            AsyncTask.execute(new Runnable() {
                @Override
                public void run() {
                    final List<ECKey> derivedKeys = wallet.getIssuedReceiveKeys();
                    Collections.sort(derivedKeys, DeterministicKey.CHILDNUM_ORDER);
                    final List<ECKey> randomKeys = wallet.getImportedKeys();
                    final Set<String> addresses = new HashSet<>(derivedKeys.size() + randomKeys.size());
                    for (final ECKey key : Iterables.concat(derivedKeys, randomKeys))
                        addresses.add(key.toAddress(Constants.NETWORK_PARAMETERS).toBase58());
                    postValue(addresses);
                }
            });
        }
    }
