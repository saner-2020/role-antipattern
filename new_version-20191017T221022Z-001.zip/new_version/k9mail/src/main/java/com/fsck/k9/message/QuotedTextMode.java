package com.fsck.k9.message;
public enum QuotedTextMode {
    NONE,
    SHOW,
    HIDE
}