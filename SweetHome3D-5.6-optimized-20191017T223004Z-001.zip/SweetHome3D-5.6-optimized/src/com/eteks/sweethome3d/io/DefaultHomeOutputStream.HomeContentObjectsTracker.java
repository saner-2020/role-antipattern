/*
 * DefaultHomeOutputStream.java 13 Oct 2008
 *
 * Sweet Home 3D, Copyright (c) 2008 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.io;
import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.util.LinkedHashMap;
import java.util.Map;
import com.eteks.sweethome3d.model.Content;
import com.eteks.sweethome3d.tools.ResourceURLContent;
import com.eteks.sweethome3d.tools.SimpleURLContent;
import com.eteks.sweethome3d.tools.TemporaryURLContent;
import com.eteks.sweethome3d.tools.URLContent;
/**
 * An <code>OutputStream</code> filter that writes a home in a stream 
 * at .sh3d file format. 
 * @see DefaultHomeInputStream
 * @author Emmanuel Puybaret
 */
private class HomeContentObjectsTracker extends ObjectOutputStream {
    private Map<Content, String> savedContentNames = new LinkedHashMap<Content, String>();
    private int savedContentIndex = 0;
    public HomeContentObjectsTracker(OutputStream out) throws IOException {
      super(out);
      if (contentRecording != ContentRecording.INCLUDE_NO_CONTENT) {
        enableReplaceObject(true);
      }
    }
    @Override
    protected Object replaceObject(Object obj) throws IOException {
      if (obj instanceof TemporaryURLContent 
          || obj instanceof HomeURLContent
          || (contentRecording == ContentRecording.INCLUDE_ALL_CONTENT && obj instanceof Content)) {
        String subEntryName = "";
        if (obj instanceof URLContent) {
          URLContent urlContent = (URLContent)obj;
          // Check if duplicated content can be avoided 
          ContentDigestManager contentDigestManager = ContentDigestManager.getInstance();
          for (Map.Entry<Content, String> contentEntry : this.savedContentNames.entrySet()) {
            if (contentDigestManager.equals(urlContent, contentEntry.getKey())) {
              this.savedContentNames.put((Content)obj, contentEntry.getValue());
              return obj;
            }
          }
          checkCurrentThreadIsntInterrupted();
          // If content comes from a zipped content  
          if (urlContent.isJAREntry()) {
            String entryName = urlContent.getJAREntryName();
            if (urlContent instanceof HomeURLContent) {
              int slashIndex = entryName.indexOf('/');
              // If content comes from a directory of a home file
              if (slashIndex > 0) {
                // Retrieve entry name in zipped stream without the directory
                subEntryName = entryName.substring(slashIndex);
              }
            } else if (urlContent instanceof ResourceURLContent) {
              ResourceURLContent resourceUrlContent = (ResourceURLContent)urlContent;
              if (resourceUrlContent.isMultiPartResource()) {
                // If content is a resource coming from a JAR file, retrieve its file name
                int lastSlashIndex = entryName.lastIndexOf('/');
                if (lastSlashIndex != -1) {
                  // Consider content is a multi part resource only if it's in a subdirectory
                  subEntryName = entryName.substring(lastSlashIndex);
                }
              }
            } else if (!(urlContent instanceof SimpleURLContent)) {
              // Retrieve entry name in zipped stream
              subEntryName = "/" + entryName;
            }            
          } else if (urlContent instanceof ResourceURLContent) {
            ResourceURLContent resourceUrlContent = (ResourceURLContent)urlContent;
            // If content is a resource coming from a directory (this should be the case 
            // only when resource isn't in a JAR file during development), retrieve its file name
            if (resourceUrlContent.isMultiPartResource()) {
              try {
                subEntryName = "/" + new File(resourceUrlContent.getURL().toURI()).getName();
              } catch (URISyntaxException ex) {
                IOException ex2 = new IOException();
                ex2.initCause(ex);
                throw ex2;
              }
            }
          }
        } 
        // Build a relative URL that points to content object 
        String homeContentPath = this.savedContentIndex++ + subEntryName;
        this.savedContentNames.put((Content)obj, homeContentPath);
      } 
      return obj;
    }
    /**
     * Returns the names of the home contents to be saved.
     */
    public Map<Content, String> getSavedContentNames() {
      return this.savedContentNames;
    }
  }
