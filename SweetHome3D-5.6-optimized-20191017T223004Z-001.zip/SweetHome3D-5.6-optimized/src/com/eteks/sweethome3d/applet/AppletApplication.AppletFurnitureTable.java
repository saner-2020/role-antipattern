/*
 * AppletApplication.java 11 Oct 2008
 *
 * Sweet Home 3D, Copyright (c) 2008 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.applet;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JComponent;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import com.eteks.sweethome3d.model.Home;
import com.eteks.sweethome3d.model.HomeFurnitureGroup;
import com.eteks.sweethome3d.model.HomePieceOfFurniture;
import com.eteks.sweethome3d.model.UserPreferences;
import com.eteks.sweethome3d.swing.FurnitureTable;
import com.eteks.sweethome3d.tools.URLContent;
import com.eteks.sweethome3d.viewcontroller.FurnitureController;
/**
 * An application wrapper working in applet. 
 * @author Emmanuel Puybaret
 */
private static final class AppletFurnitureTable extends FurnitureTable {
    private TableCellRenderer nameRenderer = new TableCellRenderer() {
        private Font defaultFont;
        private Font importedPieceFont;
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
          JComponent rendererComponent = (JComponent)AppletFurnitureTable.super.getCellRenderer(row, column).
              getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
          // Initialize fonts if not done
          if (this.defaultFont == null) {
            this.defaultFont = table.getFont();
            this.importedPieceFont = 
                new Font(this.defaultFont.getFontName(), Font.ITALIC, this.defaultFont.getSize());        
          }
          HomePieceOfFurniture piece = (HomePieceOfFurniture)getValueAt(row, column);
          URLContent model = (URLContent)piece.getModel();
          // Imported pieces are not stored in URLContent instances
          boolean importedPiece = model.getClass() != URLContent.class;
          rendererComponent.setFont(importedPiece  ? this.importedPieceFont  : this.defaultFont);
          return rendererComponent;
        }
      };
    private AppletFurnitureTable(Home home, UserPreferences preferences, FurnitureController controller) {
      super(home, preferences, controller);
    }
    @Override
    public TableCellRenderer getCellRenderer(int row, int column) {
      if (getColumnModel().getColumn(column).getIdentifier() == HomePieceOfFurniture.SortableProperty.NAME
          && !(getValueAt(row, column) instanceof HomeFurnitureGroup)) {
        return this.nameRenderer;
      } else {
        return super.getCellRenderer(row, column);
      }
    }
  }
