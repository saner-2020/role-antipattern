/*
 * Copyright the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.annotation.Nullable;
import org.bitcoinj.core.Coin;
import org.bitcoinj.core.Sha256Hash;
import org.bitcoinj.core.Transaction;
import org.bitcoinj.utils.MonetaryFormat;
import org.bitcoinj.wallet.Wallet;
import de.schildbach.wallet.R;
import de.schildbach.wallet.data.AddressBookEntry;
import de.schildbach.wallet.ui.TransactionsAdapter.ListItem.TransactionItem;
import de.schildbach.wallet.ui.TransactionsAdapter.ListItem.WarningItem;
import android.content.Context;
import android.support.v7.recyclerview.extensions.ListAdapter;
import android.support.v7.util.DiffUtil;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
/**
 * @author Andreas Schildbach
 */
public class TransactionsAdapter extends ListAdapter<TransactionsAdapter.ListItem, RecyclerView.ViewHolder> {
    public static List<ListItem> buildListItems(final Context context, final List<Transaction> transactions,
            final WarningType warning, final @Nullable Wallet wallet,
            final @Nullable Map<String, AddressBookEntry> addressBook, final MonetaryFormat format,
            final int maxConnectedPeers, final @Nullable Sha256Hash selectedTransaction) {
        final MonetaryFormat noCodeFormat = format.noCode();
        final List<ListItem> items = new ArrayList<>(transactions.size() + 1);
        if (warning != null)
            items.add(new ListItem.WarningItem(warning));
        for (final Transaction tx : transactions)
            items.add(new ListItem.TransactionItem(context, tx, wallet, addressBook, noCodeFormat, maxConnectedPeers,
                    tx.getHash().equals(selectedTransaction)));
        return items;
    }
    private final Context context;
    private final LayoutInflater inflater;
    @Nullable
    private final OnClickListener onClickListener;
    private static final String CONFIDENCE_SYMBOL_IN_CONFLICT = "\u26A0"; // warning sign
    private static final String CONFIDENCE_SYMBOL_DEAD = "\u271D"; // latin cross
    private static final String CONFIDENCE_SYMBOL_UNKNOWN = "?";
    private static final int VIEW_TYPE_TRANSACTION = 0;
    private static final int VIEW_TYPE_WARNING = 1;
    public TransactionsAdapter(final Context context, final int maxConnectedPeers,
            final @Nullable OnClickListener onClickListener) {
        super(new DiffUtil.ItemCallback<ListItem>() {
            @Override
            public boolean areItemsTheSame(final ListItem oldItem, final ListItem newItem) {
                if (oldItem instanceof TransactionItem) {
                    if (!(newItem instanceof TransactionItem))
                        return false;
                    return Objects.equals(((TransactionItem) oldItem).transactionHash,
                            ((TransactionItem) newItem).transactionHash);
                } else {
                    if (!(newItem instanceof WarningItem))
                        return false;
                    return Objects.equals(((WarningItem) oldItem).type, ((WarningItem) newItem).type);
                }
            }
            @Override
            public boolean areContentsTheSame(final ListItem oldItem, final ListItem newItem) {
                if (oldItem instanceof TransactionItem) {
                    final TransactionItem oldTransactionItem = (TransactionItem) oldItem;
                    final TransactionItem newTransactionItem = (TransactionItem) newItem;
                    if (!Objects.equals(oldTransactionItem.confidenceCircularProgress,
                            newTransactionItem.confidenceCircularProgress))
                        return false;
                    if (!Objects.equals(oldTransactionItem.confidenceCircularMaxProgress,
                            newTransactionItem.confidenceCircularMaxProgress))
                        return false;
                    if (!Objects.equals(oldTransactionItem.confidenceCircularSize,
                            newTransactionItem.confidenceCircularSize))
                        return false;
                    if (!Objects.equals(oldTransactionItem.confidenceCircularMaxSize,
                            newTransactionItem.confidenceCircularMaxSize))
                        return false;
                    if (!Objects.equals(oldTransactionItem.confidenceCircularFillColor,
                            newTransactionItem.confidenceCircularFillColor))
                        return false;
                    if (!Objects.equals(oldTransactionItem.confidenceCircularStrokeColor,
                            newTransactionItem.confidenceCircularStrokeColor))
                        return false;
                    if (!Objects.equals(oldTransactionItem.confidenceTextual, newTransactionItem.confidenceTextual))
                        return false;
                    if (!Objects.equals(oldTransactionItem.confidenceTextualColor,
                            newTransactionItem.confidenceTextualColor))
                        return false;
                    if (!Objects.equals(oldTransactionItem.time, newTransactionItem.time))
                        return false;
                    if (!Objects.equals(oldTransactionItem.timeColor, newTransactionItem.timeColor))
                        return false;
                    if (!Objects.equals(oldTransactionItem.address, newTransactionItem.address))
                        return false;
                    if (!Objects.equals(oldTransactionItem.addressColor, newTransactionItem.addressColor))
                        return false;
                    if (!Objects.equals(oldTransactionItem.addressTypeface, newTransactionItem.addressTypeface))
                        return false;
                    if (!Objects.equals(oldTransactionItem.addressSingleLine, newTransactionItem.addressSingleLine))
                        return false;
                    if (!Objects.equals(oldTransactionItem.fee, newTransactionItem.fee))
                        return false;
                    if (!Objects.equals(oldTransactionItem.feeFormat.format(Coin.COIN).toString(),
                            newTransactionItem.feeFormat.format(Coin.COIN).toString()))
                        return false;
                    if (!Objects.equals(oldTransactionItem.value, newTransactionItem.value))
                        return false;
                    if (!Objects.equals(oldTransactionItem.valueFormat.format(Coin.COIN).toString(),
                            newTransactionItem.valueFormat.format(Coin.COIN).toString()))
                        return false;
                    if (!Objects.equals(oldTransactionItem.valueColor, newTransactionItem.valueColor))
                        return false;
                    if (!Objects.equals(oldTransactionItem.fiat, newTransactionItem.fiat))
                        return false;
                    if (!Objects.equals(
                            oldTransactionItem.fiatFormat != null
                                    ? oldTransactionItem.fiatFormat.format(Coin.COIN).toString() : null,
                            newTransactionItem.fiatFormat != null
                                    ? newTransactionItem.fiatFormat.format(Coin.COIN).toString() : null))
                        return false;
                    if (!Objects.equals(oldTransactionItem.fiatPrefixColor, newTransactionItem.fiatPrefixColor))
                        return false;
                    if (!Objects.equals(oldTransactionItem.message, newTransactionItem.message))
                        return false;
                    if (!Objects.equals(oldTransactionItem.messageColor, newTransactionItem.messageColor))
                        return false;
                    if (!Objects.equals(oldTransactionItem.messageSingleLine, newTransactionItem.messageSingleLine))
                        return false;
                    if (!Objects.equals(oldTransactionItem.isSelected, newTransactionItem.isSelected))
                        return false;
                    return true;
                } else {
                    return true;
                }
            }
            @Override
            public Object getChangePayload(final ListItem oldItem, final ListItem newItem) {
                final EnumSet<ChangeType> changes = EnumSet.noneOf(ChangeType.class);
                if (oldItem instanceof TransactionItem) {
                    final TransactionItem oldTransactionItem = (TransactionItem) oldItem;
                    final TransactionItem newTransactionItem = (TransactionItem) newItem;
                    if (!(Objects.equals(oldTransactionItem.confidenceCircularProgress,
                            newTransactionItem.confidenceCircularProgress)
                            && Objects.equals(oldTransactionItem.confidenceCircularMaxProgress,
                                    newTransactionItem.confidenceCircularMaxProgress)
                            && Objects.equals(oldTransactionItem.confidenceCircularSize,
                                    newTransactionItem.confidenceCircularSize)
                            && Objects.equals(oldTransactionItem.confidenceCircularMaxSize,
                                    newTransactionItem.confidenceCircularMaxSize)
                            && Objects.equals(oldTransactionItem.confidenceCircularFillColor,
                                    newTransactionItem.confidenceCircularFillColor)
                            && Objects.equals(oldTransactionItem.confidenceCircularStrokeColor,
                                    newTransactionItem.confidenceCircularStrokeColor)
                            && Objects.equals(oldTransactionItem.confidenceTextual,
                                    newTransactionItem.confidenceTextual)
                            && Objects.equals(oldTransactionItem.confidenceTextualColor,
                                    newTransactionItem.confidenceTextualColor)))
                        changes.add(ChangeType.CONFIDENCE);
                    if (!(Objects.equals(oldTransactionItem.time, newTransactionItem.time)
                            && Objects.equals(oldTransactionItem.timeColor, newTransactionItem.timeColor)))
                        changes.add(ChangeType.TIME);
                    if (!(Objects.equals(oldTransactionItem.address, newTransactionItem.address)
                            && Objects.equals(oldTransactionItem.addressColor, newTransactionItem.addressColor)
                            && Objects.equals(oldTransactionItem.addressTypeface, newTransactionItem.addressTypeface)
                            && Objects.equals(oldTransactionItem.addressSingleLine,
                                    newTransactionItem.addressSingleLine)))
                        changes.add(ChangeType.ADDRESS);
                    if (!(Objects.equals(oldTransactionItem.fee, newTransactionItem.fee)
                            && Objects.equals(oldTransactionItem.feeFormat.format(Coin.COIN).toString(),
                                    newTransactionItem.feeFormat.format(Coin.COIN).toString())))
                        changes.add(ChangeType.FEE);
                    if (!(Objects.equals(oldTransactionItem.value, newTransactionItem.value)
                            && Objects.equals(oldTransactionItem.valueFormat.format(Coin.COIN).toString(),
                                    newTransactionItem.valueFormat.format(Coin.COIN).toString())
                            && Objects.equals(oldTransactionItem.valueColor, newTransactionItem.valueColor)))
                        changes.add(ChangeType.VALUE);
                    if (!(Objects.equals(oldTransactionItem.fiat, newTransactionItem.fiat)
                            && Objects.equals(
                                    oldTransactionItem.fiatFormat != null
                                            ? oldTransactionItem.fiatFormat.format(Coin.COIN).toString() : null,
                                    newTransactionItem.fiatFormat != null
                                            ? newTransactionItem.fiatFormat.format(Coin.COIN).toString() : null)
                            && Objects.equals(oldTransactionItem.fiatPrefixColor, newTransactionItem.fiatPrefixColor)))
                        changes.add(ChangeType.FIAT);
                    if (!(Objects.equals(oldTransactionItem.message, newTransactionItem.message)
                            && Objects.equals(oldTransactionItem.messageColor, newTransactionItem.messageColor)
                            && Objects.equals(oldTransactionItem.messageSingleLine,
                                    newTransactionItem.messageSingleLine)))
                        changes.add(ChangeType.MESSAGE);
                    if (!(Objects.equals(oldTransactionItem.isSelected, newTransactionItem.isSelected)))
                        changes.add(ChangeType.IS_SELECTED);
                }
                return changes;
            }
        });
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.onClickListener = onClickListener;
    }
    @Override
    public int getItemViewType(final int position) {
        final ListItem listItem = getItem(position);
        if (listItem instanceof ListItem.WarningItem)
            return VIEW_TYPE_WARNING;
        else if (listItem instanceof ListItem.TransactionItem)
            return VIEW_TYPE_TRANSACTION;
        else
            throw new IllegalStateException();
    }
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(final ViewGroup parent, final int viewType) {
        if (viewType == VIEW_TYPE_TRANSACTION) {
            final CardView cardView = (CardView) inflater.inflate(R.layout.transaction_row_card, parent, false);
            cardView.setPreventCornerOverlap(false);
            cardView.setUseCompatPadding(false);
            cardView.setMaxCardElevation(0); // we're using Lollipop elevation
            return new TransactionViewHolder(cardView);
        } else if (viewType == VIEW_TYPE_WARNING) {
            return new WarningViewHolder(inflater.inflate(R.layout.transaction_row_warning, parent, false));
        } else {
            throw new IllegalStateException("unknown type: " + viewType);
        }
    }
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        final ListItem listItem = getItem(position);
        if (holder instanceof TransactionViewHolder) {
            final TransactionViewHolder transactionHolder = (TransactionViewHolder) holder;
            final ListItem.TransactionItem transactionItem = (ListItem.TransactionItem) listItem;
            transactionHolder.itemView.setActivated(transactionItem.isSelected);
            transactionHolder.bind(transactionItem);
            final OnClickListener onClickListener = this.onClickListener;
            if (onClickListener != null) {
                transactionHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(final View v) {
                        onClickListener.onTransactionClick(v, transactionItem.transactionHash);
                    }
                });
                transactionHolder.menuView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(final View v) {
                        onClickListener.onTransactionMenuClick(v, transactionItem.transactionHash);
                    }
                });
            }
        } else if (holder instanceof WarningViewHolder) {
            final WarningViewHolder warningHolder = (WarningViewHolder) holder;
            final ListItem.WarningItem warningItem = (ListItem.WarningItem) listItem;
            if (warningItem.type == WarningType.BACKUP) {
                if (getItemCount() == 2 /* 1 transaction, 1 warning */) {
                    warningHolder.messageView.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
                    warningHolder.messageView
                            .setText(Html.fromHtml(context.getString(R.string.wallet_transactions_row_warning_backup)));
                } else {
                    warningHolder.messageView
                            .setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_warning_grey600_24dp, 0, 0, 0);
                    warningHolder.messageView.setText(
                            Html.fromHtml(context.getString(R.string.wallet_disclaimer_fragment_remind_backup)));
                }
            } else if (warningItem.type == WarningType.STORAGE_ENCRYPTION) {
                warningHolder.messageView.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
                warningHolder.messageView.setText(
                        Html.fromHtml(context.getString(R.string.wallet_transactions_row_warning_storage_encryption)));
            } else if (warningItem.type == WarningType.CHAIN_FORKING) {
                warningHolder.messageView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_warning_grey600_24dp, 0,
                        0, 0);
                warningHolder.messageView.setText(
                        Html.fromHtml(context.getString(R.string.wallet_transactions_row_warning_chain_forking)));
            }
            final OnClickListener onClickListener = this.onClickListener;
            if (onClickListener != null) {
                warningHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(final View v) {
                        onClickListener.onWarningClick(v);
                    }
                });
            }
        }
    }
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position,
            final List<Object> payloads) {
        if (payloads.isEmpty()) { // Full bind
            onBindViewHolder(holder, position);
        } else { // Partial bind
            final ListItem listItem = getItem(position);
            final TransactionViewHolder transactionHolder = (TransactionViewHolder) holder;
            final ListItem.TransactionItem transactionItem = (ListItem.TransactionItem) listItem;
            for (final Object payload : payloads) {
                final EnumSet<ChangeType> changes = (EnumSet<ChangeType>) payload;
                for (final ChangeType change : changes) {
                    if (change == ChangeType.CONFIDENCE)
                        transactionHolder.bindConfidence(transactionItem);
                    else if (change == ChangeType.TIME)
                        transactionHolder.bindTime(transactionItem);
                    else if (change == ChangeType.ADDRESS)
                        transactionHolder.bindAddress(transactionItem);
                    else if (change == ChangeType.FEE)
                        transactionHolder.bindFee(transactionItem);
                    else if (change == ChangeType.VALUE)
                        transactionHolder.bindValue(transactionItem);
                    else if (change == ChangeType.FIAT)
                        transactionHolder.bindFiat(transactionItem);
                    else if (change == ChangeType.MESSAGE)
                        transactionHolder.bindMessage(transactionItem);
                    else if (change == ChangeType.IS_SELECTED)
                        transactionHolder.bindIsSelected(transactionItem);
                }
            }
        }
    }
}
