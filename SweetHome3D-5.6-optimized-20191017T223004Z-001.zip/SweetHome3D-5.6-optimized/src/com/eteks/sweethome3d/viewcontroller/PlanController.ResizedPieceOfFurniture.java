/*
 * PlanController.java 2 juin 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import java.util.List;
import com.eteks.sweethome3d.model.HomeDoorOrWindow;
import com.eteks.sweethome3d.model.HomeFurnitureGroup;
import com.eteks.sweethome3d.model.HomePieceOfFurniture;
/**
 * A MVC controller for the plan view.
 * @author Emmanuel Puybaret
 */
private static class ResizedPieceOfFurniture {
    private final HomePieceOfFurniture piece;
    private final float                x;
    private final float                y;
    private final float                width;
    private final float                depth;
    private final float                height;
    private final boolean              doorOrWindowBoundToWall;
    private final float []             groupFurnitureX;
    private final float []             groupFurnitureY;
    private final float []             groupFurnitureWidth;
    private final float []             groupFurnitureDepth;
    private final float []             groupFurnitureHeight;
    public ResizedPieceOfFurniture(HomePieceOfFurniture piece) {
      this.piece = piece;
      this.x = piece.getX();
      this.y = piece.getY();
      this.width = piece.getWidth();
      this.depth = piece.getDepth();
      this.height = piece.getHeight();
      this.doorOrWindowBoundToWall = piece instanceof HomeDoorOrWindow 
          && ((HomeDoorOrWindow)piece).isBoundToWall();
      if (piece instanceof HomeFurnitureGroup) {
        List<HomePieceOfFurniture> groupFurniture = ((HomeFurnitureGroup)piece).getAllFurniture();
        this.groupFurnitureX = new float [groupFurniture.size()];
        this.groupFurnitureY = new float [groupFurniture.size()];
        this.groupFurnitureWidth = new float [groupFurniture.size()];
        this.groupFurnitureDepth = new float [groupFurniture.size()];
        this.groupFurnitureHeight = new float [groupFurniture.size()];
        for (int i = 0; i < groupFurniture.size(); i++) {
          HomePieceOfFurniture groupPiece = groupFurniture.get(i);
          this.groupFurnitureX [i] = groupPiece.getX();
          this.groupFurnitureY [i] = groupPiece.getY();
          this.groupFurnitureWidth [i] = groupPiece.getWidth();
          this.groupFurnitureDepth [i] = groupPiece.getDepth();
          this.groupFurnitureHeight [i] = groupPiece.getHeight();
        }
      } else {
        this.groupFurnitureX = null;
        this.groupFurnitureY = null;
        this.groupFurnitureWidth = null;
        this.groupFurnitureDepth = null;
        this.groupFurnitureHeight = null;
      }
    }
    public HomePieceOfFurniture getPieceOfFurniture() {
      return this.piece;
    }
    public float getWidth() {
      return this.width;
    }
    public float getDepth() {
      return this.depth;
    }
    public float getHeight() {
      return this.height;
    }
    public boolean isDoorOrWindowBoundToWall() {
      return this.doorOrWindowBoundToWall;
    }
    public void reset() {
      this.piece.setX(this.x);
      this.piece.setY(this.y);
      setPieceOfFurnitureSize(this.piece, this.width, this.depth, this.height);
      if (this.piece instanceof HomeDoorOrWindow) {
        ((HomeDoorOrWindow)this.piece).setBoundToWall(this.doorOrWindowBoundToWall);
      }
      if (this.piece instanceof HomeFurnitureGroup) {
        List<HomePieceOfFurniture> groupFurniture = ((HomeFurnitureGroup)this.piece).getAllFurniture();
        for (int i = 0; i < groupFurniture.size(); i++) {
          HomePieceOfFurniture groupPiece = groupFurniture.get(i);
          if (this.piece.isResizable()) {
            // Restore group furniture location and size because resizing a group isn't reversible 
            groupPiece.setX(this.groupFurnitureX [i]);
            groupPiece.setY(this.groupFurnitureY [i]);
            setPieceOfFurnitureSize(groupPiece, 
                this.groupFurnitureWidth [i], this.groupFurnitureDepth [i], this.groupFurnitureHeight [i]);
          }
        }
      }
    }
    public static void setPieceOfFurnitureSize(HomePieceOfFurniture piece, 
                                               float width, float depth, float height) {
      if (piece.isHorizontallyRotated()) {
        // Furniture rotated around horizontal axes are always changed proportionally
        float scale = width / piece.getWidth();
        piece.scale(scale);
        piece.setWidthInPlan(scale * piece.getWidthInPlan());
        piece.setDepthInPlan(scale * piece.getDepthInPlan());
        piece.setHeightInPlan(scale * piece.getHeightInPlan());
        if (piece instanceof HomeFurnitureGroup) {
          for (HomePieceOfFurniture childPiece : ((HomeFurnitureGroup)piece).getAllFurniture()) {
            childPiece.setWidthInPlan(scale * childPiece.getWidthInPlan());
            childPiece.setDepthInPlan(scale * childPiece.getDepthInPlan());
            childPiece.setHeightInPlan(scale * childPiece.getHeightInPlan());
          }
        }
      } else {
        float widthInPlan = piece.getWidthInPlan() * width / piece.getWidth();
        piece.setWidth(width);
        piece.setWidthInPlan(widthInPlan);
        float depthInPlan = piece.getDepthInPlan() * depth / piece.getDepth();
        piece.setDepth(depth);
        piece.setDepthInPlan(depthInPlan);
        float heightInPlan = piece.getHeightInPlan() * height / piece.getHeight();
        piece.setHeight(height);
        piece.setHeightInPlan(heightInPlan);
        if (piece instanceof HomeFurnitureGroup) {
          for (HomePieceOfFurniture childPiece : ((HomeFurnitureGroup)piece).getAllFurniture()) {
            childPiece.setWidthInPlan(childPiece.getWidth());
            childPiece.setDepthInPlan(childPiece.getDepth());
            childPiece.setHeightInPlan(childPiece.getHeight());
          }
        }
      }
    }
  }
