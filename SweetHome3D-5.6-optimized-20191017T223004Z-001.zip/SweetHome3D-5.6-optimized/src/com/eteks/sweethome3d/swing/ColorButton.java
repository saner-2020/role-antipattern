/*
 * ColorButton.java 29 mai 07
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.colorchooser.AbstractColorChooserPanel;
import javax.swing.colorchooser.ColorSelectionModel;
import javax.swing.colorchooser.DefaultColorSelectionModel;
import javax.swing.text.JTextComponent;
import com.eteks.sweethome3d.model.UserPreferences;
/**
 * Button displaying a color as an icon.
 */
public class ColorButton extends JButton {
  public static final String COLOR_PROPERTY = "color";
  public static final String COLOR_DIALOG_TITLE_PROPERTY = "colorDialogTitle";
  // Share color chooser between ColorButton instances to keep recent colors
  private static JColorChooser colorChooser;
  private static Locale        colorChooserLocale;
  private Integer color;
  private String  colorDialogTitle;
  /**
   * Creates a color button.
   */
  public ColorButton() {
    this(null);
  }
  /**
   * Creates a color button.
   */
  public ColorButton(final UserPreferences preferences) {
    JLabel colorLabel = new JLabel("Color");
    Dimension iconDimension = colorLabel.getPreferredSize();
    final int iconWidth = iconDimension.width;
    final int iconHeight = iconDimension.height;
    setIcon(new Icon() {
      public int getIconWidth() {
        return iconWidth;
      }
      public int getIconHeight() {
        return iconHeight;
      }
      public void paintIcon(Component c, Graphics g, int x, int y) {
        if (color != null) {
          g.setColor(new Color(color));
          g.fillRect(x + 2, y + 2, iconWidth - 4,
              iconHeight - 4);
        }
        g.setColor(getForeground());
        g.drawRect(x + 2, y + 2, iconWidth - 5, iconHeight - 5);
      }
    });
    // Add a listener to update color
    addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent ev) {
        if (colorChooser == null
            || !Locale.getDefault().equals(colorChooserLocale)) {
          // Create color chooser instance each time default locale changed 
          colorChooser = createColorChooser(preferences);          
          colorChooserLocale = Locale.getDefault();
        }
        // Update edited color in furniture color chooser
        colorChooser.setColor(color != null 
            ? new Color(color)
            : getBackground());
        JDialog colorDialog = JColorChooser.createDialog(getParent(), 
            colorDialogTitle, true, colorChooser,
            new ActionListener () { 
              public void actionPerformed(ActionEvent e) {
                // Change button color when user click on ok button
                Integer color = colorChooser.getColor().getRGB();
                setColor(color);
                List<Integer> recentColors = new ArrayList<Integer>(preferences.getRecentColors());
                int colorIndex = recentColors.indexOf(color);
                if (colorIndex != 0) {
                  // Move color at the beginning of the list and ensure it doesn't contain more than 20 colors
                  if (colorIndex > 0) {
                    recentColors.remove(colorIndex);
                  } else {
                    while (recentColors.size() > RecentColorsPanel.MAX_COLORS) {
                      recentColors.remove(recentColors.size() - 1);
                    }
                  }
                  recentColors.add(0, color);
                  preferences.setRecentColors(recentColors);     
                }
              }
            }, null);   
        if (preferences != null) {
          AbstractColorChooserPanel colorChooserPanel = colorChooser.getChooserPanels() [0];
          if (colorChooserPanel instanceof PalettesColorChooserPanel) {
            ((PalettesColorChooserPanel)colorChooserPanel).setInitialColor(colorChooser.getColor());
            colorChooser.getPreviewPanel().getParent().setVisible(!preferences.getRecentColors().isEmpty());
            colorDialog.pack();
          }
        }
        colorDialog.setVisible(true);
      }
    });
  }
  /**
   * Creates a new color chooser.
   */
  private JColorChooser createColorChooser(UserPreferences preferences) {
    final JColorChooser colorChooser;
    if (preferences != null) {
      // Replace preview title by recent
      UIManager.put("ColorChooser.previewText", 
          preferences.getLocalizedString(ColorButton.class, "recentPanel.title"));
      ColorSelectionModel colorSelectionModel = new DefaultColorSelectionModel();
      final JPanel previewPanel = new RecentColorsPanel(colorSelectionModel, preferences);          
      final PalettesColorChooserPanel palettesPanel = new PalettesColorChooserPanel(preferences);
      palettesPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
      colorChooser = new JColorChooser(colorSelectionModel) {
          public void updateUI() {
            super.updateUI();
            // Add customized color chooser panel in updateUI, because an outside call to setChooserPanels 
            // might be ignored when the color chooser dialog is created
            List<AbstractColorChooserPanel> chooserPanels = new ArrayList<AbstractColorChooserPanel>(
                Arrays.asList(getChooserPanels()));
            // Remove swatch chooser panel
            if (chooserPanels.get(0).getClass().getName().equals("javax.swing.colorchooser.DefaultSwatchChooserPanel")) {
              chooserPanels.remove(0);
            } 
            // Remove components used to manage transparency and displayed at the fourth or fifth row 
            // of the first panel of ColorChooserPanel instances
            for (AbstractColorChooserPanel chooserPanel : chooserPanels) {
              if (chooserPanel.getClass().getName().equals("javax.swing.colorchooser.ColorChooserPanel")) {
                Component colorPanel = chooserPanel.getComponent(0);
                if (colorPanel.getClass().getName().equals("javax.swing.colorchooser.ColorPanel")
                    && colorPanel instanceof Container) {
                  Container colorPanelContainer = (Container)colorPanel;
                  if (colorPanelContainer.getComponentCount() == 15) {
                    int transparencyComponentsRow;
                    if (colorPanelContainer.getComponent(4) instanceof JLabel
                        && ((JLabel)colorPanelContainer.getComponent(4)).getText().length() == 0) {
                      transparencyComponentsRow = 3;
                    } else {
                      transparencyComponentsRow = 4;
                    }
                    colorPanelContainer.remove(transparencyComponentsRow + 10);
                    colorPanelContainer.remove(transparencyComponentsRow + 5);
                    colorPanelContainer.remove(transparencyComponentsRow);
                  }
                }
              }
            }
            chooserPanels.add(0, palettesPanel);
            setChooserPanels(chooserPanels.toArray(new AbstractColorChooserPanel [chooserPanels.size()]));
            setPreviewPanel(previewPanel);
            // Add auto selection to color chooser panels text fields
            addAutoSelectionOnTextFields(this);
          }
        };
    } else {
      colorChooser = new JColorChooser();
    }
    // Add Esc key management
    colorChooser.getActionMap().put("close", new AbstractAction() {
        public void actionPerformed(ActionEvent ev) {
          ((Window)SwingUtilities.getRoot(colorChooser)).dispose();
        }
      });
    colorChooser.getInputMap(JColorChooser.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("ESCAPE"), "close");
    return colorChooser;
  }
  private void addAutoSelectionOnTextFields(JComponent component) {
    if (component instanceof JTextComponent) {
      SwingTools.addAutoSelectionOnFocusGain((JTextComponent)component);
    } else if (component instanceof JSpinner) {
      JComponent editor = ((JSpinner)component).getEditor();
      if (editor instanceof JSpinner.DefaultEditor) {
        SwingTools.addAutoSelectionOnFocusGain(((JSpinner.DefaultEditor)editor).getTextField());
      }
    }
    for (int i = 0, n = component.getComponentCount(); i < n; i++) {
      Component childComponent = component.getComponent(i);
      if (childComponent instanceof JComponent) {
        addAutoSelectionOnTextFields((JComponent)childComponent);
      }
    }
  }
  /**
   * Returns the color displayed by this button.
   * @return the RGB code of the color of this button or <code>null</code>.
   */
  public Integer getColor() {
    return this.color;
  }
  /**
   * Sets the color displayed by this button.
   * @param color RGB code of the color or <code>null</code>.
   */
  public void setColor(Integer color) {
    if (color != this.color
        || (color != null && !color.equals(this.color))) {
      Integer oldColor = this.color;
      this.color = color;
      firePropertyChange(COLOR_PROPERTY, oldColor, color);
      repaint();
    }
  }
  /**
   * Returns the title of color dialog displayed when this button is pressed.  
   */
  public String getColorDialogTitle() {
    return this.colorDialogTitle;
  }
  /**
   * Sets the title of color dialog displayed when this button is pressed.  
   */
  public void setColorDialogTitle(String colorDialogTitle) {
    if (colorDialogTitle != this.colorDialogTitle
        || (colorDialogTitle != null && !colorDialogTitle.equals(this.colorDialogTitle))) {
      String oldColorDialogTitle = this.colorDialogTitle;
      this.colorDialogTitle = colorDialogTitle;
      firePropertyChange(COLOR_DIALOG_TITLE_PROPERTY, oldColorDialogTitle, colorDialogTitle);
      repaint();
    }
  }
  /**
   * Color chooser panel showing different palettes.
   */
  /**
   * A gray color chart.
   */
  /**
   * A color chart.
   */
  /**
   * A combo box able to display a color palette.
   */
  /**
   * Color code.
   */
  /**
   * Panel showing recent colors.
   */
}
