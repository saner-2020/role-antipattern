/*
 * NullableSpinner.java 29 mai 07
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.util.Date;
import javax.swing.SpinnerDateModel;
/**
 * Spinner that accepts empty string values. In this case the returned value is <code>null</code>. 
 */
public static class NullableSpinnerDateModel extends SpinnerDateModel {
    private boolean isNull;
    private boolean nullable;
    @Override
    public Object getNextValue() {
      if (this.isNull) {
        return super.getValue();
      } 
      return super.getNextValue();
    }
    @Override
    public Object getPreviousValue() {
      if (this.isNull) {
        return super.getValue();
      } 
      return super.getPreviousValue();
    }
    @Override
    public Object getValue() {
      if (this.isNull) {
        return null;
      } else {
        return super.getValue();
      }
    }
    /**
     * Sets model value. This method is overridden to store whether current value is <code>null</code> 
     * or not (super class <code>setValue</code> doesn't accept <code>null</code> value).
     */
    @Override
    public void setValue(Object value) {
      if (value == null && isNullable()) {
        if (!this.isNull) {
          this.isNull = true;
          fireStateChanged();
        }
      } else {
        if (this.isNull 
            && value != null 
            && value.equals(super.getValue())) {
          // Fire a state change if the value set is the same one as the one stored by number model
          // and this model exposed a null value before
          this.isNull = false;
          fireStateChanged();
        } else {
          this.isNull = false;
          super.setValue(value);
        }
      }
    }
    /**
     * Returns <code>true</code> if this spinner model is nullable.
     */
    public boolean isNullable() {
      return this.nullable;
    }
    /**
     * Sets whether this spinner model is nullable.
     */
    public void setNullable(boolean nullable) {
      this.nullable = nullable;
      if (!nullable && getValue() == null) {
        setValue(new Date());
      }
    }
  }
