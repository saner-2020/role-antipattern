/*
 * NullableSpinner.java 29 mai 07
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.text.Format;
import java.text.ParseException;
import javax.swing.JFormattedTextField;
import javax.swing.text.NumberFormatter;
/**
 * Spinner that accepts empty string values. In this case the returned value is <code>null</code>. 
 */
public class NullableSpinner extends AutoCommitSpinner {
  /**
   * Creates a default nullable spinner able to edit an integer. 
   */
  public NullableSpinner() {
    this(new NullableSpinnerNumberModel(0, 0, Integer.MAX_VALUE, 1));
  }
  /**
   * Creates a nullable spinner from <code>model</code>. 
   */
  public NullableSpinner(NullableSpinnerNumberModel model) {
    super(model, model.getFormat());
    final JFormattedTextField textField = ((DefaultEditor)getEditor()).getTextField();
    final JFormattedTextField.AbstractFormatter defaultFormatter = textField.getFormatter();
    // Change formatted text field formatter to enable the edition of empty values
    textField.setFormatterFactory(new JFormattedTextField.AbstractFormatterFactory() {
        @Override
        public JFormattedTextField.AbstractFormatter getFormatter(JFormattedTextField textfield) {
          return new NumberFormatter () {
              @Override
              public Format getFormat() {
                if (defaultFormatter instanceof NumberFormatter) {
                  return ((NumberFormatter)defaultFormatter).getFormat();
                } else {
                  return super.getFormat();
                }
              }
              @Override
              public boolean getCommitsOnValidEdit() {
                if (defaultFormatter instanceof NumberFormatter) {
                  return ((NumberFormatter)defaultFormatter).getCommitsOnValidEdit();
                } else {
                  return super.getCommitsOnValidEdit();
                }
              }
              @SuppressWarnings({"rawtypes"})
              @Override
              public Comparable getMaximum() {
                if (defaultFormatter instanceof NumberFormatter) {
                  return ((NumberFormatter)defaultFormatter).getMaximum();
                } else {
                  return super.getMaximum();
                }
              }
              @SuppressWarnings({"rawtypes"})
              @Override
              public Comparable getMinimum() {
                if (defaultFormatter instanceof NumberFormatter) {
                  return ((NumberFormatter)defaultFormatter).getMinimum();
                } else {
                  return super.getMinimum();
                }
              }
              @SuppressWarnings({"rawtypes"})
              @Override
              public void setMaximum(Comparable maximum) {
                if (defaultFormatter instanceof NumberFormatter) {
                  ((NumberFormatter)defaultFormatter).setMaximum(maximum);
                } else {
                  super.setMaximum(maximum);
                }
              }
              @SuppressWarnings({"rawtypes"})
              @Override
              public void setMinimum(Comparable minimum) {
                if (defaultFormatter instanceof NumberFormatter) {
                  ((NumberFormatter)defaultFormatter).setMinimum(minimum);
                } else {
                  super.setMinimum(minimum);
                }
              }
              @Override
              public Object stringToValue(String text) throws ParseException {
                if (text.length() == 0 && ((NullableSpinnerNumberModel)getModel()).isNullable()) {
                  // Return null for empty text 
                  return null;
                } else {
                  return defaultFormatter.stringToValue(text);
                }
              }
              @Override
              public String valueToString(Object value) throws ParseException {
                if (value == null && ((NullableSpinnerNumberModel)getModel()).isNullable()) {
                  // Return empty text for null values
                  return "";
                } else {
                  return defaultFormatter.valueToString(value);
                }
              }
            };
        }
      });
  }
  /**
   * Spinner date model that accepts <code>null</code> values. 
   */
  /**
   * Spinner number model that accepts <code>null</code> values. 
   */
  /**
   * A nullable spinner number model that will reset to minimum when maximum is reached. 
   */
  /**
   * Nullable spinner model displaying length values matching preferences unit. 
   */
}
