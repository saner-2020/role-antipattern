package com.fsck.k9.mail.ssl;

private static class LocalKeyStoreHolder {
        static final LocalKeyStore INSTANCE = new LocalKeyStore();
    }