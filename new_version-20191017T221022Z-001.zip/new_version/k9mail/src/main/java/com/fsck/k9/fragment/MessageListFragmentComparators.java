package com.fsck.k9.fragment;

import android.database.Cursor;

import java.util.Comparator;

/**
 * A set of {@link Comparator} classes used for {@link Cursor} data comparison.
 */
public class MessageListFragmentComparators {
    /**
     * Reverses the result of a {@link Comparator}.
     *
     * @param <T>
     */
    

    /**
     * Chains comparator to find a non-0 result.
     *
     * @param <T>
     */
    

    

    

    

    

    

    

    

    
}