/*
 * ColorButton.java 29 mai 07
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.colorchooser.ColorSelectionModel;
import com.eteks.sweethome3d.model.UserPreferences;
import com.eteks.sweethome3d.tools.OperatingSystem;
/**
 * Button displaying a color as an icon.
 */
private static class RecentColorsPanel extends JPanel {
    public static final int MAX_COLORS = OperatingSystem.isJavaVersionGreaterOrEqual("1.7") ? 25 : 20;
    private Cursor pipetteCursor;
    private RecentColorsPanel(final ColorSelectionModel colorSelectionModel,
                              final UserPreferences preferences) {
      super(new GridBagLayout());
      this.pipetteCursor = SwingTools.createCustomCursor(
          OperatingSystem.isMacOSX()
              ? ColorButton.class.getResource("resources/cursors/pipette16x16-macosx.png")
              : ColorButton.class.getResource("resources/cursors/pipette16x16.png"),
          ColorButton.class.getResource("resources/cursors/pipette32x32.png"), 
          0, 1, "Pipette", Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
      preferences.addPropertyChangeListener(UserPreferences.Property.RECENT_COLORS, 
          new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent ev) {
              setRecentColors(colorSelectionModel, preferences);
            }
          });
      setRecentColors(colorSelectionModel, preferences);
      setOpaque(false);
    }
    private void setRecentColors(final ColorSelectionModel colorSelectionModel, 
                                 UserPreferences preferences) {
      removeAll();
      int i = 0;
      if (UIManager.getLookAndFeel().getID().equals("GTK")) {
        // Add a label to replace the border that is not active
        add(new JLabel(UIManager.getString("ColorChooser.previewText")), new GridBagConstraints(
            i++, 0, 1, 1, 0, 0, GridBagConstraints.LINE_START, 
            GridBagConstraints.NONE, new Insets(0, 0, 0, 5), 0, 0));
      }      
      List<Integer> recentColors = preferences.getRecentColors();
      final int colorComponentSize = Math.round(20 * SwingTools.getResolutionScale());
      for (int j = 0; j < recentColors.size() && j < MAX_COLORS; j++) {
        final Integer color = recentColors.get(j);
        Component colorComponent = new JComponent() {
            @Override
            protected void paintComponent(Graphics g) {
              Insets insets = getInsets();
              int drawnWidth = getWidth() - insets.right - insets.left;
              int drawnHeight = getHeight() - insets.bottom - insets.top;
              g.setColor(Color.GRAY);
              g.translate(insets.left, insets.top);            
              g.drawRect(0, 0, drawnWidth - 1, drawnHeight - 1);
              g.setColor(new Color(color));
              g.fillRect(1, 1, drawnWidth - 2, drawnHeight - 2);
            }
            @Override
            public Dimension getPreferredSize() {
              return new Dimension(colorComponentSize, colorComponentSize);
            }
          };
        colorComponent.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent ev) {
              colorSelectionModel.setSelectedColor(new Color(color));
              if (ev.getClickCount() == 2) {
                JRootPane rootPane = (JRootPane)SwingUtilities.getAncestorOfClass(JRootPane.class, RecentColorsPanel.this);
                if (rootPane != null) {
                  for (JButton button : SwingTools.findChildren(rootPane, JButton.class)) {
                    if ("OK".equals(button.getActionCommand())) {
                      button.doClick();
                    }
                  }
                }
              }
            }
          });
        colorComponent.setCursor(this.pipetteCursor);
        add(colorComponent, new GridBagConstraints(
            i++, 0, 1, 1, 0, 0, GridBagConstraints.CENTER, 
            GridBagConstraints.NONE, new Insets(0, 0, 0, 2), 0, 0));
      }
    }
    public Insets getInsets() { 
      if (OperatingSystem.isJavaVersionGreaterOrEqual("1.7")) {
        Insets insets = super.getInsets();
        if (OperatingSystem.isMacOSXLeopardOrSuperior()) {
          insets.top += 10;
        }
        return insets;
      } else {
        if (UIManager.getLookAndFeel().getID().equals("GTK")) {
          return new Insets(5, 5, 5, 5);
        } else {
          // Tip to ensure the preview panel isn't ignored by BasicColorChooserUI
          return new Insets(1, 0, 0, 0);
        }
      }
    }
  }
