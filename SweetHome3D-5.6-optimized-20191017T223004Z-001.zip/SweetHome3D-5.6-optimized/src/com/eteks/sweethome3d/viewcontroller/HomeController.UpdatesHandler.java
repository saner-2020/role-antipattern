/*
 * HomeController.java 15 mai 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import java.io.InterruptedIOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
/**
 * A MVC controller for the home view.
 * @author Emmanuel Puybaret
 */
private class UpdatesHandler extends DefaultHandler {
    private final URL                       baseUrl;
    private final StringBuilder             comment = new StringBuilder();
    private final SimpleDateFormat          dateTimeFormat;
    private final SimpleDateFormat          dateFormat;
    private final Map<String, List<Update>> updates = new HashMap<String, List<Update>>();
    private Update                          update;
    private boolean                         inComment;
    private boolean                         inUpdate;
    private String                          language;
    public UpdatesHandler(URL baseUrl) {
      this.baseUrl = baseUrl;
      TimeZone gmtTimeZone = TimeZone.getTimeZone("GMT");
      this.dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
      this.dateTimeFormat.setTimeZone(gmtTimeZone);
      this.dateFormat = new SimpleDateFormat("yyyy-MM-dd");
      this.dateFormat.setTimeZone(gmtTimeZone);
    }
    /**
     * Returns the update matching the given <code>id</code>.
     */
    private List<Update> getUpdates(String id) {
      return this.updates.get(id);
    }
    /**
     * Throws a <code>SAXException</code> exception initialized with a <code>InterruptedRecorderException</code> 
     * cause if current thread is interrupted. The interrupted status of the current thread 
     * is cleared when an exception is thrown.
     */
    private void checkCurrentThreadIsntInterrupted() throws SAXException {
      if (Thread.interrupted()) {
        throw new SAXException(new InterruptedIOException());
      }
    }
    @Override
    public void startElement(String uri, String localName, String name, Attributes attributes) throws SAXException {
      checkCurrentThreadIsntInterrupted();
      if (this.inComment) {
        // Reproduce comment content
        this.comment.append("<" + name);
        for (int i = 0; i < attributes.getLength(); i++) {
          this.comment.append(" " + attributes.getQName(i) + "=\"" + attributes.getValue(i) + "\"");
        }
        this.comment.append(">");
      } else if (this.inUpdate && "comment".equals(name)) {
        this.comment.setLength(0);
        this.language = attributes.getValue("lang");
        if (this.language == null || preferences.getLanguage().equals(this.language)) {
          this.inComment = true;
        }
      } else if (this.inUpdate && "downloadPage".equals(name)) {
        String url = attributes.getValue("url");
        if (url != null) {
          try {
            String language = attributes.getValue("lang");
            if (language == null) {
              this.update.setDefaultDownloadPage(new URL(this.baseUrl, url));
            } else if (preferences.getLanguage().equals(language)) {
              this.update.setDownloadPage(new URL(this.baseUrl, url));
            }
          } catch (MalformedURLException ex) {
            // Ignore bad URLs
          }
        }
      } else if (!this.inUpdate && "update".equals(name)) {
        String id = attributes.getValue("id");
        String version = attributes.getValue("version");
        if (id != null
            && version != null) {
          this.update = new Update(id, version);
          String inheritedUpdate = attributes.getValue("inherits");
          // If update inherits from an other update, search the update with the same id and version
          if (inheritedUpdate != null) {
            List<Update> updates = this.updates.get(inheritedUpdate);
            if (updates != null) {
              for (Update update : updates) {
                if (version.equals(update.getVersion())) {
                  this.update = update.clone();
                  this.update.setId(id);
                  break;
                }
              }
            }
          }
          String dateAttibute = attributes.getValue("date");
          if (dateAttibute != null) {
            try {
              this.update.setDate(this.dateTimeFormat.parse(dateAttibute));
            } catch (ParseException ex) {
              try {
                this.update.setDate(this.dateFormat.parse(dateAttibute));
              } catch (ParseException ex1) {
              }
            }
          }
          String minVersion = attributes.getValue("minVersion");
          if (minVersion != null) {
            this.update.setMinVersion(minVersion);
          }
          String maxVersion = attributes.getValue("maxVersion");
          if (maxVersion != null) {
            this.update.setMaxVersion(maxVersion);
          }
          String size = attributes.getValue("size");
          if (size != null) {
            try {
              this.update.setSize(new Long (size));
            } catch (NumberFormatException ex) { 
              // Ignore malformed number
            }
          }
          String operatingSystem = attributes.getValue("operatingSystem");
          if (operatingSystem != null) {
            this.update.setOperatingSystem(operatingSystem);
          }
          List<Update> updates = this.updates.get(id);
          if (updates == null) {
            updates = new ArrayList<Update>();
            this.updates.put(id, updates);
          }
          updates.add(this.update);
          this.inUpdate = true;
        }
      }
    }
    @Override
    public void characters(char [] ch, int start, int length) throws SAXException {
      checkCurrentThreadIsntInterrupted();
      if (this.inComment) {
        // Reproduce comment content
        this.comment.append(ch, start, length);
      }
    }
    @Override
    public void endElement(String uri, String localName, String name) throws SAXException {
      if (this.inComment) {
        if ("comment".equals(name)) {
          String comment = this.comment.toString().trim().replace('\n', ' ');
          if (comment.length() == 0) {
            comment = null;
          }
          if (this.language == null) {
            this.update.setDefaultComment(comment);
          } else {
            this.update.setComment(comment);
          }
          this.inComment = false;
        } else {
          // Reproduce comment content
          this.comment.append("</" + name + ">");
        }
      } else if (this.inUpdate && "update".equals(name)) {
        this.inUpdate = false;
      }
    }
  }
