/*
 * FurnitureCatalogTree.java 7 avr. 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JEditorPane;
import javax.swing.JTree;
import javax.swing.text.html.HTMLDocument;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeCellRenderer;
import com.eteks.sweethome3d.model.CatalogPieceOfFurniture;
import com.eteks.sweethome3d.model.Content;
import com.eteks.sweethome3d.model.FurnitureCategory;
/**
 * A tree displaying furniture catalog by category.
 * @author Emmanuel Puybaret
 */
private class CatalogCellRenderer extends JComponent implements TreeCellRenderer {
    private static final int        DEFAULT_ICON_HEIGHT = 32;
    private Font                    defaultFont;
    private Font                    modifiablePieceFont;
    private DefaultTreeCellRenderer nameLabel;
    private JEditorPane             informationPane;
    public CatalogCellRenderer() {
      setLayout(null);
      this.nameLabel = new DefaultTreeCellRenderer();
      this.informationPane = new JEditorPane("text/html", null);
      this.informationPane.setOpaque(false);
      this.informationPane.setEditable(false);
      add(this.nameLabel);
      add(this.informationPane);
    }
    public Component getTreeCellRendererComponent(JTree tree, 
        Object value, boolean selected, boolean expanded, 
        boolean leaf, int row, boolean hasFocus) {
      // Configure name label with its icon, background and focus colors 
      this.nameLabel.getTreeCellRendererComponent( 
          tree, value, selected, expanded, leaf, row, hasFocus);
      // Initialize fonts if not done
      if (this.defaultFont == null) {
        this.defaultFont = this.nameLabel.getFont();
        String bodyRule = "body { font-family: " + this.defaultFont.getFamily() + "; " 
            + "font-size: " + this.defaultFont.getSize() + "pt; " 
            + "margin: 0; }";
        ((HTMLDocument)this.informationPane.getDocument()).getStyleSheet().addRule(bodyRule);
        this.modifiablePieceFont = 
            new Font(this.defaultFont.getFontName(), Font.ITALIC, this.defaultFont.getSize());        
      }
      // If node is a category, change label text
      if (value instanceof FurnitureCategory) {
        this.nameLabel.setText(((FurnitureCategory)value).getName());
        this.nameLabel.setFont(this.defaultFont);
        this.informationPane.setVisible(false);
      } 
      // Else if node is a piece of furniture, change label text and icon
      else if (value instanceof CatalogPieceOfFurniture) {
        CatalogPieceOfFurniture piece = (CatalogPieceOfFurniture)value;
        this.nameLabel.setText(piece.getName());
        this.nameLabel.setIcon(getLabelIcon(tree, piece.getIcon()));
        this.nameLabel.setFont(piece.isModifiable() 
            ? this.modifiablePieceFont : this.defaultFont);
        this.informationPane.setVisible(true);
        this.informationPane.setText(piece.getInformation());
      }
      return this;
    }
    @Override
    public void doLayout() {
      Dimension namePreferredSize = this.nameLabel.getPreferredSize();
      this.nameLabel.setSize(namePreferredSize);
      if (this.informationPane.isVisible()) {
        Dimension informationPreferredSize = this.informationPane.getPreferredSize();
        this.informationPane.setBounds(namePreferredSize.width + 2, 
            Math.max(0, (namePreferredSize.height - informationPreferredSize.height) / 2),
            informationPreferredSize.width, namePreferredSize.height);
      }
    }
    @Override
    public Dimension getPreferredSize() {
      Dimension preferredSize = this.nameLabel.getPreferredSize();
      if (this.informationPane.isVisible()) {
        preferredSize.width += 2 + this.informationPane.getPreferredSize().width;
      }
      return preferredSize;
    }
    /**
     * The following methods are overridden for performance reasons.
     */
    @Override
    public void revalidate() {      
    }
    @Override
    public void repaint(long tm, int x, int y, int width, int height) {      
    }
    @Override
    public void repaint(Rectangle r) {      
    }
    @Override
    public void repaint() {      
    }
    /**
     * Returns an Icon instance with the read image scaled at the tree row height or
     * an empty image if the image couldn't be read.
     * @param content the content of an image.
     */
    private Icon getLabelIcon(JTree tree, Content content) {
      return IconManager.getInstance().getIcon(content, getRowHeight(tree), tree);
    }
    /**
     * Returns the height of rows in tree.
     */
    private int getRowHeight(JTree tree) {
      return tree.isFixedRowHeight()
          ? tree.getRowHeight()
          : DEFAULT_ICON_HEIGHT;
    }
    @Override
    protected void paintChildren(Graphics g) {
      // Force text anti aliasing on texts
      ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, 
          RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
      super.paintChildren(g);
    }
  }
