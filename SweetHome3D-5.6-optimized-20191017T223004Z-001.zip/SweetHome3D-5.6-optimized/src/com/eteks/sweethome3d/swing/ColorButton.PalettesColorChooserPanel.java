/*
 * ColorButton.java 29 mai 07
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.awt.AWTException;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.awt.image.BufferedImage;
import java.text.FieldPosition;
import java.text.Format;
import java.text.ParseException;
import java.text.ParsePosition;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.ToolTipManager;
import javax.swing.colorchooser.AbstractColorChooserPanel;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.MouseInputAdapter;
import com.eteks.sweethome3d.model.UserPreferences;
import com.eteks.sweethome3d.tools.OperatingSystem;
/**
 * Button displaying a color as an icon.
 */
private static class PalettesColorChooserPanel extends AbstractColorChooserPanel {
    private final UserPreferences preferences;
    private GrayColorChart        grayColorChart;
    private ColorChart            colorChart;
    private JComponent            colorComponent;
    private JFormattedTextField   rgbTextField;
    private PaletteComboBox       ralComboBox;
    private PaletteComboBox       creativeCommonsComboBox;
    private Color                 initialColor;
    public PalettesColorChooserPanel(UserPreferences preferences) {
      setOpaque(false);
      this.preferences = preferences;
      addAncestorListener(new AncestorListener() {
          private int initialDelay;
          public void ancestorAdded(AncestorEvent event) {
            // Set a shorter delay to display tool tips
            ToolTipManager toolTipManager = ToolTipManager.sharedInstance();
            this.initialDelay = toolTipManager.getInitialDelay();
            toolTipManager.setInitialDelay(Math.min(this.initialDelay, 100));
          }
          public void ancestorRemoved(AncestorEvent event) {
            // Restore default delay
            ToolTipManager.sharedInstance().setInitialDelay(this.initialDelay);
          }
          public void ancestorMoved(AncestorEvent event) {
          }
        });
    }
    public void setInitialColor(Color referenceColor) {
      this.initialColor = referenceColor;
      if (this.colorComponent != null) {
        this.colorComponent.repaint();
      }
    }
    @Override
    public void updateChooser() {
      Color selectedColor = getColorFromModel();
      this.colorComponent.repaint();
      if (!selectedColor.equals(this.rgbTextField.getValue())) {
        this.rgbTextField.setValue(selectedColor);
      }
      this.ralComboBox.setSelectedItem(this.ralComboBox.getColorCode(selectedColor));
      this.creativeCommonsComboBox.setSelectedItem(this.creativeCommonsComboBox.getColorCode(selectedColor));
    }
    @Override
    protected void buildChooser() {
      removeAll();
      // Create components
      this.grayColorChart = new GrayColorChart();
      this.grayColorChart.setBorder(BorderFactory.createLineBorder(Color.GRAY));
      final Cursor pipetteCursor = SwingTools.createCustomCursor(
          OperatingSystem.isMacOSX()
              ? ColorButton.class.getResource("resources/cursors/pipette16x16-macosx.png")
              : ColorButton.class.getResource("resources/cursors/pipette16x16.png"),
          ColorButton.class.getResource("resources/cursors/pipette32x32.png"), 
          0, 1, "Pipette", Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
      this.grayColorChart.setCursor(pipetteCursor);
      ToolTipManager.sharedInstance().registerComponent(this.grayColorChart);
      MouseInputAdapter grayColorCharMouseListener = new MouseInputAdapter() {
          @Override
          public void mousePressed(MouseEvent ev) {
            getColorSelectionModel().setSelectedColor(grayColorChart.getColorAt(ev.getY()));
            if (ev.getClickCount() == 2) {
              clickOnOk();
            }
          }
          @Override
          public void mouseDragged(MouseEvent ev) {
            mousePressed(ev);
          }
        };
      this.grayColorChart.addMouseListener(grayColorCharMouseListener);
      this.grayColorChart.addMouseMotionListener(grayColorCharMouseListener);
      this.colorChart = new ColorChart();
      this.colorChart.setBorder(BorderFactory.createLineBorder(Color.GRAY));
      this.colorChart.setCursor(pipetteCursor);
      ToolTipManager.sharedInstance().registerComponent(this.colorChart);
      MouseInputAdapter colorChartMouseListener = new MouseInputAdapter() {
          @Override
          public void mousePressed(MouseEvent ev) {
            getColorSelectionModel().setSelectedColor(colorChart.getColorAt(ev.getX(), ev.getY()));
            if (ev.getClickCount() == 2) {
              clickOnOk();
            }
          }
          @Override
          public void mouseDragged(MouseEvent ev) {
            mousePressed(ev);
          }
        };
      this.colorChart.addMouseListener(colorChartMouseListener);
      this.colorChart.addMouseMotionListener(colorChartMouseListener);
      JLabel colorLabel = new JLabel(
          this.preferences.getLocalizedString(ColorButton.class, "colorLabel.text"));
      this.colorComponent = new JComponent() {
          @Override
          protected void paintComponent(Graphics g) {
            Insets insets = getInsets();
            int drawnWidth = getWidth() - insets.right - insets.left;
            int drawnHeight = getHeight() - insets.bottom - insets.top;
            g.setColor(Color.GRAY);
            g.translate(insets.left, insets.top);            
            g.drawRect(0, 0, drawnWidth / 2 - 1, drawnHeight - 1);
            g.drawRect(drawnWidth / 2, 0, drawnWidth / 2 - 1, drawnHeight - 1);
            g.setColor(initialColor);
            g.fillRect(1, 1, drawnWidth / 2 - 2, drawnHeight - 2);
            g.setColor(getColorSelectionModel().getSelectedColor());
            g.fillRect(drawnWidth / 2 + 1, 1, drawnWidth / 2 - 2, drawnHeight - 2);
          }
          @Override
          public Dimension getPreferredSize() {
            return new Dimension(60, 30);
          }
        };
      this.colorComponent.addMouseListener(new MouseAdapter() {
          @Override
          public void mousePressed(MouseEvent ev) {
            if (ev.getX() < ev.getComponent().getWidth() / 2) {
              getColorSelectionModel().setSelectedColor(initialColor);
            }
          }
        });
      this.colorComponent.setCursor(pipetteCursor);
      AbstractAction pipetteAction = new AbstractAction() {
          public void actionPerformed(ActionEvent ev) {
            // Grab desktop with a tiny undecorated dialog
            Window window = SwingUtilities.getWindowAncestor(getParent());
            if (!(window instanceof Frame)) {
              window = JOptionPane.getRootFrame();
            }
            final JDialog pipetteWindow = new JDialog((Frame)window);
            pipetteWindow.setUndecorated(true);
            pipetteWindow.setModal(true);
            pipetteWindow.setSize(3, 3);
            try {
              if (OperatingSystem.isJavaVersionGreaterOrEqual("1.7")) {
                // Call pipetteWindow.setOpacity(0.05f) by reflection to ensure Java SE 5 compatibility
                // Opacity is set to 0.05f to be almost transparent but still visible enough by the
                // the system not to switch to another application when the user clicks
                Window.class.getMethod("setOpacity", float.class).invoke(pipetteWindow, 0.05f);
                // Enlarge window to reduce mouse cursor change
                pipetteWindow.setSize(10, 10);
              } else if (OperatingSystem.isJavaVersionGreaterOrEqual("1.6")) {
                // Call com.sun.awt.AWTUtilities.setWindowOpacity(pipetteWindow, 0.05f)
                Class<?> awtUtilitiesClass = Class.forName("com.sun.awt.AWTUtilities");
                awtUtilitiesClass.getMethod("setWindowOpacity", Window.class, float.class).invoke(null, pipetteWindow, 0.05f);
                // Enlarge window to reduce mouse cursor change
                pipetteWindow.setSize(10, 10);
              } 
            } catch (Exception ex) {
              // For any exception, let's consider simply the method failed or doesn't exist
            }
            final Point mouseLocation = MouseInfo.getPointerInfo().getLocation();
            pipetteWindow.setLocation(mouseLocation.x - pipetteWindow.getWidth() / 2, 
                mouseLocation.y - pipetteWindow.getHeight() / 2);
            mouseLocation.setLocation(-1, -1); // Reset location to help window update its cursor 
            pipetteWindow.setCursor(pipetteCursor);
            // Follow mouse moves with a timer because mouse listeners would miss some events
            final Timer timer = new Timer(10, new ActionListener() {
                public void actionPerformed(ActionEvent ev) {
                  Point newMouseLocation = MouseInfo.getPointerInfo().getLocation();
                  if (!mouseLocation.equals(newMouseLocation)) {
                    mouseLocation.setLocation(newMouseLocation);
                    pipetteWindow.setLocation(mouseLocation.x - pipetteWindow.getWidth() / 2, 
                        mouseLocation.y - pipetteWindow.getHeight() / 2);
                    pipetteWindow.setCursor(pipetteCursor);
                  }
                }
              });
            timer.start();
            pipetteWindow.getRootPane().getInputMap(JRootPane.WHEN_IN_FOCUSED_WINDOW).
                put(KeyStroke.getKeyStroke("ESCAPE"), "Close");
            final AbstractAction closeAction = new AbstractAction() {
                public void actionPerformed(ActionEvent ev) {
                  timer.stop();
                  pipetteWindow.dispose();
                }
              };
            pipetteWindow.getRootPane().getActionMap().put("Close", closeAction);
            pipetteWindow.addWindowFocusListener(new WindowFocusListener() {
                public void windowLostFocus(WindowEvent ev) {
                  closeAction.actionPerformed(null);
                }
                public void windowGainedFocus(WindowEvent ev) {
                }
              });
            pipetteWindow.addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent ev) {
                  try {
                    closeAction.actionPerformed(null);
                    getColorSelectionModel().setSelectedColor(getColorAtMouseLocation());
                  } catch (AWTException ex) {
                    ex.printStackTrace();
                  }
                }
              });
            pipetteWindow.setVisible(true);
          }
          private Color getColorAtMouseLocation() throws AWTException {
            BufferedImage screenCapture = new Robot().createScreenCapture(
                new Rectangle(MouseInfo.getPointerInfo().getLocation(), new Dimension(1, 1)));
            int [] pixel = screenCapture.getRGB(0, 0, 1, 1, null, 0, 1);
            return new Color(pixel [0]);
          }
        };
      pipetteAction.putValue(Action.SMALL_ICON, 
          new ImageIcon(OperatingSystem.isMacOSX()
              ? ColorButton.class.getResource("resources/cursors/pipette16x16-macosx.png")
              : ColorButton.class.getResource("resources/cursors/pipette16x16.png")));
      JButton pipetteButton = new JButton(pipetteAction);
      pipetteButton.setFocusable(false);
      pipetteButton.setPreferredSize(new Dimension(30, 30));
      JLabel rgbLabel = new JLabel(SwingTools.getLocalizedLabelText(this.preferences, ColorButton.class, "rgbLabel.text"));
      this.rgbTextField = new JFormattedTextField(new Format() {
          @Override
          public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            toAppendTo.append(String.format("#%6X", ((Color)obj).getRGB() & 0xFFFFFF).replace(' ', '0'));
            pos.setEndIndex(pos.getEndIndex() + 7);
            return toAppendTo;
          }
          @Override
          public Object parseObject(String source, ParsePosition pos) {
            if (source.length() == 7 && source.charAt(0) == '#') {
              try {                
                Color color = Color.decode(source);
                pos.setIndex(pos.getIndex() + 7);
                return color;
              } catch (NumberFormatException ex) {
              }
            }
            return null;
          }
        });
      this.rgbTextField.setColumns(5);
      this.rgbTextField.getDocument().addDocumentListener(new DocumentListener() {
          public void removeUpdate(DocumentEvent ev) {
            changedUpdate(ev);
          }
          public void insertUpdate(DocumentEvent ev) {
            changedUpdate(ev);
          }
          public void changedUpdate(DocumentEvent ev) {
            try {
              rgbTextField.commitEdit();
              getColorSelectionModel().setSelectedColor((Color)rgbTextField.getValue());
            } catch (ParseException ex) {
            }
          }
        });
      JLabel ralLabel = new JLabel(SwingTools.getLocalizedLabelText(this.preferences, ColorButton.class, "ralLabel.text"));
      this.ralComboBox = new PaletteComboBox(ColorCode.RAL_COLORS);
      ItemListener paletteChangeListener = new ItemListener() {
          public void itemStateChanged(ItemEvent ev) {
            ColorCode ralColor = (ColorCode)((JComboBox)ev.getSource()).getSelectedItem();
            if (ralColor != null) {
              getColorSelectionModel().setSelectedColor(new Color(ralColor.getRGB()));
            }
          }
        };
      this.ralComboBox.addItemListener(paletteChangeListener);
      JLabel creativeCommonsLabel = new JLabel(
          SwingTools.getLocalizedLabelText(this.preferences, ColorButton.class, "creativeCommonsLabel.text"));
      this.creativeCommonsComboBox = new PaletteComboBox(ColorCode.CREATIVE_COMMONS_COLORS);
      this.creativeCommonsComboBox.addItemListener(paletteChangeListener);
      if (!OperatingSystem.isMacOSX()) {
        rgbLabel.setDisplayedMnemonic(KeyStroke.getKeyStroke(
            this.preferences.getLocalizedString(ColorButton.class, "rgbLabel.mnemonic")).getKeyCode());
        rgbLabel.setLabelFor(this.rgbTextField);
        ralLabel.setDisplayedMnemonic(KeyStroke.getKeyStroke(
            this.preferences.getLocalizedString(ColorButton.class, "ralLabel.mnemonic")).getKeyCode());
        ralLabel.setLabelFor(this.ralComboBox);
        creativeCommonsLabel.setDisplayedMnemonic(KeyStroke.getKeyStroke(
            this.preferences.getLocalizedString(ColorButton.class, "creativeCommonsLabel.mnemonic")).getKeyCode());
        creativeCommonsLabel.setLabelFor(this.creativeCommonsComboBox);
      }
      // Layout components
      setLayout(new GridBagLayout());
      int labelAlignment = GridBagConstraints.LINE_START;
      add(this.grayColorChart, new GridBagConstraints(
          0, 0, 1, 7, 0, 0, GridBagConstraints.CENTER, 
          GridBagConstraints.BOTH, new Insets(0, 0, 0, 5), 0, 0));
      add(this.colorChart, new GridBagConstraints(
          1, 0, 1, 7, 0, 0, GridBagConstraints.CENTER, 
          GridBagConstraints.BOTH, new Insets(0, 0, 0, 10), 0, 0));           
      add(colorLabel, new GridBagConstraints(
          2, 0, 1, 1, 0, 0, labelAlignment, 
          GridBagConstraints.NONE, new Insets(0, 0, 8, 5), 0, 0));           
      add(this.colorComponent, new GridBagConstraints(
          3, 0, 1, 1, 0, 0, GridBagConstraints.LINE_START, 
          GridBagConstraints.HORIZONTAL, new Insets(0, 0, 8, 0), 0, 0));
      add(pipetteButton, new GridBagConstraints(
          4, 0, 1, 1, 0, 0, GridBagConstraints.CENTER, 
          GridBagConstraints.NONE, new Insets(0, 5, 8, 0), 0, 0));
      add(rgbLabel, new GridBagConstraints(
          2, 1, 3, 1, 0, 0, labelAlignment, 
          GridBagConstraints.NONE, new Insets(0, 0, 2, 0), 0, 0));           
      add(this.rgbTextField, new GridBagConstraints(
          2, 2, 3, 1, 0, 0, GridBagConstraints.LINE_START, 
          GridBagConstraints.HORIZONTAL, 
          OperatingSystem.isMacOSX() 
              ? new Insets(0, 1, 5, 1) 
              : new Insets(0, 0, 5, 0), 0, 0));           
      add(ralLabel, new GridBagConstraints(
          2, 3, 3, 1, 0, 0, labelAlignment, 
          GridBagConstraints.NONE, new Insets(0, 0, 2, 0), 0, 0));           
      add(this.ralComboBox, new GridBagConstraints(
          2, 4, 3, 1, 0, 0, GridBagConstraints.LINE_START, 
          GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 0), 0, 0));           
      add(creativeCommonsLabel, new GridBagConstraints(
          2, 5, 3, 1, 0, 0, labelAlignment, 
          GridBagConstraints.NONE, new Insets(0, 0, 2, 0), 0, 0));           
      add(this.creativeCommonsComboBox, new GridBagConstraints(
          2, 6, 3, 1, 0, 0, GridBagConstraints.LINE_START, 
          GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
      getColorSelectionModel().addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent ev) {
            updateChooser();
          }
        });
    }
    /**
     * Simulates a click on the button in the root pane with an OK action command.
     */
    private void clickOnOk() {
      JRootPane rootPane = (JRootPane)SwingUtilities.getAncestorOfClass(JRootPane.class, PalettesColorChooserPanel.this);
      if (rootPane != null) {
        for (JButton button : SwingTools.findChildren(rootPane, JButton.class)) {
          if ("OK".equals(button.getActionCommand())) {
            button.doClick();
          }
        }
      }
    }
    @Override
    public String getDisplayName() {
      return this.preferences.getLocalizedString(ColorButton.class, "chooserPanel.title");
    }
    @Override
    public Icon getSmallDisplayIcon() {
      return null;
    }
    @Override
    public Icon getLargeDisplayIcon() {
      return null;
    }
  }
