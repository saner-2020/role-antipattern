/*
 * Copyright the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui.monitor;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import javax.annotation.Nullable;
import org.bitcoinj.core.StoredBlock;
import org.bitcoinj.core.Transaction;
import org.bitcoinj.utils.MonetaryFormat;
import org.bitcoinj.wallet.Wallet;
import de.schildbach.wallet.R;
import de.schildbach.wallet.data.AddressBookEntry;
import de.schildbach.wallet.ui.CurrencyTextView;
import de.schildbach.wallet.util.WalletUtils;
import android.content.Context;
import android.graphics.Typeface;
import android.support.v7.recyclerview.extensions.ListAdapter;
import android.support.v7.util.DiffUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
/**
 * @author Andreas Schildbach
 */
public class BlockListAdapter extends ListAdapter<BlockListAdapter.ListItem, BlockListAdapter.ViewHolder> {
    public static List<ListItem> buildListItems(final Context context, final List<StoredBlock> blocks, final Date time,
            final MonetaryFormat format, final @Nullable Set<Transaction> transactions, final @Nullable Wallet wallet,
            final @Nullable Map<String, AddressBookEntry> addressBook) {
        final List<ListItem> items = new ArrayList<>(blocks.size());
        for (final StoredBlock block : blocks)
            items.add(new ListItem(context, block, time, format, transactions, wallet, addressBook));
        return items;
    }
    private static final int ROW_BASE_CHILD_COUNT = 2;
    private static final int ROW_INSERT_INDEX = 1;
    private final LayoutInflater inflater;
    @Nullable
    private final OnClickListener onClickListener;
    public BlockListAdapter(final Context context, final @Nullable OnClickListener onClickListener) {
        super(new DiffUtil.ItemCallback<ListItem>() {
            @Override
            public boolean areItemsTheSame(final ListItem oldItem, final ListItem newItem) {
                return oldItem.blockHash.equals(newItem.blockHash);
            }
            @Override
            public boolean areContentsTheSame(final ListItem oldItem, final ListItem newItem) {
                if (!Objects.equals(oldItem.time, newItem.time))
                    return false;
                return true;
            }
        });
        inflater = LayoutInflater.from(context);
        this.onClickListener = onClickListener;
    }
    @Override
    public ViewHolder onCreateViewHolder(final ViewGroup parent, final int viewType) {
        return new ViewHolder(inflater.inflate(R.layout.block_row, parent, false));
    }
    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final ListItem listItem = getItem(position);
        holder.heightView.setText(Integer.toString(listItem.height));
        holder.timeView.setText(listItem.time);
        holder.miningRewardAdjustmentView.setVisibility(listItem.isMiningRewardHalvingPoint ? View.VISIBLE : View.GONE);
        holder.miningDifficultyAdjustmentView
                .setVisibility(listItem.isDifficultyTransitionPoint ? View.VISIBLE : View.GONE);
        holder.hashView.setText(WalletUtils.formatHash(null, listItem.blockHash.toString(), 8, 0, ' '));
        final int transactionChildCount = holder.transactionsViewGroup.getChildCount() - ROW_BASE_CHILD_COUNT;
        int iTransactionView = 0;
        for (final BlockListAdapter.ListItem.ListTransaction tx : listItem.transactions) {
            final View view;
            if (iTransactionView < transactionChildCount) {
                view = holder.transactionsViewGroup.getChildAt(ROW_INSERT_INDEX + iTransactionView);
            } else {
                view = inflater.inflate(R.layout.block_row_transaction, null);
                holder.transactionsViewGroup.addView(view, ROW_INSERT_INDEX + iTransactionView);
            }
            bindTransactionView(view, listItem.format, tx);
            iTransactionView++;
        }
        final int leftoverTransactionViews = transactionChildCount - iTransactionView;
        if (leftoverTransactionViews > 0)
            holder.transactionsViewGroup.removeViews(ROW_INSERT_INDEX + iTransactionView, leftoverTransactionViews);
        final OnClickListener onClickListener = this.onClickListener;
        if (onClickListener != null) {
            holder.menuView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(final View v) {
                    onClickListener.onBlockMenuClick(v, listItem.blockHash);
                }
            });
        }
    }
    private void bindTransactionView(final View row, final MonetaryFormat format, final ListItem.ListTransaction tx) {
        // receiving or sending
        final TextView rowFromTo = (TextView) row.findViewById(R.id.block_row_transaction_fromto);
        rowFromTo.setText(tx.fromTo);
        // address
        final TextView rowAddress = (TextView) row.findViewById(R.id.block_row_transaction_address);
        rowAddress.setText(tx.label != null ? tx.label : tx.address.toBase58());
        rowAddress.setTypeface(tx.label != null ? Typeface.DEFAULT : Typeface.MONOSPACE);
        // value
        final CurrencyTextView rowValue = (CurrencyTextView) row.findViewById(R.id.block_row_transaction_value);
        rowValue.setAlwaysSigned(true);
        rowValue.setFormat(format);
        rowValue.setAmount(tx.value);
    }
}
