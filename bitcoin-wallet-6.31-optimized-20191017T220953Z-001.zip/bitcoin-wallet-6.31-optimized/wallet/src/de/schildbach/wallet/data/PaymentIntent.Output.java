/*
 * Copyright 2014-2015 the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.data;
import org.bitcoinj.core.Coin;
import org.bitcoinj.core.ScriptException;
import org.bitcoinj.protocols.payments.PaymentProtocol;
import org.bitcoinj.protocols.payments.PaymentProtocolException;
import org.bitcoinj.script.Script;
import de.schildbach.wallet.Constants;
import android.os.Parcel;
import android.os.Parcelable;
/**
 * @author Andreas Schildbach
 */
public final static class Output implements Parcelable {
        public final Coin amount;
        public final Script script;
        public Output(final Coin amount, final Script script) {
            this.amount = amount;
            this.script = script;
        }
        public static Output valueOf(final PaymentProtocol.Output output)
                throws PaymentProtocolException.InvalidOutputs {
            try {
                final Script script = new Script(output.scriptData);
                return new PaymentIntent.Output(output.amount, script);
            } catch (final ScriptException x) {
                throw new PaymentProtocolException.InvalidOutputs(
                        "unparseable script in output: " + Constants.HEX.encode(output.scriptData));
            }
        }
        public boolean hasAmount() {
            return amount != null && amount.signum() != 0;
        }
        @Override
        public String toString() {
            final StringBuilder builder = new StringBuilder();
            builder.append(getClass().getSimpleName());
            builder.append('[');
            builder.append(hasAmount() ? amount.toPlainString() : "null");
            builder.append(',');
            if (script.isSentToAddress() || script.isPayToScriptHash())
                builder.append(script.getToAddress(Constants.NETWORK_PARAMETERS));
            else if (script.isSentToRawPubKey())
                builder.append(Constants.HEX.encode(script.getPubKey()));
            else if (script.isSentToMultiSig())
                builder.append("multisig");
            else
                builder.append("unknown");
            builder.append(']');
            return builder.toString();
        }
        @Override
        public int describeContents() {
            return 0;
        }
        @Override
        public void writeToParcel(final Parcel dest, final int flags) {
            dest.writeSerializable(amount);
            final byte[] program = script.getProgram();
            dest.writeInt(program.length);
            dest.writeByteArray(program);
        }
        public static final Parcelable.Creator<Output> CREATOR = new Parcelable.Creator<Output>() {
            @Override
            public Output createFromParcel(final Parcel in) {
                return new Output(in);
            }
            @Override
            public Output[] newArray(final int size) {
                return new Output[size];
            }
        };
        private Output(final Parcel in) {
            amount = (Coin) in.readSerializable();
            final int programLength = in.readInt();
            final byte[] program = new byte[programLength];
            in.readByteArray(program);
            script = new Script(program);
        }
    }
