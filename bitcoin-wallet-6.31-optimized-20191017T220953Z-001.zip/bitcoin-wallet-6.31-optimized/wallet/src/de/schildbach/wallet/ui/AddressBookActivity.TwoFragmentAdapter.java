/*
 * Copyright 2011-2015 the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
/**
 * @author Andreas Schildbach
 */
private static class TwoFragmentAdapter extends PagerAdapter {
        private final FragmentManager fragmentManager;
        private final Fragment left;
        private final Fragment right;
        private FragmentTransaction currentTransaction = null;
        private Fragment currentPrimaryItem = null;
        public TwoFragmentAdapter(final FragmentManager fragmentManager, final Fragment left, final Fragment right) {
            this.fragmentManager = fragmentManager;
            this.left = left;
            this.right = right;
        }
        @Override
        public int getCount() {
            return 2;
        }
        @Override
        public Object instantiateItem(final ViewGroup container, final int position) {
            if (currentTransaction == null)
                currentTransaction = fragmentManager.beginTransaction();
            final String tag = (position == 0) ? TAG_LEFT : TAG_RIGHT;
            final Fragment fragment = (position == 0) ? left : right;
            currentTransaction.add(container.getId(), fragment, tag);
            if (fragment != currentPrimaryItem) {
                fragment.setMenuVisibility(false);
                fragment.setUserVisibleHint(false);
            }
            return fragment;
        }
        @Override
        public void destroyItem(final ViewGroup container, final int position, final Object object) {
            throw new UnsupportedOperationException();
        }
        @Override
        public void setPrimaryItem(final ViewGroup container, final int position, final Object object) {
            final Fragment fragment = (Fragment) object;
            if (fragment != currentPrimaryItem) {
                if (currentPrimaryItem != null) {
                    currentPrimaryItem.setMenuVisibility(false);
                    currentPrimaryItem.setUserVisibleHint(false);
                }
                if (fragment != null) {
                    fragment.setMenuVisibility(true);
                    fragment.setUserVisibleHint(true);
                }
                currentPrimaryItem = fragment;
            }
        }
        @Override
        public void finishUpdate(final ViewGroup container) {
            if (currentTransaction != null) {
                currentTransaction.commitAllowingStateLoss();
                currentTransaction = null;
                fragmentManager.executePendingTransactions();
            }
        }
        @Override
        public boolean isViewFromObject(final View view, final Object object) {
            return ((Fragment) object).getView() == view;
        }
    }
