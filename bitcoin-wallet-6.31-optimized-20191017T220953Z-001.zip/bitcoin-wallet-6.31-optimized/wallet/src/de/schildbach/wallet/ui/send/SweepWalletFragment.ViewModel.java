/*
 * Copyright 2014-2015 the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui.send;
import javax.annotation.Nullable;
import org.bitcoinj.core.Transaction;
import org.bitcoinj.core.VersionedChecksummedBytes;
import org.bitcoinj.wallet.Wallet;
import de.schildbach.wallet.WalletApplication;
import de.schildbach.wallet.data.DynamicFeeLiveData;
import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
/**
 * @author Andreas Schildbach
 */
public static class ViewModel extends AndroidViewModel {
        private final WalletApplication application;
        private DynamicFeeLiveData dynamicFees;
        private State state = State.DECODE_KEY;
        @Nullable
        private VersionedChecksummedBytes privateKeyToSweep = null;
        @Nullable
        private Wallet walletToSweep = null;
        @Nullable
        private Transaction sentTransaction = null;
        public ViewModel(final Application application) {
            super(application);
            this.application = (WalletApplication) application;
        }
        public DynamicFeeLiveData getDynamicFees() {
            if (dynamicFees == null)
                dynamicFees = new DynamicFeeLiveData(application);
            return dynamicFees;
        }
    }
