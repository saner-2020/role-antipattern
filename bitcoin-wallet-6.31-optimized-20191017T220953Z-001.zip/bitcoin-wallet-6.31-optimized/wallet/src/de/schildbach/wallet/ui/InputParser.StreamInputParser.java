/*
 * Copyright 2013-2015 the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import org.bitcoinj.core.Transaction;
import org.bitcoinj.core.VerificationException;
import org.bitcoinj.protocols.payments.PaymentProtocol;
import org.bitcoinj.protocols.payments.PaymentProtocolException;
import de.schildbach.wallet.R;
import de.schildbach.wallet.util.Io;
/**
 * @author Andreas Schildbach
 */
public abstract static class StreamInputParser extends InputParser {
        private final String inputType;
        private final InputStream is;
        public StreamInputParser(final String inputType, final InputStream is) {
            this.inputType = inputType;
            this.is = is;
        }
        @Override
        public void parse() {
            if (PaymentProtocol.MIMETYPE_PAYMENTREQUEST.equals(inputType)) {
                try (final ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
                    Io.copy(is, baos);
                    parseAndHandlePaymentRequest(baos.toByteArray());
                } catch (final IOException x) {
                    log.info("i/o error while fetching payment request", x);
                    error(R.string.input_parser_io_error, x.getMessage());
                } catch (final PaymentProtocolException.PkiVerificationException x) {
                    log.info("got unverifyable payment request", x);
                    error(R.string.input_parser_unverifyable_paymentrequest, x.getMessage());
                } catch (final PaymentProtocolException x) {
                    log.info("got invalid payment request", x);
                    error(R.string.input_parser_invalid_paymentrequest, x.getMessage());
                } finally {
                    try {
                        is.close();
                    } catch (IOException x) {
                        x.printStackTrace();
                    }
                }
            } else {
                cannotClassify(inputType);
            }
        }
        @Override
        protected final void handleDirectTransaction(final Transaction transaction) throws VerificationException {
            throw new UnsupportedOperationException();
        }
    }
