/*
 * Copyright 2013-2015 the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui;
import java.io.IOException;
import org.bitcoinj.core.Address;
import org.bitcoinj.core.AddressFormatException;
import org.bitcoinj.core.DumpedPrivateKey;
import org.bitcoinj.core.ProtocolException;
import org.bitcoinj.core.Transaction;
import org.bitcoinj.core.VersionedChecksummedBytes;
import org.bitcoinj.core.WrongNetworkException;
import org.bitcoinj.crypto.BIP38PrivateKey;
import org.bitcoinj.protocols.payments.PaymentProtocolException;
import org.bitcoinj.uri.BitcoinURI;
import org.bitcoinj.uri.BitcoinURIParseException;
import de.schildbach.wallet.Constants;
import de.schildbach.wallet.R;
import de.schildbach.wallet.data.PaymentIntent;
import de.schildbach.wallet.util.Qr;
/**
 * @author Andreas Schildbach
 */
public abstract static class StringInputParser extends InputParser {
        private final String input;
        public StringInputParser(final String input) {
            this.input = input;
        }
        @Override
        public void parse() {
            if (input.startsWith("BITCOIN:-")) {
                try {
                    final byte[] serializedPaymentRequest = Qr.decodeBinary(input.substring(9));
                    parseAndHandlePaymentRequest(serializedPaymentRequest);
                } catch (final IOException x) {
                    log.info("i/o error while fetching payment request", x);
                    error(R.string.input_parser_io_error, x.getMessage());
                } catch (final PaymentProtocolException.PkiVerificationException x) {
                    log.info("got unverifyable payment request", x);
                    error(R.string.input_parser_unverifyable_paymentrequest, x.getMessage());
                } catch (final PaymentProtocolException x) {
                    log.info("got invalid payment request", x);
                    error(R.string.input_parser_invalid_paymentrequest, x.getMessage());
                }
            } else if (input.startsWith("bitcoin:")) {
                try {
                    final BitcoinURI bitcoinUri = new BitcoinURI(null, input);
                    final Address address = bitcoinUri.getAddress();
                    if (address != null && !Constants.NETWORK_PARAMETERS.equals(address.getParameters()))
                        throw new BitcoinURIParseException("mismatched network");
                    handlePaymentIntent(PaymentIntent.fromBitcoinUri(bitcoinUri));
                } catch (final BitcoinURIParseException x) {
                    log.info("got invalid bitcoin uri: '" + input + "'", x);
                    error(R.string.input_parser_invalid_bitcoin_uri, input);
                }
            } else if (PATTERN_TRANSACTION.matcher(input).matches()) {
                try {
                    final Transaction tx = new Transaction(Constants.NETWORK_PARAMETERS,
                            Qr.decodeDecompressBinary(input));
                    handleDirectTransaction(tx);
                } catch (final IOException x) {
                    log.info("i/o error while fetching transaction", x);
                    error(R.string.input_parser_invalid_transaction, x.getMessage());
                } catch (final ProtocolException x) {
                    log.info("got invalid transaction", x);
                    error(R.string.input_parser_invalid_transaction, x.getMessage());
                }
            } else {
                try {
                    handlePrivateKey(DumpedPrivateKey.fromBase58(Constants.NETWORK_PARAMETERS, input));
                } catch (AddressFormatException x) {
                    try {
                        handlePrivateKey(BIP38PrivateKey.fromBase58(Constants.NETWORK_PARAMETERS, input));
                    } catch (final AddressFormatException x2) {
                        try {
                            handlePaymentIntent(PaymentIntent
                                    .fromAddress(Address.fromBase58(Constants.NETWORK_PARAMETERS, input), null));
                        } catch (WrongNetworkException x3) {
                            log.info("detected address, but wrong network: " + x3.verCode, x3);
                            error(R.string.input_parser_invalid_address);
                        } catch (AddressFormatException x3) {
                            cannotClassify(input);
                        }
                    }
                }
            }
        }
        protected void handlePrivateKey(final VersionedChecksummedBytes key) {
            final Address address = new Address(Constants.NETWORK_PARAMETERS,
                    ((DumpedPrivateKey) key).getKey().getPubKeyHash());
            handlePaymentIntent(PaymentIntent.fromAddress(address, null));
        }
    }
