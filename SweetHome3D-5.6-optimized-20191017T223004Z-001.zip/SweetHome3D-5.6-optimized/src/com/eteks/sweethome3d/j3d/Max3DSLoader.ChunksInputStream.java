/*
 * Max3DSLoader.java 24 Nov. 2013
 *
 * Sweet Home 3D, Copyright (c) 2013 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.j3d;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Stack;
import com.sun.j3d.loaders.IncorrectFormatException;
/**
 * A loader for 3DS streams.<br> 
 * Mainly an adaptation in Java 3D of the GNU LGPL C library available at www.lib3ds.org.
 * Note: this class is compatible with Java 3D 1.3.
 * @author Emmanuel Puybaret
 */
private static class ChunksInputStream extends FilterInputStream {
    private Stack<Chunk3DS> stack;
    private URL             baseUrl;
    public ChunksInputStream(InputStream in, URL baseUrl) {
      super(in);
      this.stack = new Stack<Chunk3DS>();
      this.baseUrl = baseUrl;
    }
    public URL getBaseURL() {
      return this.baseUrl;
    }
    /**
     * Reads the next chunk id and length, pushes it in the stack and returns it.
     * <code>null</code> will be returned if the end of the stream is reached.
     */
    public Chunk3DS readChunkHeader() throws IOException {
      short chunkId;
      try {
        chunkId = readLittleEndianShort(false);
      } catch (EOFException ex) {
        return null;
      }
      Chunk3DS chunk = new Chunk3DS(chunkId, readLittleEndianUnsignedInt(false));
      this.stack.push(chunk);
      return chunk;
    }
    /**
     * Pops the chunk at the top of stack and checks it was entirely read. 
     */
    public void releaseChunk() {      
      Chunk3DS chunk = this.stack.pop();
      if (chunk.getLength() != chunk.getReadLength()) {
        throw new IncorrectFormatException("Chunk " + chunk.getID() + " invalid length. " 
            + "Expected to read " + chunk.getLength() + " bytes, but actually read " + chunk.getReadLength() + " bytes");
      }
      if (!this.stack.isEmpty()) {
        this.stack.peek().incrementReadLength(chunk.getLength());
      }      
    }
    /**
     * Returns <code>true</code> if the current chunk end was reached.
     */
    public boolean isChunckEndReached() {
      Chunk3DS chunk = this.stack.peek();
      return chunk.getLength() == chunk.getReadLength();
    }
    /**
     * Reads the stream until the end of the current chunk.
     */
    public void readUntilChunkEnd() throws IOException {
      Chunk3DS chunk = this.stack.peek();
      long remainingLength = chunk.getLength() - chunk.getReadLength();
      for (long length = remainingLength; length > 0; length--) {
        if (this.in.read() < 0) {
          throw new IncorrectFormatException("Chunk " + chunk.getID() + " too short");
        }
      }
      chunk.incrementReadLength(remainingLength);
    }
    /**
     * Returns the unsigned byte read from this stream.
     */
    public short readUnsignedByte() throws IOException {
      int b = this.in.read();
      if (b == -1) {
        throw new EOFException();
      } else {
        this.stack.peek().incrementReadLength(1);
        return (short)(b & 0xFF);
      }
    }
    /**
     * Returns the unsigned short read from this stream.
     */
    public int readLittleEndianUnsignedShort() throws IOException {
      return (int)readLittleEndianShort(true) & 0xFFFF;
    }
    /**
     * Returns the short read from this stream.
     */
    public short readLittleEndianShort() throws IOException {
      return readLittleEndianShort(true);
    }
    private short readLittleEndianShort(boolean incrementReadLength) throws IOException {
      int b1 = this.in.read();
      if (b1 == -1) {
        throw new EOFException();
      }
      int b2 = this.in.read();
      if (b2 == -1) {
        throw new IncorrectFormatException("Can't read short");
      }
      if (incrementReadLength) {
        this.stack.peek().incrementReadLength(2);
      }
      return (short)((b2 << 8) | b1);
    }
    /**
     * Returns the float read from this stream.
     */
    public float readLittleEndianFloat() throws IOException {
      return Float.intBitsToFloat(readLittleEndianInt(true));
    }
    /**
     * Returns the unsigned integer read from this stream.
     */
    public long readLittleEndianUnsignedInt() throws IOException {
      return readLittleEndianUnsignedInt(true);
    }
    private long readLittleEndianUnsignedInt(boolean incrementReadLength) throws IOException {
      return (long)readLittleEndianInt(incrementReadLength) & 0xFFFFFFFFL;
    }
    /**
     * Returns the integer read from this stream.
     */
    public int readLittleEndianInt() throws IOException {
      return readLittleEndianInt(true);
    }
    private int readLittleEndianInt(boolean incrementReadLength) throws IOException {
      int b1 = this.in.read();
      if (b1 == -1) {
        throw new EOFException();
      }
      int b2 = this.in.read();
      int b3 = this.in.read();
      int b4 = this.in.read();
      if (b2 == -1 || b3 == -1 || b4 == -1) {
        throw new IncorrectFormatException("Can't read int");
      }
      if (incrementReadLength) {
        this.stack.peek().incrementReadLength(4);
      }
      return (b4 << 24) | (b3 << 16) | (b2 << 8) | b1;
    }
    /**
     * Returns the string read from this stream.
     */
    public String readString() throws IOException {
      ByteArrayOutputStream stringBytes = new ByteArrayOutputStream(256);
      int b;
      // Read characters until terminal 0
      while ((b = this.in.read()) != -1 && b != 0) {
        stringBytes.write((byte)b);
      }
      if (b == -1) {
        throw new IncorrectFormatException("Unexpected end of file");
      }
      this.stack.peek().incrementReadLength(stringBytes.size() + 1);
      return stringBytes.toString("ISO-8859-1");
    }
  }
