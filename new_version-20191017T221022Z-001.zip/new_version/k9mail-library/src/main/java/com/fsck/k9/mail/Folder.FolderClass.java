package com.fsck.k9.mail;

public enum FolderClass {
        NONE, NO_CLASS, INHERITED, FIRST_CLASS, SECOND_CLASS
    }