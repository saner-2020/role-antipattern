/*
 * WizardControllerTest.java 7 juin 07
 *
 * Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>. All Rights Reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.junit;
import java.awt.event.ActionEvent;
import java.net.URL;
import javax.swing.AbstractAction;
import javax.swing.AbstractButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import com.eteks.sweethome3d.model.UserPreferences;
import com.eteks.sweethome3d.viewcontroller.View;
import com.eteks.sweethome3d.viewcontroller.ViewFactory;
import com.eteks.sweethome3d.viewcontroller.WizardController;
/**
 * Tests {@link com.eteks.sweethome3d.viewcontroller.WizardController wizard controller}.
 * @author Emmanuel Puybaret
 */
private static class ControllerTest extends WizardController {
    private static URL stepIcon = WizardController.class.getResource("resources/backgroundImageWizard.png");
    public ControllerTest(UserPreferences preferences, ViewFactory viewFactory) {
      super(preferences, viewFactory);
      // Choose step to display
      setStepState(new FirstStep());            
    }
    @Override
    public void finish() {
      JOptionPane.showMessageDialog(null, "Wizard finished");
    }
    // First step of wizard
    private class FirstStep extends WizardControllerStepState {
      @Override
      public void enter() {
        setNextStepEnabled(true);
      }
      @Override
      public View getView() {
        return new FirstStepView();
      }
      @Override
      public URL getIcon() {
        return stepIcon;
      }
      @Override
      public boolean isFirstStep() {
        return true;
      }
      @Override
      public void goToNextStep() {
        setStepState(new SecondStep());
      }
    }
    // First step view is a simple label
    private static class FirstStepView extends JLabel implements View {
      public FirstStepView() {
        super("First step");
      }
    }
    // Second step of wizard
    private class SecondStep extends WizardControllerStepState {
      @Override
      public View getView() {        
        return new SecondStepView(this);
      }
      @Override
      public URL getIcon() {
        return stepIcon;
      }
      @Override
      public boolean isLastStep() {
        return true;
      }
      @Override
      public void goBackToPreviousStep() {
        setStepState(new FirstStep());
      }
      public void setFinishEnabled(boolean enabled) {
        // Activate next step when check box is selected
        setNextStepEnabled(enabled);
      }
    }
    // Second step view is a panel displaying a check box that enables next step
    private static class SecondStepView extends JPanel implements View {
      public SecondStepView(final SecondStep secondStepController) {
        add(new JLabel("Finish ?"));
        add(new JCheckBox(new AbstractAction("Yes") {
            public void actionPerformed(ActionEvent ev) {
              // Activate next step when check box is selected
              secondStepController.setFinishEnabled(
                  ((AbstractButton)ev.getSource()).isSelected());
            }
          }));
     }
    }
  }
