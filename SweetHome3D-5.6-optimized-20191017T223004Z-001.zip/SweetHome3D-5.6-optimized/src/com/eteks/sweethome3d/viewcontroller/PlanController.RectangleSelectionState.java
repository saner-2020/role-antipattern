/*
 * PlanController.java 2 juin 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import java.util.ArrayList;
import java.util.List;
import com.eteks.sweethome3d.model.Camera;
import com.eteks.sweethome3d.model.HomeFurnitureGroup;
import com.eteks.sweethome3d.model.HomePieceOfFurniture;
import com.eteks.sweethome3d.model.Selectable;
/**
 * A MVC controller for the plan view.
 * @author Emmanuel Puybaret
 */
private class RectangleSelectionState extends ControllerState {
    private List<Selectable> selectedItemsMousePressed;  
    private boolean          ignoreRectangleSelection;
    private boolean          mouseMoved;
    @Override
    public Mode getMode() {
      return Mode.SELECTION;
    }
    @Override
    public boolean isModificationState() {
      return true;
    }
    @Override
    public void enter() {
      Selectable itemUnderCursor = getSelectableItemAt(getXLastMousePress(), getYLastMousePress());
      // If no item under cursor and shift wasn't down, deselect all
      if (itemUnderCursor == null && !wasShiftDownLastMousePress()) {
        deselectAll();
      } 
      // Store current selection
      this.selectedItemsMousePressed = new ArrayList<Selectable>(home.getSelectedItems());
      List<HomePieceOfFurniture> furniture = home.getFurniture();
      this.ignoreRectangleSelection = false;
      for (Selectable item : this.selectedItemsMousePressed) {
        if ((item instanceof HomePieceOfFurniture)
            && !furniture.contains(item)) {
          this.ignoreRectangleSelection = true;
          break;
        }
      }
      this.mouseMoved = false;
    }
    @Override
    public void moveMouse(float x, float y) {
      this.mouseMoved = true;
      if (!this.ignoreRectangleSelection) {
        updateSelectedItems(getXLastMousePress(), getYLastMousePress(), 
            x, y, this.selectedItemsMousePressed);
        // Update rectangle feedback
        PlanView planView = getView();
        planView.setRectangleFeedback(
            getXLastMousePress(), getYLastMousePress(), x, y);
        planView.makePointVisible(x, y);
      }
    }
    @Override
    public void releaseMouse(float x, float y) {
      // If cursor didn't move
      if (!this.mouseMoved) {
        Selectable itemUnderCursor = getSelectableItemAt(x, y, false);
        // Toggle selection of the item under cursor 
        if (itemUnderCursor != null) {
          if (this.selectedItemsMousePressed.contains(itemUnderCursor)) {
            this.selectedItemsMousePressed.remove(itemUnderCursor);
          } else {
            for (int i = this.selectedItemsMousePressed.size() - 1; i >= 0; i--) {
              // Remove any camera or group of a selected piece from current selection 
              Selectable item = this.selectedItemsMousePressed.get(i);
              if (item instanceof Camera
                  || (itemUnderCursor instanceof HomePieceOfFurniture
                      && item instanceof HomeFurnitureGroup
                      && ((HomeFurnitureGroup)item).getAllFurniture().contains(itemUnderCursor))
                  || (itemUnderCursor instanceof HomeFurnitureGroup
                      && item instanceof HomePieceOfFurniture
                      && ((HomeFurnitureGroup)itemUnderCursor).getAllFurniture().contains(item))) {
                this.selectedItemsMousePressed.remove(i);
              }
            }
            // Let the camera belong to selection only if no item are selected
            if (!(itemUnderCursor instanceof Camera)
                || this.selectedItemsMousePressed.size() == 0) {
              this.selectedItemsMousePressed.add(itemUnderCursor);
            }
          }
          selectItems(this.selectedItemsMousePressed, 
              home.isAllLevelsSelection() && wasShiftDownLastMousePress());
        }
      }      
      // Change state to SelectionState
      setState(getSelectionState());
    }
    @Override
    public void escape() {
      setState(getSelectionState());
    }
    @Override
    public void exit() {
      getView().deleteFeedback();
      this.selectedItemsMousePressed = null;
    }
    /**
     * Updates selection from <code>selectedItemsMousePressed</code> and the
     * items that intersects the rectangle at coordinates (<code>x0</code>,
     * <code>y0</code>) and (<code>x1</code>, <code>y1</code>).
     */
    private void updateSelectedItems(float x0, float y0, 
                                     float x1, float y1,
                                     List<Selectable> selectedItemsMousePressed) {
      List<Selectable> selectedItems;
      boolean shiftDown = wasShiftDownLastMousePress();
      if (shiftDown) {
        selectedItems = new ArrayList<Selectable>(selectedItemsMousePressed);
      } else {
        selectedItems = new ArrayList<Selectable>();
      }
      // For all the items that intersect with rectangle
      for (Selectable item : getSelectableItemsIntersectingRectangle(x0, y0, x1, y1)) {
        // Don't let the camera be able to be selected with a rectangle
        if (!(item instanceof Camera)) {
          // If shift was down at mouse press
          if (shiftDown) {
            // Toggle selection of item
            if (selectedItemsMousePressed.contains(item)) {
              selectedItems.remove(item);
            } else {
              selectedItems.add(item);
            }
          } else if (!selectedItemsMousePressed.contains(item)) {
            // Else select the wall
            selectedItems.add(item);
          }
        }
      }    
      // Update selection
      selectItems(selectedItems, home.isAllLevelsSelection() && shiftDown);
    }
  }
