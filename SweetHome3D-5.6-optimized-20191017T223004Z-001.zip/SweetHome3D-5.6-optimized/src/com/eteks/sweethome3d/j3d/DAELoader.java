/*
 * DAELoader.java 16 Mai 2010
 *
 * Sweet Home 3D, Copyright (c) 2010 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.j3d;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.SAXException;
import com.sun.j3d.loaders.IncorrectFormatException;
import com.sun.j3d.loaders.Loader;
import com.sun.j3d.loaders.LoaderBase;
import com.sun.j3d.loaders.ParsingErrorException;
import com.sun.j3d.loaders.Scene;
import com.sun.j3d.loaders.SceneBase;
/**
 * A loader for DAE Collada 1.4.1 format as specified by
 * <a href="http://www.khronos.org/files/collada_spec_1_4.pdf">http://www.khronos.org/files/collada_spec_1_4.pdf</a>.
 * All texture coordinates are considered to belong to the same set (for example UVSET0).<br>
 * Note: this class is compatible with Java 3D 1.3.
 * @author Emmanuel Puybaret
 * @author apptaro (bug fixes)
 */
public class DAELoader extends LoaderBase implements Loader {
  private Boolean useCaches;
  /**
   * Sets whether this loader should try or avoid accessing to URLs with cache.
   * @param useCaches <code>Boolean.TRUE</code>, <code>Boolean.FALSE</code>, or 
   *    <code>null</code> then caches will be used according to the value 
   *    returned by {@link URLConnection#getDefaultUseCaches()}.
   */
  public void setUseCaches(Boolean useCaches) {
    this.useCaches = Boolean.valueOf(useCaches);
  }
  /**
   * Returns the scene described in the given DAE file.
   */
  public Scene load(String file) throws FileNotFoundException, IncorrectFormatException, ParsingErrorException {
    URL baseUrl;
    try {
      if (this.basePath != null) {
        baseUrl = new File(this.basePath).toURI().toURL();
      } else {
        baseUrl = new File(file).toURI().toURL();
      } 
    } catch (MalformedURLException ex) {
      throw new FileNotFoundException(file);
    }
    return load(new BufferedInputStream(new FileInputStream(file)), baseUrl);
  }
  /**
   * Returns the scene described in the given DAE file url.
   */
  public Scene load(URL url) throws FileNotFoundException, IncorrectFormatException, ParsingErrorException {
    URL baseUrl = this.baseUrl;
    if (this.baseUrl == null) {
      baseUrl = url;
    } 
    InputStream in;
    try {
      in = openStream(url);
    } catch (IOException ex) {
      throw new FileNotFoundException("Can't read " + url);
    }
    return load(new BufferedInputStream(in), baseUrl);
  }
  /**
   * Returns an input stream ready to read data from the given URL.
   */
  private InputStream openStream(URL url) throws IOException {
    URLConnection connection = url.openConnection();
    if (this.useCaches != null) {
      connection.setUseCaches(this.useCaches.booleanValue());
    }
    return connection.getInputStream();
  }
  /**
   * Returns the scene described in the given DAE file stream.
   */
  public Scene load(Reader reader) throws FileNotFoundException, IncorrectFormatException, ParsingErrorException {
    throw new UnsupportedOperationException();
  }
  /**
   * Returns the scene described in the given DAE file.
   */
  private Scene load(InputStream in, URL baseUrl) throws FileNotFoundException {
    try {
      return parseXMLStream(in, baseUrl);
    } catch (IOException ex) {
      throw new ParsingErrorException(ex.getMessage());
    } finally {
      try {
        in.close();
      } catch (IOException ex) {
        throw new ParsingErrorException(ex.getMessage());
      }
    }
  }
  /**
   * Returns the scene parsed from a Collada XML stream. 
   */
  private Scene parseXMLStream(InputStream in, 
                               URL baseUrl) throws IOException {
    try {
      SceneBase scene = new SceneBase();
      SAXParserFactory factory = SAXParserFactory.newInstance();
      SAXParser saxParser = factory.newSAXParser();
      saxParser.parse(in, new DAEHandler(scene, baseUrl));
      return scene;
    } catch (ParserConfigurationException ex) {
      IOException ex2 = new IOException("Can't parse XML stream");
      ex2.initCause(ex);
      throw ex2;
    } catch (SAXException ex) {
      IOException ex2 = new IOException("Can't parse XML stream");
      ex2.initCause(ex);
      throw ex2;
    }
  }
  /**
   * SAX handler for DAE Collada stream.
   */
}
