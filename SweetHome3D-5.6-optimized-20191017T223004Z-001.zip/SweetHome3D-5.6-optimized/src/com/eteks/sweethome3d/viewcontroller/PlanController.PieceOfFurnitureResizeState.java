/*
 * PlanController.java 2 juin 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import com.eteks.sweethome3d.model.HomeDoorOrWindow;
import com.eteks.sweethome3d.model.HomePieceOfFurniture;
/**
 * A MVC controller for the plan view.
 * @author Emmanuel Puybaret
 */
private class PieceOfFurnitureResizeState extends ControllerState {
    private boolean                 magnetismEnabled;
    private boolean                 alignmentActivated;
    private float                   deltaXToResizePoint;
    private float                   deltaYToResizePoint;
    private ResizedPieceOfFurniture resizedPiece;
    private float                   resizedPieceWidthInPlan;
    private float []                topLeftPoint;
    private String                  widthResizeToolTipFeedback;
    private String                  depthResizeToolTipFeedback;
    private String                  heightResizeToolTipFeedback;
    @Override
    public Mode getMode() {
      return Mode.SELECTION;
    }
    @Override
    public boolean isModificationState() {
      return true;
    }
    @Override
    public boolean isBasePlanModificationState() {
      return this.resizedPiece != null
          && isPieceOfFurniturePartOfBasePlan(this.resizedPiece.getPieceOfFurniture());
    }
    @Override
    public void enter() {
      this.widthResizeToolTipFeedback = preferences.getLocalizedString(
          PlanController.class, "widthResizeToolTipFeedback");
      this.depthResizeToolTipFeedback = preferences.getLocalizedString(
          PlanController.class, "depthResizeToolTipFeedback");
      this.heightResizeToolTipFeedback = preferences.getLocalizedString(
          PlanController.class, "heightResizeToolTipFeedback");
      HomePieceOfFurniture selectedPiece = (HomePieceOfFurniture)home.getSelectedItems().get(0);
      this.resizedPiece = new ResizedPieceOfFurniture(selectedPiece);
      this.resizedPieceWidthInPlan = selectedPiece.getWidthInPlan();
      float [][] resizedPiecePoints = selectedPiece.getPoints();
      float [] resizePoint = resizedPiecePoints [2];
      this.deltaXToResizePoint = getXLastMousePress() - resizePoint [0];
      this.deltaYToResizePoint = getYLastMousePress() - resizePoint [1];
      this.topLeftPoint = resizedPiecePoints [0];
      this.magnetismEnabled = preferences.isMagnetismEnabled()
                              ^ wasMagnetismToggledLastMousePress();  
      this.alignmentActivated = wasAlignmentActivatedLastMousePress();
      PlanView planView = getView();
      planView.setResizeIndicatorVisible(true);
      planView.setToolTipFeedback(getToolTipFeedbackText(selectedPiece.getWidth(), selectedPiece.getDepth(), selectedPiece.getHeight()), 
          getXLastMousePress(), getYLastMousePress());
    }
    @Override
    public void moveMouse(float x, float y) {
      // Compute the new location and dimension of the piece to let 
      // its bottom right point be at mouse location
      PlanView planView = getView();
      HomePieceOfFurniture selectedPiece = this.resizedPiece.getPieceOfFurniture();
      float angle = selectedPiece.getAngle();
      double cos = Math.cos(angle); 
      double sin = Math.sin(angle); 
      float deltaX = x - this.deltaXToResizePoint - this.topLeftPoint [0];
      float deltaY = y - this.deltaYToResizePoint - this.topLeftPoint [1];
      float newWidth =  (float)(deltaY * sin + deltaX * cos);
      if (this.magnetismEnabled) {
        newWidth = preferences.getLengthUnit().getMagnetizedLength(newWidth, planView.getPixelLength());
      }
      newWidth = Math.min(Math.max(newWidth, preferences.getLengthUnit().getMinimumLength()), 
          preferences.getLengthUnit().getMaximumLength());
      float newDepth = this.resizedPiece.getDepth();
      float newHeight = this.resizedPiece.getHeight();
      boolean doorOrWindowBoundToWall = this.resizedPiece.isDoorOrWindowBoundToWall();
      // Manage constraints
      if (isProprortionallyResized(selectedPiece)) {
        // Use resizing scale based on width in plan
        float scale = newWidth / this.resizedPieceWidthInPlan;
        newWidth = this.resizedPiece.getWidth() * scale;
        newDepth = this.resizedPiece.getDepth() * scale;
        newHeight = this.resizedPiece.getHeight() * scale;
        doorOrWindowBoundToWall = newDepth == this.resizedPiece.getDepth();
      } else if (!selectedPiece.isWidthDepthDeformable()) {
        newDepth = this.resizedPiece.getDepth() * newWidth / this.resizedPiece.getWidth();
      } else if (!this.resizedPiece.isDoorOrWindowBoundToWall()
                 || !this.magnetismEnabled) {
        // Update piece depth if it's not a door a window 
        // or if it's a a door a window unbound to a wall when magnetism is enabled
        newDepth = (float)(deltaY * cos - deltaX * sin);
        if (this.magnetismEnabled) {
          newDepth = preferences.getLengthUnit().getMagnetizedLength(newDepth, planView.getPixelLength());
        }
        newDepth = Math.min(Math.max(newDepth, preferences.getLengthUnit().getMinimumLength()), 
            preferences.getLengthUnit().getMaximumLength());
        doorOrWindowBoundToWall = newDepth == this.resizedPiece.getDepth();
      }
      // Update piece size
      setPieceOfFurnitureSize(this.resizedPiece, newWidth, newDepth, newHeight);
      if (this.resizedPiece.isDoorOrWindowBoundToWall()) {
        // Maintain boundToWall flag
        ((HomeDoorOrWindow)selectedPiece).setBoundToWall(this.magnetismEnabled && doorOrWindowBoundToWall);
      }
      // Update piece new location
      float newX = (float)(this.topLeftPoint [0] + (selectedPiece.getWidthInPlan() * cos - selectedPiece.getDepthInPlan() * sin) / 2f);
      float newY = (float)(this.topLeftPoint [1] + (selectedPiece.getWidthInPlan() * sin + selectedPiece.getDepthInPlan() * cos) / 2f);
      selectedPiece.setX(newX);
      selectedPiece.setY(newY);
      // Ensure point at (x,y) is visible
      planView.makePointVisible(x, y);
      planView.setToolTipFeedback(getToolTipFeedbackText(newWidth, newDepth, newHeight), x, y);
    }
    /**
     * Returns <code>true</code> if the <code>piece</code> should be proportionally resized.
     */
    private boolean isProprortionallyResized(HomePieceOfFurniture piece) {
      return !piece.isDeformable()
          || piece.isHorizontallyRotated()
          || this.alignmentActivated;
    }
    @Override
    public void releaseMouse(float x, float y) {
      postPieceOfFurnitureWidthAndDepthResize(this.resizedPiece);
      setState(getSelectionState());
    }
    @Override
    public void toggleMagnetism(boolean magnetismToggled) {
      // Compute active magnetism
      this.magnetismEnabled = preferences.isMagnetismEnabled()
                              ^ magnetismToggled;
      // Compute again angle as if mouse moved
      moveMouse(getXLastMouseMove(), getYLastMouseMove());
    }
    @Override
    public void setAlignmentActivated(boolean alignmentActivated) {
      this.alignmentActivated = alignmentActivated;
      moveMouse(getXLastMouseMove(), getYLastMouseMove());
    }
    @Override
    public void escape() {
      resetPieceOfFurnitureSize(this.resizedPiece);
      setState(getSelectionState());
    }
    @Override
    public void exit() {
      PlanView planView = getView();
      planView.setResizeIndicatorVisible(false);
      planView.deleteFeedback();
      this.resizedPiece = null;
    }  
    private String getToolTipFeedbackText(float width, float depth, float height) {
      String toolTipFeedbackText = "<html>" + String.format(this.widthResizeToolTipFeedback,  
          preferences.getLengthUnit().getFormatWithUnit().format(width));
      if (!(this.resizedPiece.getPieceOfFurniture() instanceof HomeDoorOrWindow) 
          || !((HomeDoorOrWindow)this.resizedPiece.getPieceOfFurniture()).isBoundToWall()
          || isProprortionallyResized(this.resizedPiece.getPieceOfFurniture())) {
        toolTipFeedbackText += "<br>" + String.format(this.depthResizeToolTipFeedback,
            preferences.getLengthUnit().getFormatWithUnit().format(depth));
      }
      if (isProprortionallyResized(this.resizedPiece.getPieceOfFurniture())) {
        toolTipFeedbackText += "<br>" + String.format(this.heightResizeToolTipFeedback,
            preferences.getLengthUnit().getFormatWithUnit().format(height));
      }
      return toolTipFeedbackText;
    }
  }
