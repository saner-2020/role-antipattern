/*
 * PluginManager.java 24 oct. 2008
 *
 * Sweet Home 3D, Copyright (c) 2008 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.plugin;
import com.eteks.sweethome3d.model.Library;
/**
 * Sweet Home 3D plug-ins manager.
 * @author Emmanuel Puybaret
 */
private static class PluginLibrary implements Library {
    private final String                  location;
    private final String                  name;
    private final String                  id;
    private final String                  description;
    private final String                  version;
    private final String                  license;
    private final String                  provider;
    private final Class<? extends Plugin> pluginClass;
    private final ClassLoader             pluginClassLoader;
    /**
     * Creates plug-in properties from parameters. 
     */
    public PluginLibrary(String location,
                         String id,
                         String name, String description, String version, 
                         String license, String provider,
                         Class<? extends Plugin> pluginClass, ClassLoader pluginClassLoader) {
      this.location = location;
      this.id = id;
      this.name = name;
      this.description = description;
      this.version = version;
      this.license = license;
      this.provider = provider;
      this.pluginClass = pluginClass;
      this.pluginClassLoader = pluginClassLoader;
    }
    public Class<? extends Plugin> getPluginClass() {
      return this.pluginClass;
    }
    public ClassLoader getPluginClassLoader() {
      return this.pluginClassLoader;
    }
    public String getType() {
      return PluginManager.PLUGIN_LIBRARY_TYPE;
    }
    public String getLocation() {
      return this.location;
    }
    public String getId() {
      return this.id;
    }
    public String getName() {
      return this.name;
    }
    public String getDescription() {
      return this.description;
    }
    public String getVersion() {
      return this.version;
    }
    public String getLicense() {
      return this.license;
    }
    public String getProvider() {
      return this.provider;
    }
  }
