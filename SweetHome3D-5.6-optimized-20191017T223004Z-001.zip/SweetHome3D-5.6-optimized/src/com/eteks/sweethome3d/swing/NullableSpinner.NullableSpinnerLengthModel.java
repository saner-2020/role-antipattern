/*
 * NullableSpinner.java 29 mai 07
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.text.Format;
import com.eteks.sweethome3d.model.LengthUnit;
import com.eteks.sweethome3d.model.UserPreferences;
/**
 * Spinner that accepts empty string values. In this case the returned value is <code>null</code>. 
 */
public static class NullableSpinnerLengthModel extends NullableSpinnerNumberModel {
    private final UserPreferences preferences;
    /**
     * Creates a model managing lengths between the given <code>minimum</code> and <code>maximum</code> values in centimeter. 
     */
    public NullableSpinnerLengthModel(UserPreferences preferences, float minimum, float maximum) {
      this(preferences, minimum, minimum, maximum);
    }
    /**
     * Creates a model managing lengths between the given <code>minimum</code> and <code>maximum</code> values in centimeter. 
     */
    public NullableSpinnerLengthModel(UserPreferences preferences, float value, float minimum, float maximum) {
      super(value, minimum, maximum, 
            preferences.getLengthUnit() == LengthUnit.INCH
            || preferences.getLengthUnit() == LengthUnit.INCH_DECIMALS
              ? LengthUnit.inchToCentimeter(0.125f) : 0.5f);
      this.preferences = preferences;
    }
    /**
     * Returns the displayed value in centimeter.
     */
    public Float getLength() {
      if (getValue() == null) {
        return null;
      } else {
        return Float.valueOf(((Number)getValue()).floatValue());
      }
    }
    /**
     * Sets the length in centimeter displayed in this model.
     */
    public void setLength(Float length) {
      setValue(length);
    }
    /**
     * Sets the minimum length in centimeter displayed in this model.
     */
    public void setMinimumLength(float minimum) {
      setMinimum(Float.valueOf(minimum));
    }
    /**
     * Returns the format used by this model.
     */
    @Override
    Format getFormat() {
      return this.preferences.getLengthUnit().getFormat();
    }
  }
