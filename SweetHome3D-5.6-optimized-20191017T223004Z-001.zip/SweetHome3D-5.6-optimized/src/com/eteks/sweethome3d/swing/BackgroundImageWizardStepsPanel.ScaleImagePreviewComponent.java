/*
 * BackgroundImageWizardStepsPanel.java 8 juin 07
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.event.MouseInputAdapter;
import com.eteks.sweethome3d.viewcontroller.BackgroundImageWizardController;
/**
 * Wizard panel for background image choice. 
 * @author Emmanuel Puybaret
 */
private static class ScaleImagePreviewComponent extends ScaledImageComponent {
    private enum ActionType {ACTIVATE_ALIGNMENT, DEACTIVATE_ALIGNMENT};
    private final BackgroundImageWizardController controller;
    public ScaleImagePreviewComponent(BackgroundImageWizardController controller) {
      super(null, true);
      this.controller = controller;
      addChangeListeners(controller);
      addMouseListeners(controller);
      setBorder(null);      
      InputMap inputMap = getInputMap(WHEN_IN_FOCUSED_WINDOW);
      inputMap.put(KeyStroke.getKeyStroke("shift pressed SHIFT"), ActionType.ACTIVATE_ALIGNMENT);
      inputMap.put(KeyStroke.getKeyStroke("alt shift pressed SHIFT"), ActionType.ACTIVATE_ALIGNMENT);
      inputMap.put(KeyStroke.getKeyStroke("control shift pressed SHIFT"), ActionType.ACTIVATE_ALIGNMENT);
      inputMap.put(KeyStroke.getKeyStroke("meta shift pressed SHIFT"), ActionType.ACTIVATE_ALIGNMENT);
      inputMap.put(KeyStroke.getKeyStroke("released SHIFT"), ActionType.DEACTIVATE_ALIGNMENT);
      inputMap.put(KeyStroke.getKeyStroke("alt released SHIFT"), ActionType.DEACTIVATE_ALIGNMENT);
      inputMap.put(KeyStroke.getKeyStroke("control released SHIFT"), ActionType.DEACTIVATE_ALIGNMENT);
      inputMap.put(KeyStroke.getKeyStroke("meta released SHIFT"), ActionType.DEACTIVATE_ALIGNMENT);
      setInputMap(WHEN_IN_FOCUSED_WINDOW, inputMap);
    }
    /**
     * Adds listeners to <code>controller</code> 
     * to update the scale distance points of the origin drawn by this component.
     */
    private void addChangeListeners(final BackgroundImageWizardController controller) {
      controller.addPropertyChangeListener(BackgroundImageWizardController.Property.SCALE_DISTANCE_POINTS, 
          new PropertyChangeListener () {
            public void propertyChange(PropertyChangeEvent ev) {
              // If origin values changes update displayed origin
              repaint();
            }
          });
    }
    /**
     * Adds to this component a mouse listeners that allows the user to move the start point 
     * or the end point of the scale distance line.
     */
    public void addMouseListeners(final BackgroundImageWizardController controller) {
      MouseInputAdapter mouseListener = new MouseInputAdapter() {
        private int         deltaXMousePressed;
        private int         deltaYMousePressed;
        private boolean     distanceStartPoint;
        private boolean     distanceEndPoint;
        private Point       lastMouseLocation;
        @Override
        public void mousePressed(MouseEvent ev) {
          if (!ev.isPopupTrigger()) {
            mouseMoved(ev);
            if (this.distanceStartPoint
                || this.distanceEndPoint) {
              float [][] scaleDistancePoints = controller.getScaleDistancePoints();
              Point translationorigin = getImageTranslation();
              float scale = getImageScale();
              this.deltaXMousePressed = (ev.getX() - translationorigin.x);
              this.deltaYMousePressed = (ev.getY() - translationorigin.y);
              if (this.distanceStartPoint) {
                this.deltaXMousePressed -= scaleDistancePoints [0][0] * scale;
                this.deltaYMousePressed -= scaleDistancePoints [0][1] * scale;
              } else {
                this.deltaXMousePressed -= scaleDistancePoints [1][0] * scale;
                this.deltaYMousePressed -= scaleDistancePoints [1][1] * scale;
              }
              // Set actions used to activate/deactivate alignment
              ActionMap actionMap = getActionMap();
              actionMap.put(ActionType.ACTIVATE_ALIGNMENT, new AbstractAction() {
                  public void actionPerformed(ActionEvent ev) {
                    mouseDragged(null, true);
                  }
                });                  
              actionMap.put(ActionType.DEACTIVATE_ALIGNMENT, new AbstractAction() {
                  public void actionPerformed(ActionEvent ev) {
                    mouseDragged(null, false);
                  }
                });   
              setActionMap(actionMap);
            }
          }
          this.lastMouseLocation = ev.getPoint();
        }
        @Override
        public void mouseReleased(MouseEvent ev) {
          ActionMap actionMap = getActionMap();
          // Remove actions used to activate/deactivate alignment
          actionMap.remove(ActionType.ACTIVATE_ALIGNMENT);                  
          actionMap.remove(ActionType.DEACTIVATE_ALIGNMENT);   
          setActionMap(actionMap);
        }
        @Override
        public void mouseDragged(MouseEvent ev) {
          mouseDragged(ev.getPoint(), ev.isShiftDown());
          this.lastMouseLocation = ev.getPoint();
        }
        public void mouseDragged(Point mouseLocation, boolean keepHorizontalVertical) {
          if (this.distanceStartPoint
              || this.distanceEndPoint) {
            if (mouseLocation == null) {
              mouseLocation = this.lastMouseLocation;
            }            
            Point point = getPointConstrainedInImage(
                mouseLocation.x - this.deltaXMousePressed, mouseLocation.y - this.deltaYMousePressed);
            Point translation = getImageTranslation();
            float [][] scaleDistancePoints = controller.getScaleDistancePoints();
            float [] updatedPoint;
            float [] fixedPoint;
            if (this.distanceStartPoint) {
              updatedPoint = scaleDistancePoints [0];
              fixedPoint   = scaleDistancePoints [1];
            } else {
              updatedPoint = scaleDistancePoints [1];
              fixedPoint   = scaleDistancePoints [0];
            }
            float scale = getImageScale();
            // Compute updated point of distance line
            float newX = (float)((point.getX() - translation.x) / scale);
            float newY = (float)((point.getY() - translation.y) / scale);
            // Accept new points only if distance is greater that 2 pixels
            if (Point2D.distanceSq(fixedPoint [0] * scale, fixedPoint [1] * scale, 
                    newX * scale, newY * scale) >= 4) {
              // If shift is down constrain keep the line vertical or horizontal
              if (keepHorizontalVertical) {
                double angle = Math.abs(Math.atan2(fixedPoint [1] - newY, newX - fixedPoint [0]));
                if (angle > Math.PI / 4 && angle <= 3 * Math.PI / 4) {
                  newX = fixedPoint [0];
                } else {
                  newY = fixedPoint [1];
                }
              }
              updatedPoint [0] = newX; 
              updatedPoint [1] = newY;
              controller.setScaleDistancePoints(
                scaleDistancePoints [0][0], scaleDistancePoints [0][1],
                scaleDistancePoints [1][0], scaleDistancePoints [1][1]);
              repaint();
            }
          }
        }
        @Override
        public void mouseMoved(MouseEvent ev) {
          this.distanceStartPoint = 
          this.distanceEndPoint = false;
          if (isPointInImage(ev.getX(), ev.getY())) {
            float [][] scaleDistancePoints = controller.getScaleDistancePoints();
            Point translation = getImageTranslation();
            float scale = getImageScale();
            // Check if user clicked on start or end point of distance line
            if (Math.abs(scaleDistancePoints [0][0] * scale - ev.getX() + translation.x) <= 3
                && Math.abs(scaleDistancePoints [0][1] * scale - ev.getY() + translation.y) <= 3) {
              this.distanceStartPoint = true;
            } else if (Math.abs(scaleDistancePoints [1][0] * scale - ev.getX() + translation.x) <= 3
                       && Math.abs(scaleDistancePoints [1][1] * scale - ev.getY() + translation.y) <= 3) {
              this.distanceEndPoint = true;
            }
          }
          if (this.distanceStartPoint || this.distanceEndPoint) {
            setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
          } else {
            setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
          }
        }
      };
      addMouseListener(mouseListener);
      addMouseMotionListener(mouseListener);
    }
    @Override
    protected void paintComponent(Graphics g) {
      if (getImage() != null) {
        Graphics2D g2D = (Graphics2D)g;
        g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
            RenderingHints.VALUE_ANTIALIAS_ON);
        Point translation = getImageTranslation();
        float scale = getImageScale();
        // Fill image background
        g2D.setColor(UIManager.getColor("window"));
        g2D.fillRect(translation.x, translation.y, (int)(getImage().getWidth() * scale), 
            (int)(getImage().getHeight() * scale));
        // Paint image with a 0.5 alpha
        paintImage(g2D, AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));        
        g2D.setPaint(getSelectionColor());
        AffineTransform oldTransform = g2D.getTransform();
        Stroke oldStroke = g2D.getStroke();
        // Use same origin and scale as image drawing in super class
        g2D.translate(translation.x, translation.y);
        g2D.scale(scale, scale);       
        // Draw a scale distance line        
        g2D.setStroke(new BasicStroke(5 / scale, 
            BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL));
        float [][] scaleDistancePoints = this.controller.getScaleDistancePoints();
        g2D.draw(new Line2D.Float(scaleDistancePoints [0][0], scaleDistancePoints [0][1], 
                                  scaleDistancePoints [1][0], scaleDistancePoints [1][1]));
        // Draw start point line
        g2D.setStroke(new BasicStroke(1 / scale, 
            BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL));
        double angle = Math.atan2(scaleDistancePoints [1][1] - scaleDistancePoints [0][1], 
                    scaleDistancePoints [1][0] - scaleDistancePoints [0][0]);
        AffineTransform oldTransform2 = g2D.getTransform();
        g2D.translate(scaleDistancePoints [0][0], scaleDistancePoints [0][1]);
        g2D.rotate(angle);
        Shape endLine = new Line2D.Double(0, 5 / scale, 0, -5 / scale);
        g2D.draw(endLine);
        g2D.setTransform(oldTransform2);
        // Draw end point line
        g2D.translate(scaleDistancePoints [1][0], scaleDistancePoints [1][1]);
        g2D.rotate(angle);
        g2D.draw(endLine);
        g2D.setTransform(oldTransform);
        g2D.setStroke(oldStroke);
      }
    }
  }
