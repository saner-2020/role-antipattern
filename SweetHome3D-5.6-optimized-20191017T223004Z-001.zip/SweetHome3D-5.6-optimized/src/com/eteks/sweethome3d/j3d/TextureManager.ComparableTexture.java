/*
 * TextureManager.java 2 oct 2007
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.j3d;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import javax.media.j3d.ImageComponent2D;
import javax.media.j3d.Texture;
/**
 * Singleton managing texture image cache.
 * @author Emmanuel Puybaret
 */
private static class ComparableTexture {
    private Texture               texture;
    private WeakReference<int []> imageBits;
    private Integer               imageBitsHashCode;
    private Boolean               transparent;
    public ComparableTexture(Texture texture) {
      this.texture = texture;      
    }
    public Texture getTexture() {
      return this.texture;
    }
    /**
     * Returns the pixels of the given <code>image</code>.
     */
    private int [] getImageBits() {
      int [] imageBits = null;
      if (this.imageBits != null) {
        imageBits = this.imageBits.get();
      }
      if (imageBits == null) {
        BufferedImage image = ((ImageComponent2D)this.texture.getImage(0)).getImage();
        if (image.getType() != BufferedImage.TYPE_INT_RGB
            && image.getType() != BufferedImage.TYPE_INT_ARGB) {
          // Transform as TYPE_INT_ARGB or TYPE_INT_RGB (much faster than calling image.getRGB())
          BufferedImage tmp = new BufferedImage(image.getWidth(), image.getHeight(), 
              this.texture.getFormat() == Texture.RGBA ? BufferedImage.TYPE_INT_ARGB : BufferedImage.TYPE_INT_RGB);
          Graphics2D g = (Graphics2D)tmp.getGraphics();
          g.drawImage(image, null, 0, 0);
          g.dispose();
          image = tmp;
        }
        imageBits = (int [])image.getRaster().getDataElements(0, 0, image.getWidth(), image.getHeight(), null);
        this.transparent = image.getTransparency() != BufferedImage.OPAQUE;
        if (this.transparent) {
          this.transparent = containsTransparentPixels(imageBits);
        }
        this.imageBits = new WeakReference<int[]>(imageBits);
      }
      return imageBits;
    }
    /**
     * Returns an hash code for the image of the texture that allows
     * a faster comparison and storing images bits in a weak reference.
     */
    private int getImageBitsHashCode() {
      if (this.imageBitsHashCode == null) {
        this.imageBitsHashCode = Arrays.hashCode(getImageBits());
      }
      return this.imageBitsHashCode;
    }
    /**
     * Returns <code>true</code> if the image contains at least a transparent pixel. 
     */
    private boolean containsTransparentPixels(int [] imageBits) {
      boolean transparentPixel = false;
      for (int argb : imageBits) {
        if ((argb & 0xFF000000) != 0xFF000000) {
          transparentPixel = true;
          break;
        }
      }
      return transparentPixel;
    }
    /**
     * Returns <code>true</code> if the image of the texture contains at least one transparent pixel.
     */
    public boolean isTransparent() {
      if (this.transparent == null) {
        getImageBits();
      }
      return this.transparent;
    }
    /**
     * Returns <code>true</code> if the image of this texture and 
     * the image of the object in parameter are the same. 
     */
    public boolean equalsImage(ComparableTexture comparableTexture) {
      if (this == comparableTexture) {
        return true;
      } else if (this.texture == comparableTexture.texture) {
        return true;
      } else if (getImageBitsHashCode() == comparableTexture.getImageBitsHashCode()){
        return Arrays.equals(getImageBits(), comparableTexture.getImageBits());
      }
      return false;
    }
  }
