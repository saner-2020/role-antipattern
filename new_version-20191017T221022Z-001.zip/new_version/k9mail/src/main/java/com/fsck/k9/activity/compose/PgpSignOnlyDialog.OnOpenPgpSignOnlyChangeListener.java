package com.fsck.k9.activity.compose;


public interface OnOpenPgpSignOnlyChangeListener {
        void onOpenPgpSignOnlyChange(boolean enabled);
    }