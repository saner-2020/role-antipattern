/*
 * ColorButton.java 29 mai 07
 *
 * Sweet Home 3D, Copyright (c) 2007 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.DefaultListCellRenderer;
import javax.swing.Icon;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.JPopupMenu;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import com.eteks.sweethome3d.tools.OperatingSystem;
/**
 * Button displaying a color as an icon.
 */
private static class PaletteComboBox extends JComboBox {
    private PaletteComboBox(ColorCode [] colors) {
      super(colors);
      // Set combo box popup wider as suggested at http://forums.java.net/jive/message.jspa?messageID=61267
      PopupMenuListener comboBoxPopupMenuListener = new PopupMenuListener() {
          public void popupMenuWillBecomeVisible(PopupMenuEvent ev) {
            JComboBox comboBox = (JComboBox)ev.getSource();
            Object comp = comboBox.getUI().getAccessibleChild(comboBox, 0);
            if (!(comp instanceof JPopupMenu)) {
              return;
            }
            JComponent scrollPane = (JComponent)((JPopupMenu)comp).getComponent(0);
            Dimension size = new Dimension();
            size.width = comboBox.getPreferredSize().width - 10;
            size.height = scrollPane.getPreferredSize().height;
            scrollPane.setPreferredSize(size);
            scrollPane.setMaximumSize(size);
          }
          public void popupMenuCanceled(PopupMenuEvent e) {
          }
          public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
          }
        };
      if (!OperatingSystem.isMacOSX()) {
        addPopupMenuListener(comboBoxPopupMenuListener);
      } 
      final int iconHeight = Math.round(16 * SwingTools.getResolutionScale());
      setRenderer(new DefaultListCellRenderer() {
          @Override
          public Component getListCellRendererComponent(final JList list, 
                    Object value, int index, boolean isSelected, boolean cellHasFocus) {
            final ColorCode color = (ColorCode)value;
            if (color == null) {
              value = " ";
            } else {
              value = color.getId();
            }
            Component component = super.getListCellRendererComponent(list, value,
                index, isSelected, cellHasFocus);
            if (color != null) {
              setIcon(new Icon() {
                  public int getIconWidth() {
                    return iconHeight * 2;
                  }
                  public int getIconHeight() {
                    return iconHeight;
                  }
                  public void paintIcon(Component c, Graphics g, int x, int y) {
                    g.setColor(new Color(color.getRGB()));
                    g.fillRect(x + 1, y + 1, getIconWidth() - 3, getIconHeight() - 2);
                    g.setColor(list.getForeground());
                    g.drawRect(x, y, getIconWidth() - 2, getIconHeight() - 1);
                  }
                });
            }
            return component;
          }
        });
    }
    /**
     * Returns the color code matching the one given in parameter or <code>null</code> if not found.
     */
    public ColorCode getColorCode(Color color) {
      if (color != null) {
        for (int i = 1, n = getModel().getSize(); i < n; i++) {
          ColorCode colorCode = (ColorCode)getModel().getElementAt(i);
          if (colorCode.getRGB() == (color.getRGB() & 0xFFFFFF)) {
            return colorCode;
          }
        }
      }
      return null;
    }
  }
