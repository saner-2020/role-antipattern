package com.fsck.k9.mail.internet;
public interface SizeAware {
    long getSize();
}