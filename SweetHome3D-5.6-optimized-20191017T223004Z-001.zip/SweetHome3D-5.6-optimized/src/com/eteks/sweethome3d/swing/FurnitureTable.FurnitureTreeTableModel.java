/*
 * FurnitureTable.java 15 mai 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import com.eteks.sweethome3d.model.CollectionEvent;
import com.eteks.sweethome3d.model.CollectionListener;
import com.eteks.sweethome3d.model.Home;
import com.eteks.sweethome3d.model.HomeFurnitureGroup;
import com.eteks.sweethome3d.model.HomePieceOfFurniture;
import com.eteks.sweethome3d.model.Level;
/**
 * A table displaying home furniture.
 * @author Emmanuel Puybaret
 */
private static class FurnitureTreeTableModel extends AbstractTableModel implements TreeModel {
    private Home                                    home;
    private List<HomePieceOfFurniture>              filteredAndSortedFurniture;
    private FurnitureFilter                         furnitureFilter;
    private Set<HomeFurnitureGroup>                 expandedGroups;
    private List<TreeModelListener>                 treeModelListeners;
    private Map<Object, List<HomePieceOfFurniture>> childFurnitureCache;
    private boolean                                 containsNotViewableFurniture;
    public FurnitureTreeTableModel(Home home) {
      this.home = home;
      this.expandedGroups = new HashSet<HomeFurnitureGroup>();
      this.treeModelListeners = new ArrayList<TreeModelListener>();
      this.childFurnitureCache = new HashMap<Object, List<HomePieceOfFurniture>>();
      addHomeListener(home);
      filterAndSortFurniture();
    }
    private void addHomeListener(final Home home) {
      home.addFurnitureListener(new CollectionListener<HomePieceOfFurniture>() {
          public void collectionChanged(CollectionEvent<HomePieceOfFurniture> ev) {
            HomePieceOfFurniture piece = ev.getItem();
            int pieceIndex = ev.getIndex();
            switch (ev.getType()) {
              case ADD :
                if (!expandedGroups.isEmpty()
                    || containsNotViewableFurniture
                    || pieceIndex < 0) {
                  filterAndSortFurniture();
                } else {
                  int insertionIndex = getPieceOfFurnitureInsertionIndex(piece, home, pieceIndex);
                  if (insertionIndex != -1) {
                    filteredAndSortedFurniture.add(insertionIndex, piece);
                    fireTableRowsInserted(insertionIndex, insertionIndex);
                    fireTreeModelChanged();
                  }
                }
                break;
              case DELETE :
                if (furnitureFilter != null
                    || pieceIndex < 0) {
                  filterAndSortFurniture();
                } else {
                  int deletionIndex = getPieceOfFurnitureDeletionIndex(piece, home, pieceIndex);
                  if (deletionIndex != -1) {
                    if (expandedGroups.contains(piece)) { 
                      filterAndSortFurniture();
                    } else {
                      filteredAndSortedFurniture.remove(deletionIndex);
                      fireTableRowsDeleted(deletionIndex, deletionIndex);
                      fireTreeModelChanged();
                    }
                  }
                }
                if (piece instanceof HomeFurnitureGroup) {
                  expandedGroups.remove(piece);
                }
                break;
            }
          }
          /**
           * Returns the index of an added <code>piece</code> in furniture table, with a default index
           * of <code>homePieceIndex</code> if <code>home</code> furniture isn't sorted.
           * If <code>piece</code> isn't added to furniture table, the returned value is
           * equals to the insertion index where piece should be added.
           */
          private int getPieceOfFurnitureInsertionIndex(HomePieceOfFurniture piece, Home home, int homePieceIndex) {
            if (furnitureFilter == null) {
              if (home.getFurnitureSortedProperty() == null) {
                return homePieceIndex;
              }
            } else if (!furnitureFilter.include(home, piece)) {
              return -1;
            } else if (home.getFurnitureSortedProperty() == null) {
              if (homePieceIndex == 0
                  || filteredAndSortedFurniture.size() == 0) {
                return 0;
              } else {
                // Find the index of the previous piece included in filteredAndSortedFurniture
                List<HomePieceOfFurniture> homeFurniture = home.getFurniture();
                int previousIncludedPieceIndex = homePieceIndex - 1;
                while (previousIncludedPieceIndex > 0
                    && !furnitureFilter.include(home, homeFurniture.get(previousIncludedPieceIndex))) {
                  previousIncludedPieceIndex--;
                }
                return getPieceOfFurnitureIndex(homeFurniture.get(previousIncludedPieceIndex)) + 1;
              }
            }
            // Default case when piece is included and furniture is  sorted
            int sortedIndex = Collections.binarySearch(filteredAndSortedFurniture, piece, getFurnitureComparator(home));
            if (sortedIndex >= 0) {
              return sortedIndex;
            } else {
              return -(sortedIndex + 1);
            }
          }
          /**
           * Returns the index of an existing <code>piece</code> in furniture table, with a default index
           * of <code>homePieceIndex</code> if <code>home</code> furniture isn't sorted.
           */
          private int getPieceOfFurnitureDeletionIndex(HomePieceOfFurniture piece, Home home, int homePieceIndex) {
            if (furnitureFilter == null
                && home.getFurnitureSortedProperty() == null
                && expandedGroups.isEmpty()
                && !containsNotViewableFurniture) {
              return homePieceIndex;
            }
            return getPieceOfFurnitureIndex(piece);
          }
        });
      home.addPropertyChangeListener(Home.Property.FURNITURE_VISIBLE_PROPERTIES, new PropertyChangeListener() {
          public void propertyChange(PropertyChangeEvent ev) {
            if (!home.getFurnitureVisibleProperties().contains(HomePieceOfFurniture.SortableProperty.NAME)) {
              expandedGroups.clear();
              filterAndSortFurniture();
            }
          }
        });
    }
    @Override
    public String getColumnName(int columnIndex) {
      // Column name is set by TableColumn instances themselves
      return null;
    }
    public int getColumnCount() {
      // Column count is set by TableColumnModel itself
      return 0;
    }
    public int getRowCount() {
      return this.filteredAndSortedFurniture.size();
    }
    public Object getValueAt(int rowIndex, int columnIndex) {
      // Always return piece itself, the real property displayed at screen is chosen by renderer
      return this.filteredAndSortedFurniture.get(rowIndex);
    }
    /**
     * Returns the index of <code>piece</code> in furniture table, or -1 if it is excluded by filter.
     */
    public int getPieceOfFurnitureIndex(HomePieceOfFurniture piece) {
      return this.filteredAndSortedFurniture.indexOf(piece);
    }
    /**
     * Filters and sorts <code>home</code> furniture.
     */
    public void filterAndSortFurniture() {
      int previousRowCount = this.filteredAndSortedFurniture != null
          ? this.filteredAndSortedFurniture.size()
          : 0;
      List<HomePieceOfFurniture> furniture = this.home.getFurniture();
      // Search if home furniture contains some not viewable furniture (no need to explore
      // furniture in groups because all furniture in a group belong to the same level)
      boolean containsNotViewableFurniture = false;
      for (HomePieceOfFurniture homePiece : furniture) {
        Level level = homePiece.getLevel();
        if (level != null && !level.isViewable()) {
          containsNotViewableFurniture = true;
          break;
        }
      }
      this.containsNotViewableFurniture = containsNotViewableFurniture;
      this.filteredAndSortedFurniture = getFilteredAndSortedFurniture(furniture, true);
      if (previousRowCount != this.filteredAndSortedFurniture.size()) {
        fireTableDataChanged();
      } else {
        fireTableRowsUpdated(0, getRowCount() - 1);
      }
      fireTreeModelChanged();
    }
    /**
     * Returns a filtered and sorted list of the given <code>furniture</code>.
     */
    private List<HomePieceOfFurniture> getFilteredAndSortedFurniture(List<HomePieceOfFurniture> furniture,
                                                                     boolean includeExpandedGroups) {
      // Search furniture at viewable levels
      List<HomePieceOfFurniture> viewableFurniture = new ArrayList<HomePieceOfFurniture>(furniture.size());
      for (HomePieceOfFurniture homePiece : furniture) {
        if (homePiece.getLevel() == null
            || homePiece.getLevel().isViewable()) {
          viewableFurniture.add(homePiece);
        }
      }
      List<HomePieceOfFurniture> filteredAndSortedFurniture;
      if (this.furnitureFilter == null) {
        filteredAndSortedFurniture = viewableFurniture;
      } else {
        // Create the filtered list of home furniture
        filteredAndSortedFurniture = new ArrayList<HomePieceOfFurniture>(viewableFurniture.size());
        for (HomePieceOfFurniture homePiece : viewableFurniture) {
          if (this.furnitureFilter.include(this.home, homePiece)) {
            filteredAndSortedFurniture.add(homePiece);
          }
        }
      }
      // Sort furniture if necessary
      if (this.home.getFurnitureSortedProperty() != null) {
        Comparator<HomePieceOfFurniture> furnitureComparator = getFurnitureComparator(this.home);
        Collections.sort(filteredAndSortedFurniture, furnitureComparator);
      }
      if (includeExpandedGroups) {
        // Add furniture of expanded groups
        for (int i = filteredAndSortedFurniture.size() - 1; i >= 0; i--) {
          HomePieceOfFurniture piece = filteredAndSortedFurniture.get(i);
          if (piece instanceof HomeFurnitureGroup
              && this.expandedGroups.contains(piece)) {
            filteredAndSortedFurniture.addAll(i + 1,
                getFilteredAndSortedFurniture(((HomeFurnitureGroup)piece).getFurniture(), true));
          }
        }
      }
      return filteredAndSortedFurniture;
    }
    private Comparator<HomePieceOfFurniture> getFurnitureComparator(Home home) {
      Comparator<HomePieceOfFurniture> furnitureComparator =
        HomePieceOfFurniture.getFurnitureComparator(home.getFurnitureSortedProperty());
      if (home.isFurnitureDescendingSorted()) {
        furnitureComparator = Collections.reverseOrder(furnitureComparator);
      }
      return furnitureComparator;
    }
    /**
     * Sets the filter applied to the furniture listed in this model.
     */
    public void setFurnitureFilter(FurnitureFilter furnitureFilter) {
      this.furnitureFilter = furnitureFilter;
      filterAndSortFurniture();
    }
    /**
     * Returns the filter applied to the furniture listed in this model.
     */
    public FurnitureFilter getFurnitureFilter() {
      return this.furnitureFilter;
    }
    /**
     * Returns home instance.
     */
    public Object getRoot() {
      return this.home;
    }
    /**
     * Returns the child piece at the given <code>index</code>.
     */
    public Object getChild(Object parent, int index) {
      return getChildFurniture(parent).get(index);
    }
    /**
     * Returns the count of child pieces.
     */
    public int getChildCount(Object parent) {
      return getChildFurniture(parent).size();
    }
    /**
     * Returns the index of a child.
     */
    public int getIndexOfChild(Object parent, Object child) {
      return getChildFurniture(parent).indexOf(child);
    }
    /**
     * Returns the displayed child pieces of the given <code>parent</code>.
     */
    private List<HomePieceOfFurniture> getChildFurniture(Object parent) {
      List<HomePieceOfFurniture> furniture = this.childFurnitureCache.get(parent);
      if (furniture == null) {
        if (parent instanceof HomeFurnitureGroup) {
          furniture = ((HomeFurnitureGroup)parent).getFurniture();
        } else {
          furniture = this.home.getFurniture();
        }
        furniture = getFilteredAndSortedFurniture(furniture, false);
        this.childFurnitureCache.put(parent, furniture);
      }
      return furniture;
    }
    /**
     * Returns <code>true</code> if the given node is a piece of furniture.
     */
    public boolean isLeaf(Object node) {
      return node instanceof HomePieceOfFurniture
          && !(node instanceof HomeFurnitureGroup);
    }
    public void valueForPathChanged(TreePath path, Object newValue) {
      // Modification of the values in the model is managed by the table
    }
    public void addTreeModelListener(TreeModelListener listener) {
      this.treeModelListeners.add(listener);
    }
    public void removeTreeModelListener(TreeModelListener listener) {
      this.treeModelListeners.remove(listener);
    }
    private void fireTreeModelChanged() {
      this.childFurnitureCache.clear();
      for (TreeModelListener listener : this.treeModelListeners) {
        listener.treeStructureChanged(new TreeModelEvent(this, new TreePath(this.home)));
      }
    }
    /**
     * Returns <code>true</code> if the furniture group at the given row should be expanded.
     */
    public boolean isRowExpanded(int rowIndex) {
      return this.expandedGroups.contains(this.filteredAndSortedFurniture.get(rowIndex));
    }
    /**
     * Toggles the expanded state of the furniture group at the given row.
     */
    public void toggleRowExpandedState(int rowIndex) {
      HomePieceOfFurniture piece = this.filteredAndSortedFurniture.get(rowIndex);
      if (piece instanceof HomeFurnitureGroup) {
        if (this.expandedGroups.contains(piece)) {
          this.expandedGroups.remove((HomeFurnitureGroup)piece);
        } else {
          this.expandedGroups.add((HomeFurnitureGroup)piece);
        }
        filterAndSortFurniture();
      }
    }
    /**
     * Ensures the path to the given piece is expanded.
     */
    public void expandPathToPieceOfFurniture(HomePieceOfFurniture piece) {
      List<HomePieceOfFurniture> furniture = this.home.getFurniture();
      if (furniture.contains(piece)) {
        return;
      }
      for (HomeFurnitureGroup group : this.expandedGroups) {
        if (group.getFurniture().contains(piece)) {
          return;
        }
      }
      for (HomePieceOfFurniture homePiece : furniture) {
        if (homePiece instanceof HomeFurnitureGroup
            && expandPathToPieceOfFurniture(piece, (HomeFurnitureGroup)homePiece)) {
          filterAndSortFurniture();
          return;
        }
      }
    }
    private boolean expandPathToPieceOfFurniture(HomePieceOfFurniture piece,
                                                 HomeFurnitureGroup group) {
      for (HomePieceOfFurniture groupPiece : group.getFurniture()) {
        if (groupPiece == piece
            || (groupPiece instanceof HomeFurnitureGroup
                && expandPathToPieceOfFurniture(piece, (HomeFurnitureGroup)groupPiece))) {
          this.expandedGroups.add(group);
          return true;
        }
      }
      return false;
    }
  }
