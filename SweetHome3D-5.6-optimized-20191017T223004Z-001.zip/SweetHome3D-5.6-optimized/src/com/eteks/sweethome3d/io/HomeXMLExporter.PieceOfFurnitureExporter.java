/*
 * HomeXMLExporter.java 
 *
 * Copyright (c) 2015 Emmanuel PUYBARET / eTeks <info@eteks.com>. All Rights Reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.io;
import java.io.IOException;
import java.math.BigDecimal;
import com.eteks.sweethome3d.model.HomeDoorOrWindow;
import com.eteks.sweethome3d.model.HomeFurnitureGroup;
import com.eteks.sweethome3d.model.HomeLight;
import com.eteks.sweethome3d.model.HomeMaterial;
import com.eteks.sweethome3d.model.HomePieceOfFurniture;
import com.eteks.sweethome3d.model.LightSource;
import com.eteks.sweethome3d.model.Sash;
/**
 * Exporter for home instances. Homes will be written using the DTD given in {@link HomeXMLHandler} class.
 * @author Emmanuel Puybaret
 */
protected class PieceOfFurnitureExporter extends ObjectXMLExporter<HomePieceOfFurniture> { 
    public PieceOfFurnitureExporter() {
    }
    @Override
    protected void writeAttributes(XMLWriter writer, HomePieceOfFurniture piece) throws IOException {
      if (piece.getLevel() != null) {
        writer.writeAttribute("level", getId(piece.getLevel()));        
      }
      writer.writeAttribute("catalogId", piece.getCatalogId(), null);
      writer.writeAttribute("name", piece.getName());        
      writer.writeAttribute("creator", piece.getCreator(), null);
      writer.writeAttribute("model", getExportedContentName(piece, piece.getModel()), null);
      writer.writeAttribute("icon", getExportedContentName(piece, piece.getIcon()), null);
      writer.writeAttribute("planIcon", getExportedContentName(piece, piece.getPlanIcon()), null);
      writer.writeFloatAttribute("x", piece.getX());
      writer.writeFloatAttribute("y", piece.getY());
      writer.writeFloatAttribute("elevation", piece.getElevation(), 0f);
      writer.writeFloatAttribute("angle", piece.getAngle(), 0f);
      writer.writeFloatAttribute("pitch", piece.getPitch(), 0f);
      writer.writeFloatAttribute("roll", piece.getRoll(), 0f);
      writer.writeFloatAttribute("width", piece.getWidth());
      writer.writeFloatAttribute("widthInPlan", piece.getWidthInPlan(), piece.getWidth());
      writer.writeFloatAttribute("depth", piece.getDepth());
      writer.writeFloatAttribute("depthInPlan", piece.getDepthInPlan(), piece.getDepth());
      writer.writeFloatAttribute("height", piece.getHeight());
      writer.writeFloatAttribute("heightInPlan", piece.getHeightInPlan(), piece.getHeight());
      writer.writeBooleanAttribute("backFaceShown", piece.isBackFaceShown(), false);
      writer.writeBooleanAttribute("modelMirrored", piece.isModelMirrored(), false);
      writer.writeBooleanAttribute("visible", piece.isVisible(), true);
      writer.writeColorAttribute("color", piece.getColor());
      if (piece.getShininess() != null) {
        writer.writeFloatAttribute("shininess", piece.getShininess());
      }
      float [][] modelRotation = piece.getModelRotation();
      String modelRotationString = 
          floatToString(modelRotation[0][0]) + " " + floatToString(modelRotation[0][1]) + " " + floatToString(modelRotation[0][2]) + " "
        + floatToString(modelRotation[1][0]) + " " + floatToString(modelRotation[1][1]) + " " + floatToString(modelRotation[1][2]) + " "
        + floatToString(modelRotation[2][0]) + " " + floatToString(modelRotation[2][1]) + " " + floatToString(modelRotation[2][2]);
      writer.writeAttribute("modelRotation", modelRotationString, "1 0 0 0 1 0 0 0 1");
      writer.writeBooleanAttribute("modelCenteredAtOrigin", piece.isModelCenteredAtOrigin(), true);
      writer.writeLongAttribute("modelSize", piece.getModelSize());
      writer.writeAttribute("description", piece.getDescription(), null);        
      writer.writeAttribute("information", piece.getInformation(), null);        
      writer.writeBooleanAttribute("movable", piece.isMovable(), true);
      if (!(piece instanceof HomeFurnitureGroup)) {
        if (!(piece instanceof HomeDoorOrWindow)) {
          writer.writeBooleanAttribute("doorOrWindow", piece.isDoorOrWindow(), false);
          writer.writeBooleanAttribute("horizontallyRotatable", piece.isHorizontallyRotatable(), true);
        }
        writer.writeBooleanAttribute("resizable", piece.isResizable(), true);
        writer.writeBooleanAttribute("deformable", piece.isDeformable(), true);
        writer.writeBooleanAttribute("texturable", piece.isTexturable(), true);
      }
      if (piece instanceof HomeFurnitureGroup) {
        BigDecimal price = piece.getPrice();
        // Ignore price of group if one of its children has a price
        for (HomePieceOfFurniture groupPiece : ((HomeFurnitureGroup)piece).getFurniture()) {
          if (groupPiece.getPrice() != null) {
            price = null;
            break;
          }
        }
        writer.writeBigDecimalAttribute("price", price);
      } else {
        writer.writeBigDecimalAttribute("price", piece.getPrice());
        writer.writeBigDecimalAttribute("valueAddedTaxPercentage", piece.getValueAddedTaxPercentage());
        writer.writeAttribute("currency", piece.getCurrency(), null);
      }
      writer.writeAttribute("staircaseCutOutShape", piece.getStaircaseCutOutShape(), null);
      writer.writeFloatAttribute("dropOnTopElevation", piece.getDropOnTopElevation(), 1f);
      writer.writeBooleanAttribute("nameVisible", piece.isNameVisible(), false);
      writer.writeFloatAttribute("nameAngle", piece.getNameAngle(), 0f);
      writer.writeFloatAttribute("nameXOffset", piece.getNameXOffset(), 0f);
      writer.writeFloatAttribute("nameYOffset", piece.getNameYOffset(), 0f);
      if (piece instanceof HomeDoorOrWindow) {
        HomeDoorOrWindow doorOrWindow = (HomeDoorOrWindow)piece;
        writer.writeFloatAttribute("wallThickness", doorOrWindow.getWallThickness(), 1f);
        writer.writeFloatAttribute("wallDistance", doorOrWindow.getWallDistance(), 0f);
        writer.writeAttribute("cutOutShape", doorOrWindow.getCutOutShape(), null);
        writer.writeBooleanAttribute("wallCutOutOnBothSides", doorOrWindow.isWallCutOutOnBothSides(), false);
        writer.writeBooleanAttribute("widthDepthDeformable", doorOrWindow.isWidthDepthDeformable(), true);
        writer.writeBooleanAttribute("boundToWall", doorOrWindow.isBoundToWall(), true);
      } else if (piece instanceof HomeLight) {
        writer.writeFloatAttribute("power", ((HomeLight)piece).getPower());
      } 
    }
    @Override
    protected void writeChildren(XMLWriter writer, HomePieceOfFurniture piece) throws IOException {
      // Write subclass child elements 
      if (piece instanceof HomeFurnitureGroup) {
        for (HomePieceOfFurniture groupPiece : ((HomeFurnitureGroup)piece).getFurniture()) {
          writePieceOfFurniture(writer, groupPiece);
        }
      } else if (piece instanceof HomeLight) {
        for (LightSource lightSource : ((HomeLight)piece).getLightSources()) {
          writer.writeStartElement("lightSource");
          writer.writeFloatAttribute("x", lightSource.getX());
          writer.writeFloatAttribute("y", lightSource.getY());
          writer.writeFloatAttribute("z", lightSource.getZ());
          writer.writeColorAttribute("color", lightSource.getColor());
          writer.writeFloatAttribute("diameter", lightSource.getDiameter());
          writer.writeEndElement();
        }
      } else if (piece instanceof HomeDoorOrWindow) {
        for (Sash sash : ((HomeDoorOrWindow)piece).getSashes()) {
          writer.writeStartElement("sash");
          writer.writeFloatAttribute("xAxis", sash.getXAxis());
          writer.writeFloatAttribute("yAxis", sash.getYAxis());
          writer.writeFloatAttribute("width", sash.getWidth());
          writer.writeFloatAttribute("startAngle", sash.getStartAngle());
          writer.writeFloatAttribute("endAngle", sash.getEndAngle());
          writer.writeEndElement();
        }
      }
      // Write child elements 
      writeProperties(writer, piece);
      writeTextStyle(writer, piece.getNameStyle(), "nameStyle");
      writeTexture(writer, piece.getTexture(), null);
      if (piece.getModelMaterials() != null) {
        for (HomeMaterial material : piece.getModelMaterials()) {
          writeMaterial(writer, material, piece.getModel());
        }
      }
    }
  }
