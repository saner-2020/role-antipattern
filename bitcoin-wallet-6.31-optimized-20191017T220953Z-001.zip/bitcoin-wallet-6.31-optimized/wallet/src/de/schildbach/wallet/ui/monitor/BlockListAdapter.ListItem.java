/*
 * Copyright the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui.monitor;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import org.bitcoinj.core.Address;
import org.bitcoinj.core.Coin;
import org.bitcoinj.core.Sha256Hash;
import org.bitcoinj.core.StoredBlock;
import org.bitcoinj.core.Transaction;
import org.bitcoinj.core.Transaction.Purpose;
import org.bitcoinj.utils.MonetaryFormat;
import org.bitcoinj.wallet.Wallet;
import de.schildbach.wallet.Constants;
import de.schildbach.wallet.R;
import de.schildbach.wallet.data.AddressBookEntry;
import de.schildbach.wallet.util.WalletUtils;
import android.content.Context;
import android.text.format.DateUtils;
/**
 * @author Andreas Schildbach
 */
public static class ListItem {
        public final Sha256Hash blockHash;
        public final int height;
        public final String time;
        public final boolean isMiningRewardHalvingPoint;
        public final boolean isDifficultyTransitionPoint;
        public final MonetaryFormat format;
        public final List<ListTransaction> transactions;
        public ListItem(final Context context, final StoredBlock block, final Date time, final MonetaryFormat format,
                final @Nullable Set<Transaction> transactions, final @Nullable Wallet wallet,
                final @Nullable Map<String, AddressBookEntry> addressBook) {
            this.blockHash = block.getHeader().getHash();
            this.height = block.getHeight();
            final long timeMs = block.getHeader().getTimeSeconds() * DateUtils.SECOND_IN_MILLIS;
            if (timeMs < time.getTime() - DateUtils.MINUTE_IN_MILLIS)
                this.time = DateUtils.getRelativeDateTimeString(context, timeMs, DateUtils.MINUTE_IN_MILLIS,
                        DateUtils.WEEK_IN_MILLIS, 0).toString();
            else
                this.time = context.getString(R.string.block_row_now);
            this.isMiningRewardHalvingPoint = isMiningRewardHalvingPoint(block);
            this.isDifficultyTransitionPoint = isDifficultyTransitionPoint(block);
            this.format = format;
            this.transactions = new LinkedList<>();
            if (transactions != null && wallet != null) {
                for (final Transaction tx : transactions) {
                    final Map<Sha256Hash, Integer> appearsInHashes = tx.getAppearsInHashes();
                    if (appearsInHashes != null && appearsInHashes.containsKey(blockHash))
                        this.transactions.add(new ListTransaction(context, tx, wallet, addressBook));
                }
            }
        }
        private final boolean isMiningRewardHalvingPoint(final StoredBlock storedPrev) {
            return ((storedPrev.getHeight() + 1) % 210000) == 0;
        }
        private final boolean isDifficultyTransitionPoint(final StoredBlock storedPrev) {
            return ((storedPrev.getHeight() + 1) % Constants.NETWORK_PARAMETERS.getInterval()) == 0;
        }
        public static class ListTransaction {
            public final String fromTo;
            public final Address address;
            public final String label;
            public final Coin value;
            public ListTransaction(final Context context, final Transaction tx, final Wallet wallet,
                    final @Nullable Map<String, AddressBookEntry> addressBook) {
                final boolean isCoinBase = tx.isCoinBase();
                final boolean isInternal = tx.getPurpose() == Purpose.KEY_ROTATION;
                this.value = tx.getValue(wallet);
                final boolean sent = value.signum() < 0;
                final boolean self = WalletUtils.isEntirelySelf(tx, wallet);
                if (sent)
                    this.address = WalletUtils.getToAddressOfSent(tx, wallet);
                else
                    this.address = WalletUtils.getWalletAddressOfReceived(tx, wallet);
                if (isInternal || self)
                    this.fromTo = context.getString(R.string.symbol_internal);
                else if (sent)
                    this.fromTo = context.getString(R.string.symbol_to);
                else
                    this.fromTo = context.getString(R.string.symbol_from);
                if (isCoinBase) {
                    this.label = context.getString(R.string.wallet_transactions_fragment_coinbase);
                } else if (isInternal || self) {
                    this.label = context.getString(R.string.wallet_transactions_fragment_internal);
                } else if (address != null && addressBook != null) {
                    final AddressBookEntry entry = addressBook.get(address.toString());
                    if (entry != null)
                        this.label = entry.getLabel();
                    else
                        this.label = "?";
                } else {
                    this.label = "?";
                }
            }
        }
    }
