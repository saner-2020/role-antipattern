/*
 * PlanComponentTest.java 31 mai 2006
 * 
 * Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>. All Rights
 * Reserved.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 */
package com.eteks.sweethome3d.junit;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.undo.UndoManager;
import javax.swing.undo.UndoableEditSupport;
import com.eteks.sweethome3d.io.DefaultUserPreferences;
import com.eteks.sweethome3d.model.Home;
import com.eteks.sweethome3d.model.UserPreferences;
import com.eteks.sweethome3d.swing.PlanComponent;
import com.eteks.sweethome3d.swing.SwingViewFactory;
import com.eteks.sweethome3d.viewcontroller.PlanController;
import com.eteks.sweethome3d.viewcontroller.PlanView;
import com.eteks.sweethome3d.viewcontroller.ViewFactory;
/**
 * Tests {@link com.eteks.sweethome3d.swing.PlanComponent plan} component and 
 * its {@link com.eteks.sweethome3d.viewcontroller.PlanController controller}.
 * @author Emmanuel Puybaret
 */
private static class PlanTestFrame extends JFrame {
    private final UserPreferences preferences;
    private final Home            home;
    private final PlanController  planController;
    private final JToggleButton   modeButton;
    private final JButton         undoButton;
    private final JButton         redoButton;
    private final JButton         reverseDirectionButton;
    private final JButton         splitButton;
    public PlanTestFrame() {
      super("Plan Component Test");
      // Create model objects
      this.home = new Home();
      this.home.getCompass().setVisible(false);
      Locale.setDefault(Locale.FRANCE);
      this.preferences = new DefaultUserPreferences();
      ViewFactory viewFactory = new SwingViewFactory() {
          @Override
          public PlanView createPlanView(Home home, UserPreferences preferences, PlanController controller) {
            return new PlanComponent(home, preferences, controller);
          }
        };
      UndoableEditSupport undoSupport = new UndoableEditSupport();
      final UndoManager undoManager = new UndoManager();
      undoSupport.addUndoableEditListener(undoManager);
      this.planController = new PlanController(this.home, this.preferences, viewFactory, null, undoSupport);
      // Add plan component to frame at its preferred size 
      add(new JScrollPane((JComponent)this.planController.getView()));
      // Create a toggle button for plan component mode 
      this.modeButton = new JToggleButton(new ImageIcon(
          getClass().getResource("resources/Add16.gif")));
      // Add listeners to modeButton that manages plan planController mode
      this.modeButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent ev) {
          if (modeButton.isSelected()) {
            planController.setMode(PlanController.Mode.WALL_CREATION);
          } else {
            planController.setMode(PlanController.Mode.SELECTION);
          }
        }
      });
      // Create an undo button 
      this.undoButton = new JButton(new ImageIcon(
          getClass().getResource("resources/Undo16.gif")));
      this.undoButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent ev) {
          undoManager.undo();
        }
      });
      // Create a redo button
      this.redoButton = new JButton(new ImageIcon(
          getClass().getResource("resources/Redo16.gif")));
      this.redoButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent ev) {
          undoManager.redo();
        }
      });
      this.reverseDirectionButton = new JButton("Reverse");
      this.reverseDirectionButton.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent ev) {
            planController.reverseSelectedWallsDirection();
          }
        });
      this.splitButton = new JButton("Split");
      this.splitButton.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent ev) {
            planController.splitSelectedWall();
          }
        });
      // Add a tool bar to the frame with mode toggle button, 
      // undo and redo buttons
      JToolBar toolBar = new JToolBar();
      toolBar.add(this.modeButton);
      toolBar.add(this.undoButton);
      toolBar.add(this.redoButton);
      toolBar.add(this.reverseDirectionButton);
      toolBar.add(this.splitButton);
      // Add the tool bar at top of the window
      add(toolBar, BorderLayout.NORTH);
      // Pack frame to ensure home plan component is at its preferred size 
      pack();
    }
  }
