/*
 * Copyright the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui.monitor;
import java.net.InetAddress;
import java.util.Map;
import org.bitcoinj.core.Peer;
import org.bitcoinj.core.VersionMessage;
import de.schildbach.wallet.R;
import android.content.Context;
/**
 * @author Andreas Schildbach
 */
public static class ListItem {
        public ListItem(final Context context, final Peer peer, final Map<InetAddress, String> hostnames) {
            this.ip = peer.getAddress().getAddr();
            this.hostname = hostnames.get(ip);
            this.height = peer.getBestHeight();
            final VersionMessage versionMessage = peer.getPeerVersionMessage();
            this.version = versionMessage.subVer;
            this.protocol = "protocol: " + versionMessage.clientVersion;
            final long pingTime = peer.getPingTime();
            this.ping = pingTime < Long.MAX_VALUE ? context.getString(R.string.peer_list_row_ping_time, pingTime)
                    : null;
            this.isDownloading = peer.isDownloadData();
        }
        public final InetAddress ip;
        public final String hostname;
        public final long height;
        public final String version;
        public final String protocol;
        public final String ping;
        public final boolean isDownloading;
    }
