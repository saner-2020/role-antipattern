/*
 * PlanController.java 2 juin 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.GeneralPath;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.eteks.sweethome3d.model.HomeDoorOrWindow;
import com.eteks.sweethome3d.model.HomeFurnitureGroup;
import com.eteks.sweethome3d.model.HomePieceOfFurniture;
import com.eteks.sweethome3d.model.LengthUnit;
import com.eteks.sweethome3d.model.Level;
import com.eteks.sweethome3d.model.Room;
import com.eteks.sweethome3d.model.Selectable;
import com.eteks.sweethome3d.model.Wall;
/**
 * A MVC controller for the plan view.
 * @author Emmanuel Puybaret
 */
private class RoomDrawingState extends AbstractRoomState {
    private float                  xPreviousPoint;
    private float                  yPreviousPoint;
    private Room                   newRoom;
    private float []               newPoint;
    private List<Selectable>       oldSelection;
    private boolean                oldBasePlanLocked;
    private boolean                oldAllLevelsSelection;
    private boolean                magnetismEnabled;
    private boolean                alignmentActivated;
    private long                   lastPointCreationTime;
    @Override
    public Mode getMode() {
      return Mode.ROOM_CREATION;
    }
    @Override
    public boolean isModificationState() {
      return true;
    }
    @Override
    public boolean isBasePlanModificationState() {
      return true;
    }
    @Override
    public void setMode(Mode mode) {
      // Escape current creation and change state to matching mode
      escape();
      if (mode == Mode.SELECTION) {
        setState(getSelectionState());
      } else if (mode == Mode.PANNING) {
        setState(getPanningState());
      } else if (mode == Mode.WALL_CREATION) {
        setState(getWallCreationState());
      } else if (mode == Mode.POLYLINE_CREATION) {
        setState(getPolylineCreationState());
      } else if (mode == Mode.DIMENSION_LINE_CREATION) {
        setState(getDimensionLineCreationState());
      } else if (mode == Mode.LABEL_CREATION) {
        setState(getLabelCreationState());
      } 
    }
    @Override
    public void enter() {
      super.enter();
      this.oldSelection = home.getSelectedItems();
      this.oldBasePlanLocked = home.isBasePlanLocked();
      this.oldAllLevelsSelection = home.isAllLevelsSelection();
      this.newRoom = null;
      this.alignmentActivated = wasAlignmentActivatedLastMousePress();
      toggleMagnetism(wasMagnetismToggledLastMousePress());
      if (this.magnetismEnabled) {
        // Find the closest wall or room point to current mouse location
        PointMagnetizedToClosestWallOrRoomPoint point = new PointMagnetizedToClosestWallOrRoomPoint(
            getXLastMouseMove(), getYLastMouseMove());
        if (point.isMagnetized()) {
          this.xPreviousPoint = point.getX();
          this.yPreviousPoint = point.getY();
        } else {
          RoomPointWithAngleMagnetism pointWithAngleMagnetism = new RoomPointWithAngleMagnetism(
              getXLastMouseMove(), getYLastMouseMove());
          this.xPreviousPoint = pointWithAngleMagnetism.getX();
          this.yPreviousPoint = pointWithAngleMagnetism.getY();
        }
        getView().setAlignmentFeedback(Room.class, null, 
            this.xPreviousPoint, this.yPreviousPoint, point.isMagnetized());
      } else {
        this.xPreviousPoint = getXLastMousePress();
        this.yPreviousPoint = getYLastMousePress();
        getView().setAlignmentFeedback(Room.class, null, 
            this.xPreviousPoint, this.yPreviousPoint, false);
      }
      deselectAll();
    }
    @Override
    public void moveMouse(float x, float y) {
      PlanView planView = getView();
      // Compute the coordinates where current edit room point should be moved
      float xEnd = x;
      float yEnd = y;
      boolean magnetizedPoint = false;
      if (this.alignmentActivated) {
        PointWithAngleMagnetism pointWithAngleMagnetism = new PointWithAngleMagnetism(
            this.xPreviousPoint, this.yPreviousPoint, x, y, preferences.getLengthUnit(), planView.getPixelLength());
        xEnd = pointWithAngleMagnetism.getX();
        yEnd = pointWithAngleMagnetism.getY();
      } else if (this.magnetismEnabled) {
        // Find the closest wall or room point to current mouse location
        PointMagnetizedToClosestWallOrRoomPoint point = this.newRoom != null
            ? new PointMagnetizedToClosestWallOrRoomPoint(this.newRoom, this.newRoom.getPointCount() - 1, x, y)
            : new PointMagnetizedToClosestWallOrRoomPoint(x, y);
        magnetizedPoint = point.isMagnetized();
        if (magnetizedPoint) {
          xEnd = point.getX();
          yEnd = point.getY();
        } else {
          // Use magnetism if closest wall point is too far
          int editedPointIndex = this.newRoom != null 
              ? this.newRoom.getPointCount() - 1 
              : -1;
          RoomPointWithAngleMagnetism pointWithAngleMagnetism = new RoomPointWithAngleMagnetism(
              this.newRoom, editedPointIndex, this.xPreviousPoint, this.yPreviousPoint, x, y);
          xEnd = pointWithAngleMagnetism.getX();
          yEnd = pointWithAngleMagnetism.getY();
        }
      }
      // If current room doesn't exist
      if (this.newRoom == null) {
        // Create a new one
        this.newRoom = createAndSelectRoom(this.xPreviousPoint, this.yPreviousPoint, xEnd, yEnd);
      } else if (this.newPoint != null) {
        // Add a point to current room
        float [][] points = this.newRoom.getPoints();
        this.xPreviousPoint = points [points.length - 1][0];
        this.yPreviousPoint = points [points.length - 1][1]; 
        this.newRoom.addPoint(xEnd, yEnd);
        this.newPoint = null;
      } else {
        // Otherwise update its last point
        this.newRoom.setPoint(xEnd, yEnd, this.newRoom.getPointCount() - 1);
      }         
      planView.setToolTipFeedback(
          getToolTipFeedbackText(this.newRoom, this.newRoom.getPointCount() - 1), x, y);
      planView.setAlignmentFeedback(Room.class, this.newRoom, 
          xEnd, yEnd, magnetizedPoint);
      showRoomAngleFeedback(this.newRoom, this.newRoom.getPointCount() - 1);
      // Ensure point at (x,y) is visible
      planView.makePointVisible(x, y);
    }
    /**
     * Returns a new room instance with one side between (<code>xStart</code>,
     * <code>yStart</code>) and (<code>xEnd</code>, <code>yEnd</code>) points. 
     * The new room is added to home and selected
     */
    private Room createAndSelectRoom(float xStart, float yStart,
                                     float xEnd, float yEnd) {
      Room newRoom = createRoom(new float [][] {{xStart, yStart}, {xEnd, yEnd}});
      // Let's consider that points outside of home will create  by default a room with no ceiling
      Area insideWallsArea = getInsideWallsArea();
      newRoom.setCeilingVisible(insideWallsArea.contains(xStart, yStart));
      selectItem(newRoom);
      return newRoom;
    }
    @Override
    public void pressMouse(float x, float y, int clickCount, 
                           boolean shiftDown, boolean duplicationActivated) {
      if (clickCount == 2) {
        if (this.newRoom == null) {
          // Try to guess the room that contains the point (x,y)
          this.newRoom = createRoomAt(x, y);
          if (this.newRoom != null) {
            selectItem(this.newRoom);           
          }
        }
        validateDrawnRoom();
      } else {
        endRoomSide();
      }
    }
    private void validateDrawnRoom() {
      if (this.newRoom != null) {
        float [][] points = this.newRoom.getPoints();
        if (points.length < 3) {
          // Delete current created room if it doesn't have more than 2 clicked points
          home.deleteRoom(this.newRoom);
        } else {
          // Post room creation to undo support
          postCreateRooms(Arrays.asList(new Room [] {this.newRoom}), 
              this.oldSelection, this.oldBasePlanLocked, this.oldAllLevelsSelection);
        }
      }
      // Change state to RoomCreationState 
      setState(getRoomCreationState());
    }
    private void endRoomSide() {
      // Create a new room side only when its length is greater than zero
      if (this.newRoom != null
          && getRoomSideLength(this.newRoom, this.newRoom.getPointCount() - 1) > 0) {        
        this.newPoint = new float [2];
        // Let's consider that any point outside of home will create 
        // by default a room with no ceiling
        if (this.newRoom.isCeilingVisible()) {
          float [][] roomPoints = this.newRoom.getPoints();
          float [] lastPoint = roomPoints [roomPoints.length - 1];
          if (!getInsideWallsArea().contains(lastPoint [0], lastPoint [1])) {
            this.newRoom.setCeilingVisible(false);
          }
        }
      }
    }
    /**
     * Returns the room matching the closed path that contains the point at the given
     * coordinates or <code>null</code> if there's no closed path at this point. 
     */
    private Room createRoomAt(float x, float y) {
      for (GeneralPath roomPath : getRoomPathsFromWalls()) {
        if (roomPath.contains(x, y)) {
          // Add to roomPath the doorstep between the room border and the middle of the doors and windows 
          // with an elevation equal to zero that intersects with roomPath
          for (HomePieceOfFurniture piece : getVisibleDoorsAndWindowsAtGround(home.getFurniture())) {
            float [][] doorPoints = piece.getPoints();
            int intersectionCount = 0;
            for (int i = 0; i < doorPoints.length; i++) {
              if (roomPath.contains(doorPoints [i][0], doorPoints [i][1])) {
                intersectionCount++;
              }                
            }
            if (doorPoints.length == 4) {
              float epsilon = 0.05f;
              float [][] doorStepPoints = null;
              if (piece instanceof HomeDoorOrWindow
                  && ((HomeDoorOrWindow)piece).isWallCutOutOnBothSides()) {
                HomeDoorOrWindow door = (HomeDoorOrWindow)piece;
                Level selectedLevel = home.getSelectedLevel();
                Area doorArea = new Area(getPath(doorPoints));
                Area wallsDoorIntersection = new Area();
                for (Wall wall : home.getWalls()) {
                  if (wall.isAtLevel(selectedLevel)
                      && door.isParallelToWall(wall)) {
                    GeneralPath wallPath = getPath(wall.getPoints());
                    Area intersectionArea = new Area(wallPath);
                    intersectionArea.intersect(doorArea);
                    if (!intersectionArea.isEmpty()) {
                      HomePieceOfFurniture deeperDoor = door.clone();
                      // Increase door depth to ensure the wall will be cut on both sides 
                      // (doors and windows can't be rotated around horizontal axes)
                      deeperDoor.setDepthInPlan(deeperDoor.getDepth() + 4 * wall.getThickness());
                      intersectionArea = new Area(wallPath);
                      intersectionArea.intersect(new Area(getPath(deeperDoor.getPoints())));
                      wallsDoorIntersection.add(intersectionArea);
                    }
                  }
                }
                if (!wallsDoorIntersection.isEmpty()
                    && wallsDoorIntersection.isSingular()) {
                  float [][] intersectionPoints = getPathPoints(getPath(wallsDoorIntersection), true);
                  if (intersectionPoints.length == 4) {
                    // Compute the location of door points at the middle of its wall part
                    float doorMiddleY = door.getY() 
                        + door.getDepth() * (-0.5f + door.getWallDistance() + door.getWallThickness() / 2);
                    float halfWidth = door.getWidth() / 2;
                    float [] doorMiddlePoints = {door.getX() - halfWidth, doorMiddleY,
                                                 door.getX() + halfWidth, doorMiddleY};
                    AffineTransform rotation = AffineTransform.getRotateInstance(
                        door.getAngle(), door.getX(), door.getY());
                    rotation.transform(doorMiddlePoints, 0, doorMiddlePoints, 0, 2);
                    for (int i = 0; i < intersectionPoints.length - 1; i++) {
                      // Check point in room with rectangle intersection test otherwise we miss some points
                      if (roomPath.intersects(intersectionPoints [i][0] - epsilon / 2, 
                              intersectionPoints [i][1] - epsilon / 2, epsilon, epsilon)) {
                        int inPoint1 = i;
                        int outPoint1;
                        int outPoint2;
                        if (roomPath.intersects(intersectionPoints [i + 1][0] - epsilon / 2, 
                                 intersectionPoints [i + 1][1] - epsilon / 2, epsilon, epsilon)) {
                          outPoint2 = (i + 2) % 4;
                          outPoint1 = (i + 3) % 4;
                        } else if (roomPath.intersects(intersectionPoints [(i + 3) % 4][0] - epsilon / 2, 
                            intersectionPoints [(i + 3) % 4][1] - epsilon / 2, epsilon, epsilon)) {
                          outPoint1 = (i + 1) % 4;
                          outPoint2 = (i + 2) % 4;
                        } else {
                          // May happen if door intersects room path at only one point when door is larger that room side
                          break;
                        }
                        if (Point2D.distanceSq(intersectionPoints [inPoint1][0], intersectionPoints [inPoint1][1], 
                                doorMiddlePoints [0], doorMiddlePoints [1]) 
                            < Point2D.distanceSq(intersectionPoints [inPoint1][0], intersectionPoints [inPoint1][1], 
                                doorMiddlePoints [2], doorMiddlePoints [3])) {
                          intersectionPoints [outPoint1][0] = doorMiddlePoints [0]; 
                          intersectionPoints [outPoint1][1] = doorMiddlePoints [1]; 
                          intersectionPoints [outPoint2][0] = doorMiddlePoints [2]; 
                          intersectionPoints [outPoint2][1] = doorMiddlePoints [3];
                        } else {
                          intersectionPoints [outPoint1][0] = doorMiddlePoints [2]; 
                          intersectionPoints [outPoint1][1] = doorMiddlePoints [3]; 
                          intersectionPoints [outPoint2][0] = doorMiddlePoints [0]; 
                          intersectionPoints [outPoint2][1] = doorMiddlePoints [1];
                        }
                        doorStepPoints = intersectionPoints;
                        break;
                      }
                    }
                  }
                }
              } 
              if (doorStepPoints == null 
                  && intersectionCount == 2) {
                // Find the intersection of the door with home walls
                Area wallsDoorIntersection = new Area(getWallsArea(false));
                wallsDoorIntersection.intersect(new Area(getPath(doorPoints)));
                // Reduce the size of intersection to its half
                float [][] intersectionPoints = getPathPoints(getPath(wallsDoorIntersection), false);
                if (intersectionPoints.length == 4) {
                  for (int i = 0; i < intersectionPoints.length; i++) {
                    // Check point in room with rectangle intersection test otherwise we miss some points
                    if (roomPath.intersects(intersectionPoints [i][0] - epsilon / 2, 
                          intersectionPoints [i][1] - epsilon / 2, epsilon, epsilon)) {
                      int inPoint1 = i;
                      int inPoint2;
                      int outPoint1;
                      int outPoint2;
                      if (roomPath.intersects(intersectionPoints [i + 1][0] - epsilon / 2, 
                               intersectionPoints [i + 1][1] - epsilon / 2, epsilon, epsilon)) {
                        inPoint2 = i + 1;
                        outPoint2 = (i + 2) % 4;
                        outPoint1 = (i + 3) % 4;
                      } else {
                        outPoint1 = (i + 1) % 4;
                        outPoint2 = (i + 2) % 4;
                        inPoint2 = (i + 3) % 4;
                      }
                      intersectionPoints [outPoint1][0] = (intersectionPoints [outPoint1][0] 
                          + intersectionPoints [inPoint1][0]) / 2; 
                      intersectionPoints [outPoint1][1] = (intersectionPoints [outPoint1][1] 
                          + intersectionPoints [inPoint1][1]) / 2; 
                      intersectionPoints [outPoint2][0] = (intersectionPoints [outPoint2][0] 
                          + intersectionPoints [inPoint2][0]) / 2; 
                      intersectionPoints [outPoint2][1] = (intersectionPoints [outPoint2][1] 
                          + intersectionPoints [inPoint2][1]) / 2;
                      doorStepPoints = intersectionPoints;
                      break;
                    }
                  }
                }                
              }
              if (doorStepPoints != null) {
                GeneralPath path = getPath(doorStepPoints);
                // Enlarge the intersection path to ensure its union with room builds only one path
                Rectangle2D bounds2D = path.getBounds2D();                    
                AffineTransform transform = AffineTransform.getTranslateInstance(bounds2D.getCenterX(), bounds2D.getCenterY());
                double min = Math.min(bounds2D.getWidth(), bounds2D.getHeight());
                double scale = (min + epsilon) / min;
                transform.scale(scale, scale);
                transform.translate(-bounds2D.getCenterX(), -bounds2D.getCenterY());
                Shape doorStepPath = path.createTransformedShape(transform);
                Area halfDoorRoomUnion = new Area(doorStepPath);
                halfDoorRoomUnion.add(new Area(roomPath));
                roomPath = getPath(halfDoorRoomUnion);
              }
            }
          }
          return createRoom(getPathPoints(roomPath, false));
        }
      }
      return null;
    }
    /**
     * Returns all the visible doors and windows with a null elevation in the given <code>furniture</code>.  
     */
    private List<HomePieceOfFurniture> getVisibleDoorsAndWindowsAtGround(List<HomePieceOfFurniture> furniture) {
      List<HomePieceOfFurniture> doorsAndWindows = new ArrayList<HomePieceOfFurniture>(furniture.size());
      for (HomePieceOfFurniture piece : furniture) {
        if (isPieceOfFurnitureVisibleAtSelectedLevel(piece)
            && piece.getElevation() == 0) {
          if (piece instanceof HomeFurnitureGroup) {
            doorsAndWindows.addAll(getVisibleDoorsAndWindowsAtGround(((HomeFurnitureGroup)piece).getFurniture()));
          } else if (piece.isDoorOrWindow()) {
            doorsAndWindows.add(piece);
          }
        }
      }
      return doorsAndWindows;
    }
    @Override
    public void setEditionActivated(boolean editionActivated) {
      PlanView planView = getView();
      if (editionActivated) {
        planView.deleteFeedback();
        if (this.newRoom == null) {
          // Edit previous point
          planView.setToolTipEditedProperties(new EditableProperty [] {EditableProperty.X,
                                                                       EditableProperty.Y},
              new Object [] {this.xPreviousPoint, this.yPreviousPoint},
              this.xPreviousPoint, this.yPreviousPoint);
        } else {
          if (this.newPoint != null) {
            // May happen if edition is activated after the user clicked to add a new point 
            createNextSide();            
          }
          // Edit length and angle
          float [][] points = this.newRoom.getPoints();
          planView.setToolTipEditedProperties(new EditableProperty [] {EditableProperty.LENGTH,
                                                                       EditableProperty.ANGLE},
              new Object [] {getRoomSideLength(this.newRoom, points.length - 1), 
                             getRoomSideAngle(this.newRoom, points.length - 1)},
              points [points.length - 1][0], points [points.length - 1][1]);
        }
      } else { 
        if (this.newRoom == null) {
          // Create a new side once user entered the start point of the room 
          LengthUnit lengthUnit = preferences.getLengthUnit();
          float defaultLength = lengthUnit == LengthUnit.INCH || lengthUnit == LengthUnit.INCH_DECIMALS 
              ? LengthUnit.footToCentimeter(10) : 300;
          this.newRoom = createAndSelectRoom(this.xPreviousPoint, this.yPreviousPoint, 
                                             this.xPreviousPoint + defaultLength, this.yPreviousPoint);
          // Activate automatically second step to let user enter the 
          // length and angle of the new side
          planView.deleteFeedback();
          setEditionActivated(true);
        } else if (System.currentTimeMillis() - this.lastPointCreationTime < 300) {
          // If the user deactivated edition less than 300 ms after activation, 
          // escape current side creation
          escape();
        } else {
          endRoomSide();
          float [][] points = this.newRoom.getPoints();
          // If last edited point matches first point validate drawn room 
          if (points.length > 2 
              && this.newRoom.getPointIndexAt(points [points.length - 1][0], points [points.length - 1][1], 0.001f) == 0) {
            // Remove last currently edited point.
            this.newRoom.removePoint(this.newRoom.getPointCount() - 1);
            validateDrawnRoom();
            return;
          }
          createNextSide();
          // Reactivate automatically second step
          planView.deleteToolTipFeedback();
          setEditionActivated(true);
        }
      }
    }
    private void createNextSide() {
      // Add a point to current room
      float [][] points = this.newRoom.getPoints();
      this.xPreviousPoint = points [points.length - 1][0];
      this.yPreviousPoint = points [points.length - 1][1]; 
      // Create a new side with an angle equal to previous side angle - 90�
      double previousSideAngle = Math.PI - Math.atan2(points [points.length - 2][1] - points [points.length - 1][1], 
          points [points.length - 2][0] - points [points.length - 1][0]);
      previousSideAngle -=  Math.PI / 2;
      float previousSideLength = getRoomSideLength(this.newRoom, points.length - 1); 
      this.newRoom.addPoint(
          (float)(this.xPreviousPoint + previousSideLength * Math.cos(previousSideAngle)),
          (float)(this.yPreviousPoint - previousSideLength * Math.sin(previousSideAngle)));
      this.newPoint = null;
      this.lastPointCreationTime = System.currentTimeMillis();
    }
    @Override
    public void updateEditableProperty(EditableProperty editableProperty, Object value) {
      PlanView planView = getView();
      if (this.newRoom == null) {
        float maximumLength = preferences.getLengthUnit().getMaximumLength();
        // Update start point of the first wall
        switch (editableProperty) {
          case X : 
            this.xPreviousPoint = value != null ? ((Number)value).floatValue() : 0;
            this.xPreviousPoint = Math.max(-maximumLength, Math.min(this.xPreviousPoint, maximumLength));
            break;      
          case Y : 
            this.yPreviousPoint = value != null ? ((Number)value).floatValue() : 0;
            this.yPreviousPoint = Math.max(-maximumLength, Math.min(this.yPreviousPoint, maximumLength));
            break;      
        }
        planView.setAlignmentFeedback(Room.class, null, this.xPreviousPoint, this.yPreviousPoint, true);
        planView.makePointVisible(this.xPreviousPoint, this.yPreviousPoint);
      } else {
        float [][] roomPoints = this.newRoom.getPoints();
        float [] previousPoint = roomPoints [roomPoints.length - 2];
        float [] point = roomPoints [roomPoints.length - 1];
        float newX;
        float newY;
        // Update end point of the current room
        switch (editableProperty) {
          case LENGTH : 
            float length = value != null ? ((Number)value).floatValue() : 0;
            length = Math.max(0.001f, Math.min(length, preferences.getLengthUnit().getMaximumLength()));
            double sideAngle = Math.PI - Math.atan2(previousPoint [1] - point [1], 
                previousPoint [0] - point [0]);
            newX = (float)(previousPoint [0] + length * Math.cos(sideAngle));
            newY = (float)(previousPoint [1] - length * Math.sin(sideAngle));
            break;      
          case ANGLE : 
            sideAngle = Math.toRadians(value != null ? ((Number)value).floatValue() : 0);
            if (roomPoints.length > 2) {
              sideAngle -= Math.atan2(roomPoints [roomPoints.length - 3][1] - previousPoint [1], 
                  roomPoints [roomPoints.length - 3][0] - previousPoint [0]);
            }
            float sideLength = getRoomSideLength(this.newRoom, roomPoints.length - 1);
            newX = (float)(previousPoint [0] + sideLength * Math.cos(sideAngle));
            newY = (float)(previousPoint [1] - sideLength * Math.sin(sideAngle));
            break;
          default :
            return;
        }
        this.newRoom.setPoint(newX, newY, roomPoints.length - 1);
        // Update new room
        planView.setAlignmentFeedback(Room.class, this.newRoom, newX, newY, false);
        showRoomAngleFeedback(this.newRoom, roomPoints.length - 1);
        // Ensure room side points are visible
        planView.makePointVisible(previousPoint [0], previousPoint [1]);
        planView.makePointVisible(newX, newY);
      }
    }
    @Override
    public void toggleMagnetism(boolean magnetismToggled) {
      // Compute active magnetism
      this.magnetismEnabled = preferences.isMagnetismEnabled()
                              ^ magnetismToggled;
      // If the new room already exists, 
      // compute again its last point as if mouse moved
      if (this.newRoom != null) {
        moveMouse(getXLastMouseMove(), getYLastMouseMove());
      }
    }
    @Override
    public void setAlignmentActivated(boolean alignmentActivated) {
      this.alignmentActivated = alignmentActivated;
      moveMouse(getXLastMouseMove(), getYLastMouseMove());
    }
    @Override
    public void escape() {
      if (this.newRoom != null
          && this.newPoint == null) {
        // Remove last currently edited point.
        this.newRoom.removePoint(this.newRoom.getPointCount() - 1);
      }
      validateDrawnRoom();
    }
    @Override
    public void exit() {
      getView().deleteFeedback();
      this.newRoom = null;
      this.newPoint = null;
      this.oldSelection = null;
    }  
  }
