/*
 * FurnitureCatalogListPanel.java 10 janv 2010
 *
 * Sweet Home 3D, Copyright (c) 2010 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.awt.EventQueue;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.AbstractListModel;
import com.eteks.sweethome3d.model.CatalogPieceOfFurniture;
import com.eteks.sweethome3d.model.CollectionEvent;
import com.eteks.sweethome3d.model.CollectionListener;
import com.eteks.sweethome3d.model.FurnitureCatalog;
import com.eteks.sweethome3d.model.FurnitureCategory;
/**
 * A furniture catalog view that displays furniture in a list, with a combo and search text field.
 * @author Emmanuel Puybaret
 */
private static class FurnitureCatalogListModel extends AbstractListModel {
    private FurnitureCatalog                catalog;
    private List<CatalogPieceOfFurniture>   furniture;
    private FurnitureCategory               filterCategory;
    private String                          filterText;
    public FurnitureCatalogListModel(FurnitureCatalog catalog) {
      this.catalog = catalog;
      this.filterText = "";
      catalog.addFurnitureListener(new FurnitureCatalogListener(this));
    }
    public void setFilterCategory(FurnitureCategory filterCategory) {
      this.filterCategory = filterCategory;
      resetFurnitureList();
    }
    public void setFilterText(String filterText) {
      this.filterText = filterText;
      resetFurnitureList();
    }
    public Object getElementAt(int index) {
      checkFurnitureList();
      return this.furniture.get(index);
    }
    public int getSize() {
      checkFurnitureList();
      return this.furniture.size();
    }
    private void resetFurnitureList() {
      if (this.furniture != null) {
        this.furniture = null;
        EventQueue.invokeLater(new Runnable() {
            public void run() {
              fireContentsChanged(this, -1, -1);
            }
          });
      }
    }
    private void checkFurnitureList() {
      if (this.furniture == null) {
        this.furniture = new ArrayList<CatalogPieceOfFurniture>();
        this.furniture.clear();
        for (FurnitureCategory category : this.catalog.getCategories()) {
          for (CatalogPieceOfFurniture piece : category.getFurniture()) {
            if ((this.filterCategory == null
                  || piece.getCategory().equals(this.filterCategory))
                && piece.matchesFilter(this.filterText)) {
              furniture.add(piece);
            }
          }
        }
        Collections.sort(this.furniture);
      }
    }
    /**
     * Catalog furniture listener bound to this list model with a weak reference to avoid
     * strong link between catalog and this list.  
     */
    private static class FurnitureCatalogListener implements CollectionListener<CatalogPieceOfFurniture> {
      private WeakReference<FurnitureCatalogListModel>  listModel;
      public FurnitureCatalogListener(FurnitureCatalogListModel catalogListModel) {
        this.listModel = new WeakReference<FurnitureCatalogListModel>(catalogListModel);
      }
      public void collectionChanged(CollectionEvent<CatalogPieceOfFurniture> ev) {
        // If catalog list model was garbage collected, remove this listener from catalog
        FurnitureCatalogListModel listModel = this.listModel.get();
        FurnitureCatalog catalog = (FurnitureCatalog)ev.getSource();
        if (listModel == null) {
          catalog.removeFurnitureListener(this);
        } else {
          listModel.resetFurnitureList();
        }
      }
    }
  }
