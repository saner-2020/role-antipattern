/*
 * Copyright the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package de.schildbach.wallet.ui;
import de.schildbach.wallet.WalletApplication;
import android.arch.lifecycle.LiveData;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ClipboardManager.OnPrimaryClipChangedListener;
import android.content.Context;
/**
 * @author Andreas Schildbach
 */
public static class ClipLiveData extends LiveData<ClipData> implements OnPrimaryClipChangedListener {
        private final ClipboardManager clipboardManager;
        public ClipLiveData(final WalletApplication application) {
            clipboardManager = (ClipboardManager) application.getSystemService(Context.CLIPBOARD_SERVICE);
        }
        @Override
        protected void onActive() {
            clipboardManager.addPrimaryClipChangedListener(this);
            onPrimaryClipChanged();
        }
        @Override
        protected void onInactive() {
            clipboardManager.removePrimaryClipChangedListener(this);
        }
        @Override
        public void onPrimaryClipChanged() {
            setValue(clipboardManager.getPrimaryClip());
        }
        public void setClipData(final ClipData clipData) {
            clipboardManager.setPrimaryClip(clipData);
        }
    }
