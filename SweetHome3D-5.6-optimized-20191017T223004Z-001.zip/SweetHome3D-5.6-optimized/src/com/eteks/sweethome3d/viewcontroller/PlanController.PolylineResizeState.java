/*
 * PlanController.java 2 juin 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.viewcontroller;
import java.util.ArrayList;
import java.util.Collection;
import com.eteks.sweethome3d.model.Polyline;
/**
 * A MVC controller for the plan view.
 * @author Emmanuel Puybaret
 */
private class PolylineResizeState extends AbstractPolylineState {
    private Collection<Polyline> polylines;
    private Polyline             selectedPolyline;
    private int                  polylinePointIndex;
    private float                oldX;
    private float                oldY;
    private float                deltaXToResizePoint;
    private float                deltaYToResizePoint;
    private boolean              magnetismEnabled;
    private boolean              alignmentActivated;
    @Override
    public Mode getMode() {
      return Mode.SELECTION;
    }
    @Override
    public boolean isModificationState() {
      return true;
    }
    @Override
    public boolean isBasePlanModificationState() {
      return true;
    }
    @Override
    public void enter() {
      super.enter();
      this.selectedPolyline = (Polyline)home.getSelectedItems().get(0);
      this.polylines = new ArrayList<Polyline>(home.getPolylines());
      this.polylines.remove(this.selectedPolyline);
      float margin = INDICATOR_PIXEL_MARGIN / getScale();
      this.polylinePointIndex = this.selectedPolyline.getPointIndexAt( 
          getXLastMousePress(), getYLastMousePress(), margin);
      float [][] polylinePoints = this.selectedPolyline.getPoints();
      this.oldX = polylinePoints [this.polylinePointIndex][0];
      this.oldY = polylinePoints [this.polylinePointIndex][1];
      this.deltaXToResizePoint = getXLastMousePress() - this.oldX;
      this.deltaYToResizePoint = getYLastMousePress() - this.oldY;
      this.alignmentActivated = wasAlignmentActivatedLastMousePress();
      toggleMagnetism(wasMagnetismToggledLastMousePress());
      PlanView planView = getView();
      planView.setResizeIndicatorVisible(true);
      String toolTipFeedbackText = getToolTipFeedbackText(this.selectedPolyline, this.polylinePointIndex);
      if (toolTipFeedbackText != null) {
        planView.setToolTipFeedback(toolTipFeedbackText, getXLastMousePress(), getYLastMousePress());
        if (this.selectedPolyline.getJoinStyle() != Polyline.JoinStyle.CURVED) {
          showPolylineAngleFeedback(this.selectedPolyline, this.polylinePointIndex);
        }
      }
    }
    @Override
    public void moveMouse(float x, float y) {
      PlanView planView = getView();
      float newX = x - this.deltaXToResizePoint;
      float newY = y - this.deltaYToResizePoint;
      if (this.alignmentActivated 
          || this.magnetismEnabled) {
        float [][] polylinePoints = this.selectedPolyline.getPoints();
        int previousPointIndex = this.polylinePointIndex == 0 
            ? (this.selectedPolyline.isClosedPath()  
                  ? polylinePoints.length - 1 
                  : 1)
            : this.polylinePointIndex - 1;
        float xPreviousPoint = polylinePoints [previousPointIndex][0];
        float yPreviousPoint = polylinePoints [previousPointIndex][1];
        PointWithAngleMagnetism pointWithAngleMagnetism = new PointWithAngleMagnetism(
            xPreviousPoint, yPreviousPoint, newX, newY, preferences.getLengthUnit(), planView.getPixelLength());
        newX = pointWithAngleMagnetism.getX();
        newY = pointWithAngleMagnetism.getY();
      } 
      this.selectedPolyline.setPoint(newX, newY, this.polylinePointIndex);
      planView.setToolTipFeedback(getToolTipFeedbackText(this.selectedPolyline, this.polylinePointIndex), x, y);
      if (this.selectedPolyline.getJoinStyle() != Polyline.JoinStyle.CURVED) {
        showPolylineAngleFeedback(this.selectedPolyline, this.polylinePointIndex);
      }
      // Ensure point at (x,y) is visible
      planView.makePointVisible(x, y);
    }
    @Override
    public void releaseMouse(float x, float y) {
      postPolylineResize(this.selectedPolyline, this.oldX, this.oldY, this.polylinePointIndex);
      setState(getSelectionState());
    }
    @Override
    public void toggleMagnetism(boolean magnetismToggled) {
      // Compute active magnetism
      this.magnetismEnabled = preferences.isMagnetismEnabled()
                              ^ magnetismToggled;
      moveMouse(getXLastMouseMove(), getYLastMouseMove());
    }
    @Override
    public void setAlignmentActivated(boolean alignmentActivated) {
      this.alignmentActivated = alignmentActivated;
      moveMouse(getXLastMouseMove(), getYLastMouseMove());
    }
    @Override
    public void escape() {
      this.selectedPolyline.setPoint(this.oldX, this.oldY, this.polylinePointIndex);
      setState(getSelectionState());
    }
    @Override
    public void exit() {
      PlanView planView = getView();
      planView.setResizeIndicatorVisible(false);
      planView.deleteFeedback();
      this.selectedPolyline = null;
    }  
  }
