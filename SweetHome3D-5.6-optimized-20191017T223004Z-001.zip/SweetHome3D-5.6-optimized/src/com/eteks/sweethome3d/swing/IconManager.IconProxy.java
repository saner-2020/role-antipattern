/*
 * IconManager.java 2 mai 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.eteks.sweethome3d.swing;
import java.awt.Component;
import java.awt.Graphics;
import java.util.concurrent.Executors;
import javax.swing.Icon;
import com.eteks.sweethome3d.model.Content;
/**
 * Singleton managing icons cache.
 * @author Emmanuel Puybaret
 */
private class IconProxy implements Icon {
    private Icon icon;
    public IconProxy(final Content content, final int height,
                     final Component waitingComponent,
                     final Icon errorIcon, Icon waitIcon) {
      this.icon = waitIcon;
      if (iconsLoader == null) {
        iconsLoader = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() * 2);
      }
      // Load the icon in a different thread
      iconsLoader.execute(new Runnable () {
          public void run() {
            icon = createIcon(content, height, errorIcon);
            waitingComponent.repaint();
          }
        });
    }
    public int getIconWidth() {
      return this.icon.getIconWidth();
    }
    public int getIconHeight() {
      return this.icon.getIconHeight();
    }
    public void paintIcon(Component c, Graphics g, int x, int y) {
      this.icon.paintIcon(c, g, x, y);
    }
    public Icon getIcon() {
      return this.icon;
    }
  }
